package com.lms.caller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Prefs.enabled(c) && Prefs.userId(c).isNotEmpty()) {
            ContextCompat.startForegroundService(c, Intent(c, CallService::class.java))
        }
    }
}
