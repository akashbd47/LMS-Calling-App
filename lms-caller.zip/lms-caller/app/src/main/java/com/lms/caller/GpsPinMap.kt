package com.lms.caller

import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView

/**
 * Map that shows ONLY the phone's GPS position (red pin + accuracy circle).
 * The pin is attached to the GPS coordinate, so panning or zooming the map never changes it and it cannot be
 * moved by hand. [fix] is the location that gets saved.
 */
class GpsPinMap(
    private val h: HomeActivity,
    private val startLat: Double,
    private val startLng: Double,
    private val startZoom: Double,
    private val oldLoc: Loc?
) {
    val view = FrameLayout(h)
    val status: TextView = h.label("GPS not started", 13f, C.muted)
    var fix: Location? = null
        private set

    private val mv = MapView(h)
    private var map: MapLibreMap? = null
    private var sat = false
    private var following = true
    private var firstZoomDone = false
    private var gps: Gps? = null
    private var waitingForGps = false
    private var receiver: BroadcastReceiver? = null
    private val handler = Handler(Looper.getMainLooper())
    private val pin = h.icon(R.drawable.ic_pin, C.bad, 40)
    private val oldPin = h.icon(R.drawable.ic_pin, Color.parseColor("#64748B"), 30)
    private val circle = View(h)

    init {
        view.addView(mv, FrameLayout.LayoutParams(MATCH, MATCH))
        circle.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#262563EB"))
            setStroke(h.dp(1), Color.parseColor("#2563EB"))
        }
        circle.visibility = View.GONE
        view.addView(circle, FrameLayout.LayoutParams(h.dp(16), h.dp(16)))
        oldPin.visibility = View.GONE
        view.addView(oldPin, FrameLayout.LayoutParams(h.dp(30), h.dp(30)))
        pin.visibility = View.GONE
        view.addView(pin, FrameLayout.LayoutParams(h.dp(40), h.dp(40)))

        val tipText = if (oldLoc != null) "Red = your GPS location now  \u2022  Grey = saved location" else "Showing your phone's GPS location"
        val tip = h.label(tipText, 12f, C.text, true)
        tip.background = h.shape(Color.WHITE, 12)
        tip.setPadding(h.dp(12), h.dp(8), h.dp(12), h.dp(8))
        tip.elevation = h.dp(3).toFloat()
        view.addView(tip, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            setMargins(h.dp(10), h.dp(10), h.dp(70), 0)
        })
        view.addView(h.fab(R.drawable.ic_layers) { toggleSat() }, FrameLayout.LayoutParams(h.dp(46), h.dp(46), Gravity.TOP or Gravity.END).apply {
            setMargins(0, h.dp(10), h.dp(10), 0)
        })
        view.addView(h.fab(R.drawable.ic_target) { recenter() }, FrameLayout.LayoutParams(h.dp(46), h.dp(46), Gravity.TOP or Gravity.END).apply {
            setMargins(0, h.dp(64), h.dp(10), 0)
        })
    }

    fun start() {
        h.registerMap(mv)
        mv.getMapAsync { m ->
            map = m
            m.uiSettings.isRotateGesturesEnabled = false
            m.uiSettings.isCompassEnabled = false
            m.cameraPosition = CameraPosition.Builder().target(LatLng(startLat, startLng)).zoom(startZoom).build()
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) following = false
            }
            m.addOnCameraMoveListener { updateOverlay() }
            m.addOnCameraIdleListener { updateOverlay() }
            MapStyle.apply(m, false) { updateOverlay() }
        }
        // when the user switches GPS on in the phone settings, carry on automatically
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (waitingForGps && gpsOn()) {
                    waitingForGps = false
                    refreshGps()
                }
            }
        }
        receiver = r
        try { h.registerReceiver(r, IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION)) } catch (e: Exception) { }
        refreshGps()
    }

    fun close() {
        handler.removeCallbacksAndMessages(null)
        gps?.stop()
        receiver?.let { try { h.unregisterReceiver(it) } catch (e: Exception) { } }
        receiver = null
        h.unregisterMap(mv)
    }

    /** True when the phone's location (GPS) is switched on. */
    fun gpsOn(): Boolean {
        val lm = h.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false }
    }

    private fun askGps() {
        waitingForGps = true
        status.setTextColor(C.bad)
        status.text = "GPS is OFF. Turn on Location (GPS) to add a location."
        AlertDialog.Builder(h)
            .setTitle("Turn on GPS")
            .setMessage("Phone location (GPS) must be ON to add a location.\n\nTap \"Turn on\", switch Location on (High accuracy), then come back to the app.")
            .setPositiveButton("Turn on") { _, _ ->
                try {
                    h.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                } catch (e: Exception) {
                    h.toast("Open phone Settings and turn on Location")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleSat() {
        val m = map ?: return
        sat = !sat
        MapStyle.apply(m, sat) { updateOverlay() }
    }

    private fun recenter() {
        val m = map ?: return
        following = true
        val f = fix
        if (f == null) {
            h.toast("GPS location not found yet")
            return
        }
        val z = if (m.cameraPosition.zoom < 17.0) 18.0 else m.cameraPosition.zoom
        m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(f.latitude, f.longitude), z))
    }

    /** (Re)starts the GPS search. The saved position is always the best GPS fix of the current search. */
    fun refreshGps() {
        h.needLocation { ok ->
            if (!ok) {
                status.setTextColor(C.bad)
                status.text = "Location permission is needed to add a location."
                h.toast("Allow the location permission to continue")
            } else if (!gpsOn()) {
                fix = null
                updateOverlay()
                askGps()
            } else {
                waitingForGps = false
                following = true
                fix = null
                updateOverlay()
                var g = gps
                if (g == null) {
                    g = Gps(h) { onFix(it) }
                    gps = g
                }
                if (g.start()) {
                    status.setTextColor(C.muted)
                    status.text = "Searching GPS... stay outside near the house"
                    handler.removeCallbacksAndMessages(null)
                    handler.postDelayed({ stopGps() }, 45000L)
                } else {
                    status.setTextColor(C.bad)
                    status.text = "Location is turned off. Turn on GPS in phone settings."
                }
            }
        }
    }

    private fun stopGps() {
        val g = gps ?: return
        if (g.isRunning) g.stop()
        val f = fix
        if (f != null) {
            status.text = "GPS fixed  \u2022  accuracy \u00B1${f.accuracy.toInt()} m"
        } else {
            status.setTextColor(C.bad)
            status.text = "GPS location not found. Go outside and tap Refresh GPS."
        }
    }

    private fun onFix(l: Location) {
        fix = l
        val a = l.accuracy.toInt()
        status.setTextColor(if (a <= 20) C.ok else if (a <= 50) C.warn else C.bad)
        status.text = "GPS accuracy \u00B1$a m" + if (a <= 20) "  (good)" else "  (improving...)"
        val m = map
        if (m != null && following) {
            val ll = LatLng(l.latitude, l.longitude)
            if (!firstZoomDone) {
                firstZoomDone = true
                m.animateCamera(CameraUpdateFactory.newLatLngZoom(ll, 18.0))
            } else {
                m.animateCamera(CameraUpdateFactory.newLatLng(ll))
            }
        }
        updateOverlay()
        if (a <= 12) {
            handler.removeCallbacksAndMessages(null)
            stopGps()
        }
    }

    /** Puts the pin views on top of the map at the screen position of their coordinates. */
    private fun updateOverlay() {
        val m = map ?: return
        val proj = m.projection
        val f = fix
        if (f == null) {
            pin.visibility = View.GONE
            circle.visibility = View.GONE
        } else {
            val p = proj.toScreenLocation(LatLng(f.latitude, f.longitude))
            pin.visibility = View.VISIBLE
            pin.translationX = p.x - h.dp(20)
            pin.translationY = p.y - h.dp(37)
            val mpp = proj.getMetersPerPixelAtLatitude(f.latitude)
            var d = if (mpp > 0.0) (2.0 * f.accuracy / mpp * h.resources.displayMetrics.density).toInt() else 0
            d = d.coerceIn(h.dp(16), h.dp(260))
            val lp = circle.layoutParams
            if (lp.width != d) {
                lp.width = d
                lp.height = d
                circle.layoutParams = lp
            }
            circle.translationX = p.x - d / 2f
            circle.translationY = p.y - d / 2f
            circle.visibility = View.VISIBLE
        }
        val o = oldLoc
        if (o != null) {
            val p = proj.toScreenLocation(LatLng(o.lat, o.lng))
            oldPin.visibility = View.VISIBLE
            oldPin.translationX = p.x - h.dp(15)
            oldPin.translationY = p.y - h.dp(28)
        }
    }
}
