package com.lms.caller

import android.app.AlertDialog
import android.graphics.Color
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.text.TextUtils
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

object MapStyle {
    const val STREET = "https://tiles.openfreemap.org/styles/liberty"
    private const val SAT = "{\"version\":8," +
        "\"glyphs\":\"https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf\"," +
        "\"sources\":{\"sat\":{\"type\":\"raster\",\"tiles\":[\"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}\"]," +
        "\"tileSize\":256,\"maxzoom\":19,\"attribution\":\"Esri, Maxar, Earthstar Geographics\"}}," +
        "\"layers\":[{\"id\":\"sat\",\"type\":\"raster\",\"source\":\"sat\"}]}"

    fun font(sat: Boolean): String = if (sat) "Open Sans Regular" else "Noto Sans Regular"

    fun apply(map: MapLibreMap, sat: Boolean, done: (Style) -> Unit) {
        val b = if (sat) Style.Builder().fromJson(SAT) else Style.Builder().fromUri(STREET)
        map.setStyle(b) { style -> done(style) }
    }
}

/** Location module: the saved locations (CustomerLocations), also of customers whose loan is already paid. */
class LocationScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "Customer Location", Repo.status, { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, village, phone, L/C no")
    private val count = h.label("", 13f, C.pink, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private var rows: List<Loc> = emptyList()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    init {
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { refreshList() }
        header.addChip(unionBar.root)
        header.action(h, R.drawable.ic_add) { addPin() }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))

        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(4), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    private fun onData() {
        header.sub.text = Repo.status
        unionBar.refresh()
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Loc>()
        for (l in Repo.savedLocs()) {
            if (!Repo.unionOk(l.union)) continue
            if (q.isNotEmpty() && !(l.name.lowercase().contains(q) || l.father.lowercase().contains(q) ||
                    l.spouse.lowercase().contains(q) || l.village.lowercase().contains(q) ||
                    l.caseNo.lowercase().contains(q) || (digits.isNotEmpty() && normalizePhone(l.phone).contains(digits)))) continue
            out.add(l)
        }
        out.sortBy { it.name.lowercase() }
        count.text = "${out.size} locations saved"
        rows = out
        recycler.adapter?.notifyDataSetChanged()
    }

    /** "+" : pick a customer from the loan list, then set the pin. */
    private fun addPin() {
        if (Repo.loans.isEmpty()) { h.toast("Customer data is not loaded yet"); return }
        CustomerPicker.open(h, "Add location", "Customers without a location", { Repo.locFor(it) == null }) { c ->
            h.pop()
            LocationEditor.open(h, c)
        }
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val badge = h.pill("", C.ok)
        val nav: ImageView = h.icon(R.drawable.ic_nav, C.primary, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            root.gravity = Gravity.CENTER_VERTICAL
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(1))
            col.addView(badge, h.lp(8, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            nav.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            nav.background = h.ripple(h.shape(C.soft, 24), 24)
            root.addView(nav, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(12), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            fun at(): Loc? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            r.setOnClickListener { at()?.let { Details.open(h, Repo.custFor(it), it) } }
            vh.nav.setOnClickListener { at()?.let { Act.navigate(h, it.lat, it.lng, it.name) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val l = rows[i]
            v.name.text = l.name
            v.l2.text = listOf(l.village, l.union).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            v.l2.gone(v.l2.text.isEmpty())
            val parts = ArrayList<String>()
            if (l.phone.isNotEmpty()) parts.add(l.phone)
            if (l.father.isNotEmpty()) parts.add("Father: " + l.father)
            else if (l.spouse.isNotEmpty()) parts.add("Spouse: " + l.spouse)
            v.l3.text = parts.joinToString("  \u2022  ")
            v.l3.gone(parts.isEmpty())
            val live = Repo.custFor(l) != null
            v.badge.text = if (live) "Active loan" else "Loan closed / not in loan data"
            val col = if (live) C.ok else C.muted
            v.badge.setTextColor(col)
            v.badge.background = h.shape((col and 0xFFFFFF) or 0x1F000000, 20)
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}

/** Set / update the home pin of one customer. The pin is always the phone's GPS position and cannot be moved by hand. */
class LocationEditor private constructor(private val h: HomeActivity, private val c: Cust) {
    val root = h.vbox()
    private val existing: Loc? = Repo.locFor(c)
    private val panel: GpsPinMap

    companion object {
        fun open(h: HomeActivity, c: Cust) {
            val e = LocationEditor(h, c)
            h.push(e.root) { e.close() }
            e.start()
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        val hd = Header(h, if (existing != null) "Update location" else "Add location",
            listOf(c.name, c.village).filter { it.isNotEmpty() }.joinToString("  \u2022  "), { h.pop() })
        root.addView(hd.root)

        val st = startPos()
        panel = GpsPinMap(h, st[0], st[1], st[2], existing)
        root.addView(panel.view, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bottom = h.vbox()
        bottom.setBackgroundColor(Color.WHITE)
        bottom.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(14))
        bottom.elevation = h.dp(8).toFloat()
        if (existing != null) {
            bottom.addView(h.label("Already saved by ${existing.updatedBy} on ${fmtDate(existing.updatedAt)}", 12f, C.muted))
        }
        bottom.addView(panel.status, h.lp(4))
        val row = h.hbox()
        row.addView(h.btn("Refresh GPS", 1, R.drawable.ic_target) { panel.refreshGps() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(8) })
        row.addView(h.btn("Save location", 0, R.drawable.ic_pin) { save() }, LinearLayout.LayoutParams(0, WRAP, 1.3f))
        bottom.addView(row, h.lp(10))
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun start() {
        panel.start()
    }

    /** Where the map opens: the old pin, the last GPS fix, other pins of the same village, or Bangladesh. */
    private fun startPos(): DoubleArray {
        val e = existing
        if (e != null) return doubleArrayOf(e.lat, e.lng, 18.0)
        if (Repo.hasFix) return doubleArrayOf(Repo.lastLat, Repo.lastLng, 17.0)
        val same = Repo.locs.values.filter { !it.isNew && it.village.isNotEmpty() && it.village == c.village }
        if (same.isNotEmpty()) return doubleArrayOf(same.map { it.lat }.average(), same.map { it.lng }.average(), 15.0)
        return doubleArrayOf(23.7, 90.4, 6.0)
    }

    private fun save() {
        val fix = panel.fix
        if (fix == null) {
            if (!panel.gpsOn()) panel.refreshGps() else h.toast("GPS location not found yet. Please wait for GPS.")
            return
        }
        val acc = fix.accuracy.toDouble()
        val doSave = {
            Repo.saveLocation(c, existing, fix.latitude, fix.longitude, acc, "gps")
            h.toast("Location saved")
            h.pop()
        }
        val check = {
            if (acc > 50.0) {
                confirm("GPS is weak (\u00B1${acc.toInt()} m). Save anyway?", doSave)
            } else {
                doSave()
            }
        }
        val e = existing
        if (e != null) {
            confirm("This customer already has a location (saved by ${e.updatedBy}, ${fmtDate(e.updatedAt)}). Replace it?", check)
        } else {
            check()
        }
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(h).setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> yes() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun close() {
        panel.close()
    }
}
