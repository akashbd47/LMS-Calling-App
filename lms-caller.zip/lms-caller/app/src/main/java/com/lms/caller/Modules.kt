package com.lms.caller

import android.app.AlertDialog
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/* ================================================================== HOME (module launcher) */

class HomeScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val hello = h.label("", 22f, Color.WHITE, true)
    private val sub = h.label("", 12f, Color.parseColor("#CFE0FF"))
    private val listener: () -> Unit = { sub.text = Repo.status; hello.text = greeting() }

    private fun greeting(): String {
        val n = Prefs.userName(h)
        return if (n.isEmpty()) "Welcome" else "Welcome, $n"
    }

    private class Module(val icon: Int, val title: String, val hint: String, val c1: Int, val c2: Int, val open: () -> Unit)

    init {
        root.setBackgroundColor(C.bg)

        val top = h.hbox()
        top.gravity = Gravity.CENTER_VERTICAL
        val r = h.dp(26).toFloat()
        top.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(C.dark, C.primary)
        ).apply { cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r) }
        top.elevation = h.dp(4).toFloat()
        top.setPadding(h.dp(20), h.dp(18), h.dp(12), h.dp(20))
        val logo = android.widget.ImageView(h)
        logo.setImageResource(R.drawable.logo)
        top.addView(logo, LinearLayout.LayoutParams(h.dp(52), h.dp(52)).apply { rightMargin = h.dp(14) })
        val col = h.vbox()
        col.addView(h.label("KB LMS", 11f, Color.parseColor("#93C5FD"), true))
        hello.maxLines = 1
        hello.ellipsize = android.text.TextUtils.TruncateAt.END
        sub.maxLines = 1
        sub.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(hello, h.lp(2))
        col.addView(sub, h.lp(2))
        top.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sync = h.icon(R.drawable.ic_sync, Color.WHITE, 22)
        sync.setPadding(h.dp(10), h.dp(10), h.dp(10), h.dp(10))
        sync.background = h.ripple(h.shape(Color.parseColor("#33FFFFFF"), 24), 24)
        sync.setOnClickListener {
            Repo.refreshLoans(true)
            h.toast("Refreshing...")
        }
        top.addView(sync, LinearLayout.LayoutParams(h.dp(44), h.dp(44)))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val items = listOf(
            Module(R.drawable.ic_people, "Customers", "Customers List", Color.parseColor("#3B82F6"), Color.parseColor("#1D4ED8")) { h.select(HomeActivity.CUSTOMERS) },
            Module(R.drawable.ic_flag, "CL / WCL", "CL, WCL List", Color.parseColor("#F59E0B"), Color.parseColor("#EA580C")) { h.select(HomeActivity.LISTS) },
            Module(R.drawable.ic_chart, "Summary", "Due & Overdue", Color.parseColor("#22C55E"), Color.parseColor("#15803D")) { h.select(HomeActivity.SUMMARY) },
            Module(R.drawable.ic_alarm, "Overdue", "Overdue List", Color.parseColor("#EF4444"), Color.parseColor("#B91C1C")) { h.select(HomeActivity.OVERDUE) },
            Module(R.drawable.ic_info, "Monitoring", "Promise Date", Color.parseColor("#EAB308"), Color.parseColor("#A16207")) { h.select(HomeActivity.MONITOR) },
            Module(R.drawable.ic_calendar, "Reschedule", "Reschedule List", Color.parseColor("#A855F7"), Color.parseColor("#7E22CE")) { h.select(HomeActivity.RESCHEDULE) },
            Module(R.drawable.ic_pin, "Location", "Saved Locations", Color.parseColor("#EC4899"), Color.parseColor("#BE185D")) { h.select(HomeActivity.LOCATION) },
            Module(R.drawable.ic_map, "Map", "Customer Map", Color.parseColor("#14B8A6"), Color.parseColor("#0F766E")) { h.select(HomeActivity.MAP) },
            Module(R.drawable.ic_person_add, "New Customer", "Home Visit", Color.parseColor("#0EA5E9"), Color.parseColor("#0369A1")) { h.select(HomeActivity.NEWCUST) },
            Module(R.drawable.ic_phone, "Caller", "Call Listener", Color.parseColor("#6366F1"), Color.parseColor("#4338CA")) { h.openCaller() }
        )
        // Rows of 3, 3, 2, 2 cards; fixed card height, so all modules fit one screen without scrolling.
        val grid = h.vbox()
        grid.setPadding(h.dp(10), h.dp(10), h.dp(10), h.dp(8))
        var i = 0
        for (n in intArrayOf(3, 3, 2, 2)) {
            val row = h.hbox()
            for (k in 0 until n) {
                row.addView(card(items[i + k]), LinearLayout.LayoutParams(0, MATCH, 1f).apply { setMargins(h.dp(5), h.dp(5), h.dp(5), h.dp(5)) })
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH, h.dp(104)))
            i += n
        }
        root.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(devCard(), LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(h.dp(14), h.dp(2), h.dp(14), h.dp(12)) })
        listener()
        Repo.addListener(listener)
    }

    /** Developer credit at the bottom of the Home page. */
    private fun devCard(): View {
        val card = h.hbox()
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = h.shape(Color.WHITE, 18, C.line)
        card.elevation = h.dp(3).toFloat()
        card.setPadding(h.dp(12), h.dp(12), h.dp(12), h.dp(12))

        val bar = View(h)
        bar.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#1D4ED8"), Color.parseColor("#22C55E"))
        ).apply { cornerRadius = h.dp(3).toFloat() }
        card.addView(bar, LinearLayout.LayoutParams(h.dp(4), MATCH).apply { rightMargin = h.dp(12) })

        val col = h.vbox()
        val cap = h.label("THIS SOFTWARE DEVELOPED BY", 9.5f, C.muted, true)
        cap.letterSpacing = 0.08f
        col.addView(cap)
        val nameRow = h.hbox()
        nameRow.gravity = Gravity.CENTER_VERTICAL
        nameRow.addView(h.label("Md. Golam Rosul", 16f, Color.parseColor("#0F2A5F"), true))
        val gpf = h.pill("GPF-2361", C.primary)
        gpf.maxLines = 1
        nameRow.addView(gpf, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(8) })
        col.addView(nameRow, h.lp(3))
        val cr = h.hbox()
        cr.gravity = Gravity.CENTER_VERTICAL
        cr.addView(h.icon(R.drawable.ic_phone, C.ok, 14), LinearLayout.LayoutParams(h.dp(14), h.dp(14)).apply { rightMargin = h.dp(6) })
        cr.addView(h.label("Contact: ", 13f, C.muted))
        cr.addView(h.label("+8801893-264663", 13f, C.text, true))
        col.addView(cr, h.lp(4))
        card.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

        val call = h.icon(R.drawable.ic_phone, Color.WHITE, 20)
        call.setPadding(h.dp(12), h.dp(12), h.dp(12), h.dp(12))
        call.background = h.gradient(Color.parseColor("#22C55E"), Color.parseColor("#15803D"), 24)
        call.elevation = h.dp(2).toFloat()
        call.setOnClickListener {
            try {
                h.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:+8801893264663")))
            } catch (e: Exception) {
                h.toast("No dialer found")
            }
        }
        card.addView(call, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { leftMargin = h.dp(8) })
        return card
    }

    private fun card(m: Module): View {
        val c = h.vbox()
        c.gravity = Gravity.CENTER
        c.background = h.rippleOn(h.gradient(m.c1, m.c2, 20), 20)
        c.elevation = h.dp(3).toFloat()
        c.setPadding(h.dp(4), h.dp(4), h.dp(4), h.dp(4))
        val ic = h.icon(m.icon, Color.WHITE, 22)
        ic.setPadding(h.dp(10), h.dp(10), h.dp(10), h.dp(10))
        ic.background = h.shape(Color.parseColor("#33FFFFFF"), 22)
        c.addView(ic, LinearLayout.LayoutParams(h.dp(42), h.dp(42)))
        val t = h.label(m.title, 13f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        c.addView(t, h.lp(6, WRAP, WRAP))
        val hint = h.label(m.hint, 10f, Color.parseColor("#E0E7FF"))
        hint.gravity = Gravity.CENTER
        hint.maxLines = 1
        c.addView(hint, h.lp(1, WRAP, WRAP))
        c.isClickable = true
        c.setOnClickListener { m.open() }
        return c
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
    }
}

/* ================================================================== CL / WCL module */

class ListsScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "CL / WCL", Repo.status, { h.select(HomeActivity.HOME) })
    private val addBtn: ImageView
    private val search = SearchBox(h, "Search name, father, spouse, L/C no")
    private val count = h.label("", 13f, C.orange, true)
    private val tabWcl = h.label("", 14f, C.primary, true)
    private val tabCl = h.label("", 14f, C.primary, true)
    private val unionBar: UnionBar
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private var which = "WCL"
    private var rows: List<Cust> = emptyList()
    private var today = todayStart()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    private fun canEdit(): Boolean = Repo.can(if (which == "WCL") "wcl-edit" else "cl-edit")

    init {
        Repo.ensureLists()
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { refreshList() }
        header.addChip(unionBar.root)
        addBtn = header.action(h, R.drawable.ic_add) { addDialog() }
        header.action(h, R.drawable.ic_sync) {
            Repo.refreshLoans(true)
            h.toast("Refreshing...")
        }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        val seg = h.hbox()
        seg.background = h.shape(Color.WHITE, 14, C.line)
        seg.setPadding(h.dp(4), h.dp(4), h.dp(4), h.dp(4))
        for ((tv, key) in listOf(Pair(tabWcl, "WCL"), Pair(tabCl, "CL"))) {
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, h.dp(9), 0, h.dp(9))
            tv.isClickable = true
            tv.setOnClickListener { which = key; onData() }
            seg.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(seg, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(h.dp(12), h.dp(12), h.dp(12), 0) })
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))

        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(4), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    override fun onShow() {
        Repo.ensureLists()
    }

    private fun countIn(name: String): Int {
        val m = Repo.listMap(name)
        var n = 0
        for (c in Repo.loans) if (m.containsKey(c.id) && Repo.unionOk(c.union)) n++
        return n
    }

    private fun paintTab(tv: TextView, on: Boolean) {
        tv.setTextColor(if (on) Color.WHITE else C.primary)
        tv.background = if (on) h.gradient(C.primary, C.dark, 10) else null
    }

    private fun onData() {
        header.sub.text = Repo.status
        unionBar.refresh()
        tabWcl.text = "WCL  (" + countIn("WCL") + ")"
        tabCl.text = "CL  (" + countIn("CL") + ")"
        paintTab(tabWcl, which == "WCL")
        paintTab(tabCl, which == "CL")
        addBtn.gone(!canEdit())
        refreshList()
    }

    private fun refreshList() {
        val m = Repo.listMap(which)
        val q = search.edit.text.toString().trim().lowercase()
        val out = ArrayList<Cust>()
        for (c in Repo.loans) {
            if (!m.containsKey(c.id) || !Repo.unionOk(c.union)) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) || c.sCase.contains(q))) continue
            out.add(c)
        }
        out.sortWith(compareBy<Cust>({ if (it.overdue > 0L) 0 else 1 }, { it.overdue }, { it.sName }))
        var bal = 0.0
        for (c in out) bal += c.balance
        count.text = "${out.size} customers  \u2022  ${money(bal)}"
        rows = out
        today = todayStart()
        recycler.adapter?.notifyDataSetChanged()
    }

    /* ---- add dialog ---- */

    private fun addDialog() {
        if (!canEdit()) { h.toast("You do not have permission to edit $which"); return }
        val progs = LinkedHashMap<String, String>()
        for (c in Repo.loans) if (c.prog.isNotEmpty() && !progs.containsKey(c.prog)) progs[c.prog] = c.progName
        if (progs.isEmpty()) { h.toast("Loan data is not loaded yet"); return }
        val codes = progs.keys.sortedWith(compareBy<String>({ it.toLongOrNull() ?: Long.MAX_VALUE }, { it }))
        val labels = codes.map { if (!progs[it].isNullOrEmpty()) "$it - ${progs[it]}" else it }

        val col = h.vbox()
        col.setPadding(h.dp(20), h.dp(8), h.dp(20), h.dp(4))
        col.addView(h.label("Programme", 12f, C.muted))
        val sp = Spinner(h)
        sp.adapter = ArrayAdapter(h, android.R.layout.simple_spinner_dropdown_item, labels)
        col.addView(sp, h.lp(2))
        col.addView(h.label("L/C No", 12f, C.muted), h.lp(12))
        val lc = h.field("Loan case number", InputType.TYPE_CLASS_TEXT)
        col.addView(lc, h.lp(4))

        val dlg = AlertDialog.Builder(h)
            .setTitle("Add to $which")
            .setView(col)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Find", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val code = codes[sp.selectedItemPosition]
                val no = lc.text.toString().trim()
                if (no.isEmpty()) { h.toast("Enter the L/C number"); return@setOnClickListener }
                val c = Repo.loans.firstOrNull { it.prog == code && it.caseNo == no }
                if (c == null) {
                    h.toast("No loan found for programme $code, L/C $no")
                } else {
                    dlg.dismiss()
                    confirmAdd(c)
                }
            }
        }
        dlg.show()
    }

    private fun confirmAdd(c: Cust) {
        val already = Repo.listMap(which).containsKey(c.id)
        val msg = StringBuilder()
        msg.append(c.name)
        if (c.father.isNotEmpty()) msg.append("\nFather: ").append(c.father)
        val vu = listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString(" / ")
        if (vu.isNotEmpty()) msg.append("\n").append(vu)
        msg.append("\nProgramme: ").append(c.progLabel).append("  \u2022  L/C ").append(c.caseNo)
        msg.append("\nBalance: ").append(money(c.balance))
        if (already) msg.append("\n\nAlready in the $which list.")
        val b = AlertDialog.Builder(h).setTitle(if (already) "Already added" else "Add to $which?").setMessage(msg.toString())
        if (already) {
            b.setPositiveButton("OK", null)
        } else {
            b.setNegativeButton("Cancel", null)
            b.setPositiveButton("Add") { _, _ -> Repo.addToList(which, c) }
        }
        b.show()
    }

    private fun needMoreDialog(c: Cust) {
        val cur = Repo.wcl[c.id]?.needMore
        val et = h.field("Amount", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        if (cur != null) {
            et.setText(if (cur == Math.floor(cur)) cur.toLong().toString() else cur.toString())
            et.setSelection(et.text.length)
        }
        val wrap = h.vbox()
        wrap.setPadding(h.dp(20), h.dp(8), h.dp(20), h.dp(4))
        wrap.addView(et)
        AlertDialog.Builder(h)
            .setTitle("Need More - ${c.name}")
            .setView(wrap)
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Clear") { _, _ -> Repo.setNeedMore(c.id, null) }
            .setPositiveButton("Save") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isEmpty()) Repo.setNeedMore(c.id, null)
                else {
                    val v = t.toDoubleOrNull()
                    if (v == null) h.toast("Invalid amount") else Repo.setNeedMore(c.id, v)
                }
            }
            .show()
    }

    private fun confirmRemove(c: Cust) {
        AlertDialog.Builder(h)
            .setTitle("Remove from $which?")
            .setMessage(c.name + "\nL/C " + c.caseNo)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove") { _, _ -> Repo.removeFromList(which, c.id) }
            .show()
    }

    /* ---- rows ---- */

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val avatar = h.avatar(44)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val badge = h.pill("", C.muted)
        val need = h.pill("", C.primary)
        val remove = h.pill("Remove", C.bad)
        val pills = h.hbox()
        val call: ImageView = h.icon(R.drawable.ic_phone, C.primary, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            root.gravity = Gravity.CENTER_VERTICAL
            root.addView(avatar, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { rightMargin = h.dp(12) })
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(1))
            for (p in listOf(badge, need, remove)) {
                p.maxLines = 1
                p.setSingleLine()
            }
            // "Need more" has its own full-width line above the overdue date, so it never wraps.
            col.addView(need, h.lp(8, WRAP, WRAP))
            pills.addView(badge)
            pills.addView(remove, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(6) })
            col.addView(pills, h.lp(6, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            root.addView(call, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(12), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            fun at(): Cust? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            r.setOnClickListener { at()?.let { Details.open(h, it, null) } }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.phone) } }
            vh.need.setOnClickListener { at()?.let { if (canEdit()) needMoreDialog(it) } }
            vh.remove.setOnClickListener { at()?.let { confirmRemove(it) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val c = rows[i]
            h.paintAvatar(v.avatar, c.name)
            v.name.text = c.name
            v.l2.text = listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            v.l2.gone(v.l2.text.isEmpty())
            v.l3.text = "L/C ${c.caseNo}  \u2022  ${c.prog}  \u2022  Balance ${money(c.balance)}"
            v.call.gone(c.phone.isBlank())
            if (c.overdue > 0L) {
                v.badge.visibility = View.VISIBLE
                val late = c.overdue <= today
                v.badge.text = (if (late) "Overdue  " else "Next  ") + fmtDate(c.overdue)
                val col = if (late) C.bad else C.muted
                v.badge.setTextColor(col)
                v.badge.background = h.shape((col and 0xFFFFFF) or 0x1F000000, 20)
            } else {
                v.badge.visibility = View.GONE
            }
            if (which == "WCL") {
                v.need.visibility = View.VISIBLE
                val nm = Repo.wcl[c.id]?.needMore
                v.need.text = if (nm != null) "Need more: " + money(nm) else if (canEdit()) "Need more: set" else "Need more: -"
            } else {
                v.need.visibility = View.GONE
            }
            v.remove.gone(!canEdit())
            v.pills.gone(v.badge.visibility == View.GONE && v.remove.visibility == View.GONE)
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}

/* ================================================================== Summary module */

class SummaryScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "My Summary", Repo.status, { h.select(HomeActivity.HOME) })
    private val body = h.vbox()
    private val unionBar: UnionBar
    private val listener: () -> Unit = { onData() }

    init {
        Repo.ensureLists()
        root.setBackgroundColor(C.bg)
        header.action(h, R.drawable.ic_sync) {
            Repo.refreshLoans(true)
            h.toast("Refreshing...")
        }
        unionBar = UnionBar(h, true) { onData() }
        header.addChip(unionBar.root)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        val sv = ScrollView(h)
        sv.isVerticalScrollBarEnabled = false
        body.setPadding(h.dp(12), h.dp(8), h.dp(12), h.dp(24))
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        Repo.addListener(listener)
        onData()
    }

    override fun onShow() {
        Repo.ensureLists()
        onData()
    }

    private class Stat(var n: Int = 0, var a: Double = 0.0) {
        fun add(x: Double) { n++; a += x }
    }

    private fun onData() {
        header.sub.text = Repo.status
        unionBar.refresh()
        val t = todayStart()
        val all = Stat(); val over = Stat(); val only = Stat()
        val wcl = Stat(); val cl = Stat(); val rs = Stat()
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            all.add(c.balance)
            if (c.overdue > 0L && c.overdue <= t) over.add(c.balance)
            else if (c.due > 0.0) only.add(c.due)
            if (Repo.wcl.containsKey(c.id)) wcl.add(c.balance)
            if (Repo.cl.containsKey(c.id)) cl.add(c.balance)
            if (c.rs) rs.add(c.balance)
        }
        val dueN = over.n + only.n
        val dueA = over.a + only.a
        val pct = if (all.a > 0.0) dueA / all.a * 100.0 else 0.0

        body.removeAllViews()

        val hero = h.vbox()
        hero.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(C.dark, C.primary)
        ).apply { cornerRadius = h.dp(20).toFloat() }
        hero.elevation = h.dp(3).toFloat()
        hero.setPadding(h.dp(20), h.dp(18), h.dp(20), h.dp(18))
        hero.addView(h.label("TOTAL DUE", 12f, Color.parseColor("#CFE0FF"), true))
        hero.addView(h.label(money(dueA), 30f, Color.WHITE, true), h.lp(4))
        val line = h.hbox()
        line.addView(h.label("$dueN loans", 14f, Color.WHITE, true))
        line.addView(h.label("   \u2022   " + String.format(java.util.Locale.US, "%.1f", pct) + "% of balance", 14f, Color.parseColor("#CFE0FF")))
        hero.addView(line, h.lp(6, WRAP, WRAP))
        body.addView(hero, h.lp(4))

        val tiles = listOf(
            Triple("OVERDUE", over, C.bad),
            Triple("ONLY DUE", only, C.warn),
            Triple("RESCHEDULE", rs, C.violet),
            Triple("WCL", wcl, C.orange),
            Triple("CL", cl, C.teal),
            Triple("ALL LOANS", all, C.primary)
        )
        var i = 0
        while (i < tiles.size) {
            val row = h.hbox()
            row.gravity = Gravity.TOP
            for (k in 0..1) {
                val (title, st, col) = tiles[i + k]
                row.addView(
                    statCard(title, st, col),
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                        if (k == 0) rightMargin = h.dp(6) else leftMargin = h.dp(6)
                    }
                )
            }
            body.addView(row, h.lp(12))
            i += 2
        }
        val note = h.label(
            "Overdue = overdue date today or earlier (amount = balance).  Only Due = instalment due but not overdue (amount = due).  " +
                "Total Due = Overdue + Only Due.  Reschedule, WCL and CL show balance.",
            11f, C.muted
        )
        body.addView(note, h.lp(14))
    }

    private fun statCard(title: String, st: Stat, color: Int): View {
        val c = h.vbox()
        c.background = h.shape(Color.WHITE, 16, C.line)
        c.elevation = h.dp(1).toFloat()
        c.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(14))
        val bar = View(h)
        bar.background = h.shape(color, 3)
        c.addView(bar, LinearLayout.LayoutParams(h.dp(28), h.dp(4)))
        c.addView(h.label(title, 11f, color, true), h.lp(8))
        c.addView(h.label(st.n.toString(), 28f, C.text, true), h.lp(2))
        c.addView(h.label(money(st.a), 13f, C.muted), h.lp(0))
        return c
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
    }
}
