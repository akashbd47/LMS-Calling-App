package com.lms.caller

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Write Off module: every LoanMonthlyData loan whose LoanStatus contains "Write-Off".
 * The list is for monitoring, so each row shows the loan's last note (kept on the phone, no extra read).
 * Write-off loans are left out of Current Due, Overdue and the Summary figures.
 */
class WriteOffScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val rose = Color.parseColor("#BE123C")
    private val header = Header(h, "Write Off Loans", "Last note of each loan", { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, L/C no, phone")
    private val count = h.label("", 13f, rose, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private var rows: List<Cust> = emptyList()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { onData() }

    init {
        Repo.ensureLists()
        Repo.ensureNotes()
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { onData() }
        header.addChip(unionBar.root)
        header.action(h, R.drawable.ic_sync) {
            Repo.refreshLoans(true)
            h.toast("Refreshing...")
        }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))
        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(4), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    override fun onShow() {
        Repo.ensureLists()
        Repo.ensureNotes()
        onData()
    }

    private fun onData() {
        unionBar.refresh()
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Cust>()
        var bal = 0.0
        for (c in Repo.loans) {
            if (!c.writeOff || !Repo.unionOk(c.union)) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) ||
                    c.sCase.contains(q) || (digits.isNotEmpty() && c.sPhone.contains(digits)))) continue
            out.add(c)
            bal += c.balance
        }
        // loans without a note first, then the oldest last note first (they need a visit / a new note)
        out.sortWith(compareBy<Cust>({ Repo.lastNotes[it.id]?.at ?: 0L }, { it.sName }))
        count.text = if (out.isEmpty()) "No write-off loans" else "${out.size} write-off loans  \u2022  Balance ${money(bal)}"
        rows = out
        recycler.adapter?.notifyDataSetChanged()
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val stripe = View(h)
        val avatar = h.avatar(44)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val noteBox = h.vbox()
        val note = h.label("", 13.5f, C.text)
        val meta = h.label("", 11f, C.muted)
        val promise = h.pill("", C.primary)
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            note.maxLines = 3
            note.ellipsize = TextUtils.TruncateAt.END
            meta.maxLines = 1
            meta.ellipsize = TextUtils.TruncateAt.END
            promise.maxLines = 1
            promise.setSingleLine()
            root.gravity = Gravity.CENTER_VERTICAL
            root.addView(stripe, LinearLayout.LayoutParams(h.dp(4), MATCH).apply { rightMargin = h.dp(10); topMargin = h.dp(1); bottomMargin = h.dp(1) })
            root.addView(avatar, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { rightMargin = h.dp(12) })
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(2))
            noteBox.background = h.shape(Color.parseColor("#F8FAFC"), 12, C.line)
            noteBox.setPadding(h.dp(10), h.dp(8), h.dp(10), h.dp(8))
            noteBox.addView(note)
            noteBox.addView(meta, h.lp(3))
            col.addView(noteBox, h.lp(8))
            col.addView(promise, h.lp(8, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            root.addView(call, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(10), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            fun at(): Cust? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            r.setOnClickListener { at()?.let { Details.open(h, it, null) } }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.phone) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val c = rows[i]
            val n = Repo.lastNotes[c.id]
            h.paintAvatar(v.avatar, c.name)
            v.stripe.background = h.shape(rose, 3)
            v.name.text = c.name
            v.l2.text = listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            v.l2.gone(v.l2.text.isEmpty())
            v.l3.text = "L/C ${c.caseNo}  \u2022  ${c.progLabel}  \u2022  Balance ${money(c.balance)}"
            val txt = n?.text.orEmpty()
            if (txt.isEmpty()) {
                v.note.text = if (Repo.notesLoaded) "No note yet" else "Loading note..."
                v.note.setTextColor(C.muted)
                v.meta.gone(true)
            } else {
                v.note.text = txt
                v.note.setTextColor(C.text)
                val m = listOf(n?.by.orEmpty(), fmtDateTime(n?.at ?: 0L)).filter { it.isNotEmpty() && it != "-" }.joinToString("  \u2022  ")
                v.meta.text = m
                v.meta.gone(m.isEmpty())
            }
            val pr = n?.promise.orEmpty()
            if (pr.isEmpty()) {
                v.promise.gone(true)
            } else {
                v.promise.gone(false)
                v.promise.text = "Promise  " + fmtPromise(pr)
                v.promise.setTextColor(C.primary)
                v.promise.background = h.shape((C.primary and 0xFFFFFF) or 0x1F000000, 20)
            }
            v.call.gone(c.phone.isBlank())
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
