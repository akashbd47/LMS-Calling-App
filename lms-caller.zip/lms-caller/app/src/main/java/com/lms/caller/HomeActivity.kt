package com.lms.caller

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.maplibre.android.maps.MapView

interface Screen {
    val view: View
    fun onShow() {}
    fun onDestroy() {}
}

class HomeActivity : Activity() {

    private lateinit var content: FrameLayout
    private lateinit var overlayHost: FrameLayout
    private val screens = arrayOfNulls<Screen>(3)
    private val navIcons = ArrayList<ImageView>()
    private val navTexts = ArrayList<TextView>()
    private var tab = 0

    private val overlays = ArrayList<Pair<View, (() -> Unit)?>>()
    private val maps = ArrayList<MapView>()
    private var started = false
    private var resumed = false
    private var pendingPerm: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Prefs.config(this) == null || Prefs.userId(this).isEmpty()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        org.maplibre.android.MapLibre.getInstance(this)
        window.statusBarColor = C.dark
        Repo.start(this)

        val root = FrameLayout(this)
        val page = vbox()
        page.setBackgroundColor(C.bg)
        content = FrameLayout(this)
        page.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        page.addView(buildNav(), LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))
        overlayHost = FrameLayout(this)
        root.addView(overlayHost, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        select(0)
    }

    /* ---------------- bottom navigation ---------------- */

    private fun buildNav(): View {
        val bar = hbox()
        bar.setBackgroundColor(Color.WHITE)
        bar.elevation = dp(8).toFloat()
        bar.setPadding(0, dp(6), 0, dp(6))
        val items = listOf(
            Triple(R.drawable.ic_people, "Customers", 0),
            Triple(R.drawable.ic_pin, "Location", 1),
            Triple(R.drawable.ic_map, "Map", 2),
            Triple(R.drawable.ic_phone, "Caller", 3)
        )
        for ((res, name, idx) in items) {
            val col = vbox()
            col.gravity = Gravity.CENTER
            col.setPadding(0, dp(4), 0, dp(4))
            val ic = icon(res, C.muted, 24)
            val tx = label(name, 11f, C.muted, true)
            tx.gravity = Gravity.CENTER
            col.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            col.addView(tx, lp(2))
            col.isClickable = true
            col.setOnClickListener {
                if (idx == 3) {
                    startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_STATUS, true))
                } else {
                    select(idx)
                }
            }
            navIcons.add(ic)
            navTexts.add(tx)
            bar.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return bar
    }

    fun select(i: Int) {
        tab = i
        var s = screens[i]
        if (s == null) {
            s = when (i) {
                0 -> CustomersScreen(this)
                1 -> LocationScreen(this)
                else -> MapScreen(this)
            }
            screens[i] = s
            content.addView(s.view, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        for (k in screens.indices) screens[k]?.view?.gone(k != i)
        for (k in navIcons.indices) {
            val on = k == i
            navIcons[k].setColorFilter(if (on) C.primary else C.muted)
            navTexts[k].setTextColor(if (on) C.primary else C.muted)
        }
        s.onShow()
    }

    /* ---------------- full-screen overlays (details, editors) ---------------- */

    fun push(v: View, onClose: (() -> Unit)? = null) {
        val w = FrameLayout(this)
        w.setBackgroundColor(C.bg)
        w.isClickable = true
        w.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        overlayHost.addView(w, FrameLayout.LayoutParams(MATCH, MATCH))
        overlays.add(Pair(w, onClose))
    }

    fun pop() {
        if (overlays.isEmpty()) return
        val (w, close) = overlays.removeAt(overlays.size - 1)
        try { close?.invoke() } catch (e: Exception) { }
        overlayHost.removeView(w)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            overlays.isNotEmpty() -> pop()
            tab != 0 -> select(0)
            else -> {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    /* ---------------- map lifecycle ---------------- */

    fun registerMap(mv: MapView) {
        maps.add(mv)
        mv.onCreate(null)
        if (started) mv.onStart()
        if (resumed) mv.onResume()
    }

    fun unregisterMap(mv: MapView) {
        if (!maps.remove(mv)) return
        if (resumed) mv.onPause()
        if (started) mv.onStop()
        mv.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        started = true
        for (m in maps) m.onStart()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        for (m in maps) m.onResume()
    }

    override fun onPause() {
        resumed = false
        for (m in maps) m.onPause()
        super.onPause()
    }

    override fun onStop() {
        started = false
        for (m in maps) m.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        for (m in maps) m.onLowMemory()
    }

    override fun onDestroy() {
        while (overlays.isNotEmpty()) pop()
        for (s in screens) s?.onDestroy()
        for (m in maps.toList()) unregisterMap(m)
        super.onDestroy()
    }

    /* ---------------- permissions ---------------- */

    fun needLocation(cb: (Boolean) -> Unit) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            cb(true)
            return
        }
        pendingPerm = cb
        requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 21)
    }

    fun needCall(cb: (Boolean) -> Unit) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            cb(true)
            return
        }
        pendingPerm = cb
        requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 22)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        val cb = pendingPerm
        pendingPerm = null
        if (cb == null) return
        val ok = when (code) {
            21 -> checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            else -> checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        }
        cb(ok)
    }
}
