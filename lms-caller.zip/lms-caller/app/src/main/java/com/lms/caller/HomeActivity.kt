package com.lms.caller

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.maplibre.android.maps.MapView

interface Screen {
    val view: View
    fun onShow() {}
    fun onDestroy() {}
}

class HomeActivity : Activity() {

    private lateinit var content: FrameLayout
    private lateinit var overlayHost: FrameLayout
    private val screens = arrayOfNulls<Screen>(10)
    private var tab = HOME

    companion object {
        const val HOME = 0
        const val CUSTOMERS = 1
        const val LOCATION = 2
        const val MAP = 3
        const val LISTS = 4
        const val SUMMARY = 5
        const val RESCHEDULE = 6
        const val NEWCUST = 7
        const val MONITOR = 8
        const val OVERDUE = 9
    }

    private val overlays = ArrayList<Pair<View, (() -> Unit)?>>()
    private val maps = ArrayList<MapView>()
    private var started = false
    private var resumed = false
    private var pendingPerm: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Prefs.config(this) == null || Prefs.userId(this).isEmpty()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        org.maplibre.android.MapLibre.getInstance(this)
        window.statusBarColor = C.dark
        Repo.start(this)

        val root = FrameLayout(this)
        val page = vbox()
        page.setBackgroundColor(C.bg)
        content = FrameLayout(this)
        page.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))
        overlayHost = FrameLayout(this)
        root.addView(overlayHost, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        select(HOME)
    }

    /* ---------------- module navigation (Home is the launcher) ---------------- */

    fun openCaller() {
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_STATUS, true))
    }

    fun select(i: Int) {
        tab = i
        var s = screens[i]
        if (s == null) {
            s = when (i) {
                HOME -> HomeScreen(this)
                CUSTOMERS -> CustomersScreen(this)
                LOCATION -> LocationScreen(this)
                MAP -> MapScreen(this)
                LISTS -> ListsScreen(this)
                RESCHEDULE -> RescheduleScreen(this)
                NEWCUST -> NewCustomerScreen(this)
                MONITOR -> MonitoringScreen(this)
                OVERDUE -> OverdueScreen(this)
                else -> SummaryScreen(this)
            }
            screens[i] = s
            content.addView(s.view, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        for (k in screens.indices) screens[k]?.view?.gone(k != i)
        s.onShow()
    }

    /* ---------------- full-screen overlays (details, editors) ---------------- */

    fun push(v: View, onClose: (() -> Unit)? = null) {
        val w = FrameLayout(this)
        w.setBackgroundColor(C.bg)
        w.isClickable = true
        w.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        overlayHost.addView(w, FrameLayout.LayoutParams(MATCH, MATCH))
        overlays.add(Pair(w, onClose))
    }

    fun pop() {
        if (overlays.isEmpty()) return
        val (w, close) = overlays.removeAt(overlays.size - 1)
        try { close?.invoke() } catch (e: Exception) { }
        overlayHost.removeView(w)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            overlays.isNotEmpty() -> pop()
            tab != HOME -> select(HOME)
            else -> {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    /* ---------------- map lifecycle ---------------- */

    fun registerMap(mv: MapView) {
        maps.add(mv)
        mv.onCreate(null)
        if (started) mv.onStart()
        if (resumed) mv.onResume()
    }

    fun unregisterMap(mv: MapView) {
        if (!maps.remove(mv)) return
        if (resumed) mv.onPause()
        if (started) mv.onStop()
        mv.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        started = true
        for (m in maps) m.onStart()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        CallService.ensure(this)
        Repo.autoSyncCheck()
        for (m in maps) m.onResume()
    }

    override fun onPause() {
        resumed = false
        for (m in maps) m.onPause()
        super.onPause()
    }

    override fun onStop() {
        started = false
        for (m in maps) m.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        for (m in maps) m.onLowMemory()
    }

    override fun onDestroy() {
        while (overlays.isNotEmpty()) pop()
        for (s in screens) s?.onDestroy()
        for (m in maps.toList()) unregisterMap(m)
        super.onDestroy()
    }

    /* ---------------- permissions ---------------- */

    fun needLocation(cb: (Boolean) -> Unit) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            cb(true)
            return
        }
        pendingPerm = cb
        requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 21)
    }

    fun needCall(cb: (Boolean) -> Unit) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            cb(true)
            return
        }
        pendingPerm = cb
        requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 22)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        val cb = pendingPerm
        pendingPerm = null
        if (cb == null) return
        val ok = when (code) {
            21 -> checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            else -> checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        }
        cb(ok)
    }
}
