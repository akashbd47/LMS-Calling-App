package com.lms.caller

import android.app.AlertDialog
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Pending Loan = the web app's "Date Pending" list (collection LoanEntries, status "Date Pending"):
 * loans whose payment is recorded but the new loan is not decided yet. Mobile: call + delete only (no Set Date).
 */
class PendingLoanScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "Pending Loan", "", { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, union, mobile, loan case")
    private val info = h.label("", 13f, C.orange, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private val chips = ArrayList<TextView>()
    private val types = arrayOf("All", "New but Old", "Revolving", "Pure New")
    private val colors = intArrayOf(Color.parseColor("#C2410C"), Color.parseColor("#2563EB"), Color.parseColor("#16A34A"), Color.parseColor("#7C3AED"))
    private var type = 0
    private val hidden = HashSet<String>()
    private var rows: List<LoanEntry> = emptyList()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    init {
        Repo.ensureEntries()
        root.setBackgroundColor(C.bg)
        header.sub.gone(true)
        unionBar = UnionBar(h, true) { onData() }
        header.addChip(unionBar.root)
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        val cr = h.hbox()
        cr.setPadding(h.dp(12), h.dp(10), h.dp(12), 0)
        for (i in types.indices) {
            val c = h.label(types[i], 13f, colors[i], true)
            c.setPadding(h.dp(14), h.dp(7), h.dp(14), h.dp(7))
            c.isClickable = true
            c.setOnClickListener { type = i; onData() }
            c.layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = h.dp(6) }
            chips.add(c)
            cr.addView(c)
        }
        val sv = HorizontalScrollView(h)
        sv.isHorizontalScrollBarEnabled = false
        sv.addView(cr)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, WRAP))

        val ir = h.hbox()
        ir.setPadding(h.dp(16), h.dp(8), h.dp(12), 0)
        ir.addView(info)
        root.addView(ir, LinearLayout.LayoutParams(MATCH, WRAP))

        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(2), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    override fun onShow() {
        Repo.ensureEntries()
    }

    private fun onData() {
        unionBar.refresh()
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val base = ArrayList<LoanEntry>()
        for (e in Repo.entries.values) {
            if (e.id in hidden || !Repo.unionOk(e.union)) continue
            if (q.isNotEmpty() && !(e.name.lowercase().contains(q) || e.union.lowercase().contains(q) ||
                    e.oldLC.lowercase().contains(q) || e.oldProg.lowercase().contains(q) ||
                    (digits.isNotEmpty() && e.mobile.contains(digits)))) continue
            base.add(e)
        }
        for (i in types.indices) {
            val n = if (i == 0) base.size else base.count { it.type == types[i] }
            val on = i == type
            chips[i].text = types[i] + " (" + n + ")"
            chips[i].setTextColor(if (on) Color.WHITE else colors[i])
            chips[i].background = if (on) h.gradient(colors[i], colors[i], 20) else h.shape(Color.WHITE, 20, C.line)
            chips[i].elevation = h.dp(if (on) 3 else 1).toFloat()
        }
        val list = base.filter { type == 0 || it.type == types[type] }
            .sortedWith(compareBy<LoanEntry>({ it.union.lowercase() }, { it.name.lowercase() }))
        info.text = when {
            !Repo.canPending("view") -> "You do not have permission to view Pending Loan"
            !Repo.entriesLoaded -> "Loading..."
            list.isEmpty() -> "No pending loans"
            else -> "${list.size} pending loans"
        }
        rows = if (Repo.canPending("view")) list else emptyList()
        recycler.adapter?.notifyDataSetChanged()
    }

    private fun typeColor(t: String): Int = when (t) {
        types[1] -> colors[1]
        types[2] -> colors[2]
        types[3] -> colors[3]
        else -> C.muted
    }

    private fun confirmDelete(e: LoanEntry) {
        val msg = StringBuilder(e.name)
        if (e.union.isNotEmpty()) msg.append("\n").append(e.union)
        msg.append("\n").append(e.type)
        if (e.type != types[3] && e.oldProg.isNotEmpty()) msg.append("\nOld: ").append(e.oldProg).append("  \u2022  Loan Case ").append(e.oldLC)
        msg.append("\n\nThis entry will be deleted for good (the loan will not be disbursed). It cannot be brought back.")
        AlertDialog.Builder(h)
            .setTitle("Delete entry?")
            .setMessage(msg.toString())
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                hidden.add(e.id)
                refreshList()
                Repo.deleteEntry(e.id) { ok, m ->
                    hidden.remove(e.id)
                    if (ok) h.toast("Deleted: " + e.name) else h.toast(m)
                    refreshList()
                }
            }
            .show()
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val stripe = View(h)
        val avatar = h.avatar(44)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val type = h.pill("", C.muted)
        val paid = h.pill("", C.muted)
        val del = h.pill("Delete", C.bad)
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            for (p in listOf(type, paid, del)) {
                p.maxLines = 1
                p.setSingleLine()
            }
            root.gravity = Gravity.CENTER_VERTICAL
            root.addView(stripe, LinearLayout.LayoutParams(h.dp(4), MATCH).apply { rightMargin = h.dp(10); topMargin = h.dp(1); bottomMargin = h.dp(1) })
            root.addView(avatar, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { rightMargin = h.dp(12) })
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(1))
            val pills = h.hbox()
            pills.gravity = Gravity.CENTER_VERTICAL
            pills.addView(type)
            pills.addView(paid, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(6) })
            pills.addView(del, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(6) })
            col.addView(pills, h.lp(8, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            root.addView(call, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.shape(Color.WHITE, 16, C.line)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(10), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            val vh = VH(r)
            fun at(): LoanEntry? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.mobile) } }
            vh.del.setOnClickListener { at()?.let { confirmDelete(it) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val e = rows[i]
            val col = typeColor(e.type)
            h.paintAvatar(v.avatar, e.name)
            v.stripe.background = h.shape(col, 3)
            v.name.text = e.name.ifEmpty { "-" }
            v.l2.text = e.union
            v.l2.gone(e.union.isEmpty())
            val l3 = ArrayList<String>()
            if (e.type != types[3] && (e.oldProg.isNotEmpty() || e.oldLC.isNotEmpty())) l3.add(e.oldProg + "  \u2022  Loan Case " + e.oldLC)
            if (e.mobile.isNotEmpty()) l3.add(e.mobile)
            v.l3.text = l3.joinToString("   ")
            v.l3.gone(l3.isEmpty())
            v.type.text = e.type
            v.type.setTextColor(col)
            v.type.background = h.shape((col and 0xFFFFFF) or 0x1F000000, 20)
            if (e.paidMs > 0L && e.type != types[3]) {
                v.paid.visibility = View.VISIBLE
                v.paid.text = "Paid " + fmtDmy(e.paidMs)
                v.paid.setTextColor(C.muted)
                v.paid.background = h.shape(Color.parseColor("#F1F5F9"), 20)
            } else {
                v.paid.visibility = View.GONE
            }
            v.del.gone(!Repo.canPending("edit"))
            v.call.gone(e.mobile.isEmpty())
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
