package com.lms.caller

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object C {
    val primary = Color.parseColor("#1D4ED8")
    val dark = Color.parseColor("#1E3A8A")
    val bg = Color.parseColor("#F1F5F9")
    val text = Color.parseColor("#0F172A")
    val muted = Color.parseColor("#64748B")
    val ok = Color.parseColor("#16A34A")
    val bad = Color.parseColor("#DC2626")
    val warn = Color.parseColor("#D97706")
    val line = Color.parseColor("#E2E8F0")
    val soft = Color.parseColor("#EFF6FF")
    val violet = Color.parseColor("#7C3AED")
    val teal = Color.parseColor("#0891B2")
    val pink = Color.parseColor("#DB2777")
    val orange = Color.parseColor("#EA580C")
}

fun money(d: Double): String = "\u09F3 " + fmtAmt(d)

private val AVATAR_COLORS = intArrayOf(
    Color.parseColor("#2563EB"), Color.parseColor("#7C3AED"), Color.parseColor("#0891B2"), Color.parseColor("#DB2777"),
    Color.parseColor("#EA580C"), Color.parseColor("#16A34A"), Color.parseColor("#4F46E5"), Color.parseColor("#B45309")
)

/** Round letter badge (soft tinted circle, coloured letter); the colour comes from the name so it stays the same. */
fun Context.paintAvatar(tv: TextView, name: String) {
    val col = AVATAR_COLORS[(name.hashCode() and 0x7fffffff) % AVATAR_COLORS.size]
    val ch = name.trim().firstOrNull()?.toString()?.uppercase() ?: "?"
    tv.text = ch
    tv.setTextColor(col)
    tv.background = shape((col and 0xFFFFFF) or 0x22000000, 24)
}

fun Context.avatar(size: Int = 44): TextView = TextView(this).apply {
    textSize = 18f
    setTypeface(typeface, Typeface.BOLD)
    gravity = Gravity.CENTER
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
}

fun Context.gradient(c1: Int, c2: Int, radius: Int): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply { cornerRadius = dp(radius).toFloat() }

fun Context.rippleOn(base: GradientDrawable, radius: Int): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), base, shape(Color.WHITE, radius))

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.shape(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dp(radius).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.ripple(base: GradientDrawable, radius: Int): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(Color.parseColor("#22000000")), base, shape(Color.WHITE, radius))

fun Context.lp(top: Int = 0, w: Int = MATCH, h: Int = WRAP): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

fun Context.vbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

fun Context.label(t: String, size: Float = 15f, color: Int = C.text, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.icon(res: Int, tint: Int = C.primary, size: Int = 24): ImageView = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(tint)
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
}

fun Context.card(): LinearLayout = vbox().apply {
    background = shape(Color.WHITE, 16, C.line)
    setPadding(dp(16), dp(14), dp(16), dp(14))
    elevation = dp(1).toFloat()
}

fun Context.pill(t: String, color: Int, filled: Boolean = false): TextView = TextView(this).apply {
    text = t
    textSize = 12f
    setTypeface(typeface, Typeface.BOLD)
    if (filled) {
        setTextColor(Color.WHITE)
        background = shape(color, 20)
    } else {
        setTextColor(color)
        background = shape((color and 0xFFFFFF) or 0x1F000000, 20)
    }
    setPadding(dp(10), dp(4), dp(10), dp(4))
}

/** kind: 0 = primary, 1 = outline, 2 = danger outline, 3 = soft */
fun Context.btn(t: String, kind: Int = 0, iconRes: Int = 0, onClick: () -> Unit): LinearLayout {
    val row = hbox()
    row.gravity = Gravity.CENTER
    val fg = when (kind) {
        0 -> Color.WHITE
        2 -> C.bad
        else -> C.primary
    }
    val base = when (kind) {
        0 -> shape(C.primary, 12)
        1 -> shape(Color.WHITE, 12, C.primary)
        2 -> shape(Color.WHITE, 12, Color.parseColor("#FCA5A5"))
        else -> shape(C.soft, 12)
    }
    row.background = ripple(base, 12)
    row.setPadding(dp(16), 0, dp(16), 0)
    row.minimumHeight = dp(48)
    if (iconRes != 0) {
        row.addView(icon(iconRes, fg, 20), LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(8) })
    }
    row.addView(label(t, 15f, fg, true))
    row.isClickable = true
    row.setOnClickListener { onClick() }
    return row
}

fun Context.field(hint: String, kind: Int = InputType.TYPE_CLASS_TEXT): EditText = EditText(this).apply {
    this.hint = hint
    inputType = kind
    textSize = 15f
    setTextColor(C.text)
    setHintTextColor(C.muted)
    background = shape(Color.WHITE, 12, C.line)
    setPadding(dp(14), dp(12), dp(14), dp(12))
    setSingleLine()
}

/** Round icon button (used on top of the map). */
fun Context.fab(res: Int, tint: Int = C.primary, onClick: () -> Unit): ImageView = ImageView(this).apply {
    setImageResource(res)
    setColorFilter(tint)
    val p = dp(11)
    setPadding(p, p, p, p)
    background = shape(Color.WHITE, 24)
    elevation = dp(3).toFloat()
    isClickable = true
    setOnClickListener { onClick() }
}

/** Search box with a magnifier icon. Returns the container; the EditText is in [edit]. */
class SearchBox(ctx: Context, hint: String) {
    val edit: EditText = EditText(ctx)
    val root: LinearLayout = ctx.hbox()

    init {
        root.background = ctx.shape(Color.WHITE, 14)
        root.elevation = ctx.dp(3).toFloat()
        root.setPadding(ctx.dp(14), 0, ctx.dp(6), 0)
        root.addView(ctx.icon(R.drawable.ic_search, C.primary, 20))
        edit.hint = hint
        edit.textSize = 15f
        edit.setTextColor(C.text)
        edit.setHintTextColor(Color.parseColor("#94A3B8"))
        edit.background = null
        edit.setSingleLine()
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.setPadding(ctx.dp(10), ctx.dp(13), ctx.dp(10), ctx.dp(13))
        root.addView(edit, LinearLayout.LayoutParams(0, WRAP, 1f))
        val clear = ctx.icon(R.drawable.ic_close, C.muted, 18)
        clear.setPadding(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        clear.layoutParams = LinearLayout.LayoutParams(ctx.dp(32), ctx.dp(32))
        clear.setOnClickListener { edit.setText("") }
        root.addView(clear)
    }
}

/** Gradient header. [sub] can be updated later. The union chip and the search box live inside it (no extra rows below). */
class Header(private val ctx: Context, title: String, subText: String = "", onBack: (() -> Unit)? = null) {
    val root: LinearLayout = ctx.vbox()
    private val row: LinearLayout = ctx.hbox()
    val sub: TextView = ctx.label(subText, 12f, Color.parseColor("#CFE0FF"))
    val title: TextView = ctx.label(title, 18f, Color.WHITE, true)
    val actions: LinearLayout = ctx.hbox()

    init {
        val r = ctx.dp(22).toFloat()
        root.background = HeaderBg(r)
        root.elevation = ctx.dp(4).toFloat()
        root.setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(10), ctx.dp(11))
        if (onBack != null) {
            val b = ctx.icon(R.drawable.ic_back, Color.WHITE, 24)
            b.setOnClickListener { onBack() }
            row.addView(b, LinearLayout.LayoutParams(ctx.dp(24), ctx.dp(24)).apply { rightMargin = ctx.dp(12) })
        }
        this.title.maxLines = 1
        this.title.ellipsize = android.text.TextUtils.TruncateAt.END
        sub.maxLines = 1
        sub.ellipsize = android.text.TextUtils.TruncateAt.END
        val col = ctx.vbox()
        col.addView(this.title)
        col.addView(sub)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(actions)
        root.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    fun action(ctx: Context, res: Int, onClick: () -> Unit): ImageView {
        val v = ctx.icon(res, Color.WHITE, 22)
        v.setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        v.layoutParams = LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40))
        v.setOnClickListener { onClick() }
        actions.addView(v)
        return v
    }

    /** Puts a view (the compact union filter) at the left end of the header buttons. */
    fun addChip(v: View) {
        actions.addView(v, 0, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = ctx.dp(4) })
    }

    /** Search box inside the blue header. */
    fun addSearch(sb: SearchBox) {
        root.addView(sb.root, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(12); rightMargin = ctx.dp(6) })
    }
}

fun Context.toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

fun View.gone(g: Boolean) {
    visibility = if (g) View.GONE else View.VISIBLE
}

/** Soft, slightly blue shadow (the tinted colours work on Android 9+; older phones get the normal grey shadow). */
fun Context.softShadow(v: View, depthDp: Int) {
    v.elevation = dp(depthDp).toFloat()
    if (Build.VERSION.SDK_INT >= 28) {
        v.outlineSpotShadowColor = Color.parseColor("#661E3A8A")
        v.outlineAmbientShadowColor = Color.parseColor("#2E1E3A8A")
    }
}

/** Header background of every screen: deep blue gradient with two soft light-blue waves on the right. */
class HeaderBg(private val r: Float) : android.graphics.drawable.Drawable() {
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val wave = android.graphics.Path()
    private val clip = android.graphics.Path()

    override fun draw(c: android.graphics.Canvas) {
        val w = bounds.width().toFloat()
        val hh = bounds.height().toFloat()
        clip.reset()
        clip.addRoundRect(android.graphics.RectF(0f, 0f, w, hh), floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r), android.graphics.Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.shader = null
        p.alpha = 255
        p.shader = android.graphics.LinearGradient(
            0f, 0f, w, hh,
            intArrayOf(Color.parseColor("#071A4F"), Color.parseColor("#0E2D82"), Color.parseColor("#1D4ED8")),
            floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, hh, p)
        p.shader = null
        p.alpha = 255

        // big wave from the top edge down the right side
        wave.reset()
        wave.moveTo(w * 0.60f, 0f)
        wave.cubicTo(w * 0.74f, hh * 0.04f, w * 0.60f, hh * 0.50f, w * 0.80f, hh * 0.58f)
        wave.cubicTo(w * 0.92f, hh * 0.63f, w * 0.98f, hh * 0.40f, w * 1.02f, hh * 0.34f)
        wave.lineTo(w * 1.02f, 0f)
        wave.close()
        p.color = Color.parseColor("#4D2F63E8")
        c.drawPath(wave, p)

        // lower wave on the right
        wave.reset()
        wave.moveTo(w * 1.02f, hh * 0.46f)
        wave.cubicTo(w * 0.90f, hh * 0.52f, w * 0.84f, hh * 0.86f, w * 0.66f, hh * 1.02f)
        wave.lineTo(w * 1.02f, hh * 1.02f)
        wave.close()
        p.color = Color.parseColor("#403B82F6")
        c.drawPath(wave, p)
        c.restore()
    }

    override fun getOutline(outline: android.graphics.Outline) {
        outline.setRoundRect(bounds.left, bounds.top - r.toInt(), bounds.right, bounds.bottom, r)
        outline.alpha = 1f
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}

/** Slightly larger text everywhere (the Times-style font looks smaller than the system font at the same size). */
fun Context.withTextScale(): Context {
    val c = android.content.res.Configuration(resources.configuration)
    c.fontScale = c.fontScale * 1.1f
    return createConfigurationContext(c)
}
