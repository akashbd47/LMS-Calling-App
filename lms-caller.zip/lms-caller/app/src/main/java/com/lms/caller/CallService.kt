package com.lms.caller

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.app.ServiceCompat
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Transaction

/**
 * Listens to CallQueue/{userId}. When the web app writes status "Pending" this service
 * claims the request (once, in a transaction) and places ONE phone call.
 */
class CallService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var reg: ListenerRegistration? = null
    private var db: FirebaseFirestore? = null
    private var userId = ""
    private var wake: PowerManager.WakeLock? = null
    private var inFlight = false
    private var lastCallAt = 0L
    private var lastInfo = "Waiting for call requests"

    private val beat = object : Runnable {
        override fun run() {
            heartbeat()
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Call listener", NotificationManager.IMPORTANCE_LOW))
        val pm = getSystemService(PowerManager::class.java)
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lmscaller:listen").apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        userId = Prefs.userId(this)
        if (userId.isEmpty() || Prefs.config(this) == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        connect()
        handler.removeCallbacks(beat)
        handler.post(beat)
        return START_STICKY
    }

    override fun onDestroy() {
        reg?.remove()
        handler.removeCallbacksAndMessages(null)
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) { }
        super.onDestroy()
    }

    // ---------- notification ----------
    private fun notif(text: String): Notification =
        Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("LMS Caller - user $userId")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun goForeground() {
        val n = notif(lastInfo)
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun info(text: String) {
        lastInfo = text
        getSystemService(NotificationManager::class.java).notify(NID, notif(text))
    }

    // ---------- Firestore ----------
    private fun connect() {
        reg?.remove()
        val d = Fb.db(this)
        if (d == null) { stopSelf(); return }
        db = d
        reg = d.collection("CallQueue").document(userId).addSnapshotListener { snap, err ->
            if (err != null) {
                info("Connection problem, retrying...")
                handler.postDelayed({ connect() }, 15_000)
                return@addSnapshotListener
            }
            if (snap != null) onSnap(snap)
        }
        info("Waiting for call requests")
    }

    private fun heartbeat() {
        try { wake?.acquire(10 * 60 * 1000L) } catch (e: Exception) { }
        val d = db ?: return
        d.collection("CallDevices").document(userId).set(
            mapOf(
                "userId" to userId,
                "lastSeen" to FieldValue.serverTimestamp(),
                "device" to Build.MODEL,
                "app" to "1.0"
            ), SetOptions.merge()
        )
    }

    private fun onSnap(snap: DocumentSnapshot) {
        // Never act on cached data: only fresh server data may start a call.
        if (snap.metadata.isFromCache || snap.metadata.hasPendingWrites()) return
        if (!snap.exists() || snap.getString("status") != "Pending") return
        if (inFlight) return

        val d = db ?: return
        val ref = d.collection("CallQueue").document(userId)
        val number = snap.getString("number") ?: ""
        val ts = snap.getTimestamp("time")?.toDate()?.time ?: 0L
        val now = System.currentTimeMillis()
        val who = snap.getString("customerName") ?: number

        var verdict = "Received"
        var msg = "Calling"
        @Suppress("DEPRECATION")
        val callState = getSystemService(TelephonyManager::class.java).callState
        when {
            !Regex("^01\\d{9}$").matches(number) -> { verdict = "Failed"; msg = "Invalid phone number" }
            ts == 0L || now - ts > MAX_AGE_MS -> { verdict = "Expired"; msg = "Request too old, not called" }
            callState != TelephonyManager.CALL_STATE_IDLE -> { verdict = "Busy"; msg = "Phone is already on a call" }
            now - lastCallAt < COOLDOWN_MS -> { verdict = "Busy"; msg = "Please wait a few seconds" }
            checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ->
                { verdict = "Failed"; msg = "Call permission missing in phone" }
        }

        inFlight = true
        // Claim the request exactly once. If another listener/device already changed it, nothing happens.
        d.runTransaction(Transaction.Function<Boolean> { tx ->
            val s = tx.get(ref)
            val same = s.getString("status") == "Pending" && s.getTimestamp("time")?.toDate()?.time == ts
            if (!same) return@Function false
            tx.update(ref, mapOf(
                "status" to verdict, "message" to msg,
                "handledAt" to FieldValue.serverTimestamp(), "device" to Build.MODEL
            ))
            true
        }).addOnSuccessListener { claimed ->
            if (claimed && verdict == "Received") {
                placeCall(ref, number, who)
            } else {
                if (claimed) info("$verdict: $msg")
                inFlight = false
            }
        }.addOnFailureListener {
            info("Could not claim request (offline?)")
            inFlight = false
        }
    }

    private fun placeCall(ref: DocumentReference, number: String, who: String) {
        try {
            lastCallAt = System.currentTimeMillis()
            getSystemService(TelecomManager::class.java)
                .placeCall(Uri.fromParts("tel", number, null), Bundle())
            info("Calling $who")
        } catch (e: Exception) {
            lastCallAt = 0L
            ref.update(mapOf("status" to "Failed", "message" to (e.message ?: "Call failed")))
            info("Call failed: ${e.message}")
        } finally {
            inFlight = false
        }
    }

    companion object {
        private const val CH = "lms_caller"
        private const val NID = 41
        private const val MAX_AGE_MS = 60_000L
        private const val COOLDOWN_MS = 10_000L
    }
}
