package com.lms.caller

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Full-screen opening screen: the KB LMS logo flips in with a 3D rotation, tilts gently in space,
 * a light shine sweeps over it, then the app opens.
 */
class SplashActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var opened = false
    private var tilt: ValueAnimator? = null
    private val openApp = Runnable { next() }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 28) {
            val wlp = window.attributes
            wlp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = wlp
        }

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#06143A"), Color.parseColor("#0B2E7A"), Color.parseColor("#1D4ED8"))
        )

        // soft glow behind the logo
        val glow = View(this)
        glow.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(190).toFloat()
            colors = intArrayOf(Color.parseColor("#663B82F6"), Color.parseColor("#003B82F6"))
        }
        root.addView(glow, FrameLayout.LayoutParams(dp(380), dp(380), Gravity.CENTER).apply { bottomMargin = dp(70) })

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        root.addView(col, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // logo card (rounded, shadow, 3D)
        val card = FrameLayout(this)
        card.elevation = dp(28).toFloat()
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.width * 0.13f)
            }
        }
        card.clipToOutline = true
        card.cameraDistance = 9000f * d
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        card.addView(logo, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val shine = View(this)
        shine.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#00FFFFFF"), Color.parseColor("#80FFFFFF"), Color.parseColor("#00FFFFFF"))
        )
        shine.rotation = 18f
        shine.alpha = 0f
        card.addView(shine, FrameLayout.LayoutParams(dp(70), dp(340), Gravity.START or Gravity.CENTER_VERTICAL))
        col.addView(card, LinearLayout.LayoutParams(dp(210), dp(210)))

        val title = TextView(this)
        title.text = "KB LMS"
        title.textSize = 30f
        title.setTextColor(Color.WHITE)
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.letterSpacing = 0.12f
        title.gravity = Gravity.CENTER
        title.alpha = 0f
        col.addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(34) })

        val sub = TextView(this)
        sub.text = "Loan Monitoring System"
        sub.textSize = 14f
        sub.setTextColor(Color.parseColor("#BFD4FF"))
        sub.letterSpacing = 0.08f
        sub.gravity = Gravity.CENTER
        sub.alpha = 0f
        col.addView(sub, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        // thin loading line
        val track = FrameLayout(this)
        track.background = GradientDrawable().apply { setColor(Color.parseColor("#33FFFFFF")); cornerRadius = dp(2).toFloat() }
        val fill = View(this)
        fill.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#60A5FA"), Color.parseColor("#4ADE80"))
        ).apply { cornerRadius = dp(2).toFloat() }
        fill.pivotX = 0f
        fill.scaleX = 0f
        track.addView(fill, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        col.addView(track, LinearLayout.LayoutParams(dp(150), dp(4)).apply { topMargin = dp(44) })

        setContentView(root)
        root.setOnClickListener { next() }

        // --- animation ---
        card.alpha = 0f
        card.rotationY = -110f
        card.scaleX = 0.55f
        card.scaleY = 0.55f
        card.translationY = dp(40).toFloat()
        card.animate().alpha(1f).setDuration(450).start()
        card.animate().rotationY(0f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(1000).setInterpolator(OvershootInterpolator(1.15f)).start()

        // glow pulse
        glow.alpha = 0f
        glow.animate().alpha(1f).setDuration(900).start()

        // gentle 3D tilt once the logo has landed
        handler.postDelayed({
            val a = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat())
            a.duration = 2800
            a.repeatCount = ValueAnimator.INFINITE
            a.interpolator = LinearInterpolator()
            a.addUpdateListener {
                val t = it.animatedValue as Float
                card.rotationY = 11f * Math.sin(t.toDouble()).toFloat()
                card.rotationX = 5f * Math.cos(t.toDouble()).toFloat()
                val g = 1f + 0.06f * Math.sin(t.toDouble()).toFloat()
                glow.scaleX = g
                glow.scaleY = g
            }
            tilt = a
            a.start()
        }, 1000)

        // shine sweep
        handler.postDelayed({
            shine.alpha = 1f
            shine.translationX = -dp(110).toFloat()
            shine.animate().translationX(dp(260).toFloat()).setDuration(900)
                .setInterpolator(DecelerateInterpolator()).withEndAction { shine.alpha = 0f }.start()
        }, 950)

        // texts and progress line
        title.translationY = dp(18).toFloat()
        title.animate().alpha(1f).translationY(0f).setStartDelay(650).setDuration(550).start()
        sub.translationY = dp(14).toFloat()
        sub.animate().alpha(1f).translationY(0f).setStartDelay(850).setDuration(550).start()
        fill.animate().scaleX(1f).setStartDelay(500).setDuration(1700).setInterpolator(LinearInterpolator()).start()

        handler.postDelayed(openApp, 2300)
    }

    private fun next() {
        if (opened) return
        opened = true
        handler.removeCallbacks(openApp)
        tilt?.cancel()
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tilt?.cancel()
        super.onDestroy()
    }
}
