package com.lms.caller

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Transaction
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/* ---------------------------------------------------------------- helpers */

fun normalizePhone(v: String?): String {
    var d = (v ?: "").filter { it in '0'..'9' }
    if (d.startsWith("880")) d = d.substring(2)
    if (d.length == 10 && d.startsWith("1")) d = "0$d"
    return d
}

fun normName(s: String?): String =
    (s ?: "").lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

fun sameName(a: String?, b: String?): Boolean {
    val x = normName(a)
    return x.isNotEmpty() && x == normName(b)
}

fun fmtDate(ms: Long): String =
    if (ms <= 0L) "-" else SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date(ms))

fun fmtDateTime(ms: Long): String =
    if (ms <= 0L) "-" else SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date(ms))

/** Promise date as stored ("2026-09-26") -> "26-09-2026". */
fun fmtPromise(s: String): String {
    val t = s.trim()
    val m = Regex("^(\\d{4})-(\\d{1,2})-(\\d{1,2})").find(t)
    if (m != null) return String.format(Locale.US, "%02d-%02d-%s", m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1])
    val ms = parseAnyDate(t)
    return if (ms > 0L) SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH).format(Date(ms)) else t
}

/** Promise date text -> local midnight in ms (0 when it cannot be read). */
fun promiseMs(s: String): Long {
    val t = s.trim()
    val m = Regex("^(\\d{4})-(\\d{1,2})-(\\d{1,2})").find(t)
    if (m != null) {
        val c = Calendar.getInstance()
        c.clear()
        c.set(m.groupValues[1].toInt(), m.groupValues[2].toInt() - 1, m.groupValues[3].toInt(), 0, 0, 0)
        return c.timeInMillis
    }
    val ms = parseAnyDate(t)
    if (ms <= 0L) return 0L
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

/** Amount with lakh / crore grouping: 13247278 -> 1,32,47,278. */
fun fmtAmt(d: Double): String {
    val n = Math.round(d)
    val s = Math.abs(n).toString()
    val out = if (s.length <= 3) s else {
        val last3 = s.substring(s.length - 3)
        var rest = s.substring(0, s.length - 3)
        val parts = ArrayList<String>()
        while (rest.length > 2) {
            parts.add(0, rest.substring(rest.length - 2))
            rest = rest.substring(0, rest.length - 2)
        }
        if (rest.isNotEmpty()) parts.add(0, rest)
        parts.joinToString(",") + "," + last3
    }
    return if (n < 0) "-$out" else out
}

fun fmtDmy(ms: Long): String = SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH).format(Date(ms))

fun todayStart(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun distM(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
    val r = 6371000.0
    val p1 = Math.toRadians(lat1)
    val p2 = Math.toRadians(lat2)
    val dp = Math.toRadians(lat2 - lat1)
    val dl = Math.toRadians(lng2 - lng1)
    val a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2)
    return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

fun fmtDist(m: Double): String = if (m < 1000) "${m.toInt()} m" else String.format(Locale.US, "%.1f km", m / 1000)

private val DATE_FORMATS = listOf("yyyy-MM-dd", "dd-MM-yyyy", "dd/MM/yyyy", "dd-MMM-yyyy", "dd MMM yyyy", "d/M/yyyy", "d-M-yyyy")

fun parseAnyDate(v: Any?): Long {
    when (v) {
        null -> return 0L
        is Timestamp -> return v.toDate().time
        is Date -> return v.time
        is Number -> return v.toLong()
        is String -> {
            val s = v.trim()
            if (s.isEmpty()) return 0L
            for (f in DATE_FORMATS) {
                try {
                    val sdf = SimpleDateFormat(f, Locale.ENGLISH)
                    sdf.isLenient = false
                    val d = sdf.parse(s)
                    if (d != null) return d.time
                } catch (e: Exception) {
                }
            }
        }
    }
    return 0L
}

/** rescheduleNo -> 1, 2, 3 ... (0 when blank, 0 or not a number). Commas are ignored, like the web app. */
fun rescheduleNumber(v: Any?): Int {
    val x = when (v) {
        is Number -> v.toDouble()
        is String -> v.replace(",", "").trim().toDoubleOrNull() ?: 0.0
        else -> 0.0
    }
    return if (x >= 1.0) x.toInt() else 0
}

fun numOf(v: Any?): Double = when (v) {
    is Number -> v.toDouble()
    is String -> v.replace(Regex("[^0-9.\\-]"), "").toDoubleOrNull() ?: 0.0
    else -> 0.0
}

private fun DocumentSnapshot.str(k: String): String = (get(k)?.toString() ?: "").trim()

/* ---------------------------------------------------------------- models */

/** One loan row from LoanMonthlyData (id = Firestore document id, same id the web app uses for Notes). */
class Cust(
    val id: String, val prog: String, val caseNo: String, val name: String, val father: String,
    val spouse: String, val village: String, val union: String, val phone: String,
    val overdue: Long, val balance: Double, val due: Double, val received: Double,
    val progName: String = "", val rsNo: Int = 0, val installment: Double = 0.0
) {
    /** Rescheduled loan = rescheduleNo is 1 or more. */
    val rs: Boolean get() = rsNo >= 1
    val key: String get() = "$prog|$caseNo"
    /** "05 - Programme name" (just the code when the name is not known). */
    val progLabel: String get() = if (progName.isNotEmpty()) "$prog - $progName" else prog
    val sName: String = name.lowercase()
    val sFather: String = father.lowercase()
    val sSpouse: String = spouse.lowercase()
    val sCase: String = caseNo.lowercase()
    val sPhone: String = normalizePhone(phone)

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("p", prog).put("c", caseNo).put("n", name).put("f", father)
        .put("s", spouse).put("v", village).put("u", union).put("ph", phone)
        .put("od", overdue).put("b", balance).put("d", due).put("r", received)
        .put("pn", progName).put("rn", rsNo).put("ia", installment)

    companion object {
        fun fromJson(o: JSONObject) = Cust(
            o.getString("id"), o.optString("p"), o.optString("c"), o.optString("n"), o.optString("f"),
            o.optString("s"), o.optString("v"), o.optString("u"), o.optString("ph"),
            o.optLong("od"), o.optDouble("b", 0.0), o.optDouble("d", 0.0), o.optDouble("r", 0.0),
            o.optString("pn"), o.optInt("rn", if (o.optBoolean("rs", false)) 1 else 0),
            o.optDouble("ia", 0.0)
        )

        fun fromDoc(d: DocumentSnapshot) = Cust(
            d.id, d.str("loanProgrammeCode"), d.str("loanCaseNo"), d.str("customerName"), d.str("fatherName"),
            d.str("spouseName"), d.str("village"), d.str("union"), d.str("phone"),
            parseAnyDate(d.get("overdueDate")), numOf(d.get("currentBalance")), numOf(d.get("due")),
            numOf(d.get("receivedAmount")),
            d.str("loanProgrammeName"),
            rescheduleNumber(d.get("rescheduleNo")),
            numOf(d.get("installmentAmount"))
        )
    }
}

/** One document of CustomerLocations (random document id). */
class Loc(
    val id: String, var phone: String, var prog: String, var caseNo: String, var name: String,
    var father: String, var spouse: String, var village: String, var union: String,
    var lat: Double, var lng: Double, var accuracy: Double, var active: Boolean,
    var source: String, var updatedBy: String, var updatedAt: Long, var isNew: Boolean = false, var ownerId: String = ""
) {
    val key: String get() = "$prog|$caseNo"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("ph", phone).put("p", prog).put("c", caseNo).put("n", name).put("f", father)
        .put("s", spouse).put("v", village).put("u", union).put("la", lat).put("lo", lng)
        .put("ac", accuracy).put("a", active).put("src", source).put("by", updatedBy).put("at", updatedAt).put("nw", isNew).put("ow", ownerId)

    companion object {
        fun fromJson(o: JSONObject) = Loc(
            o.getString("id"), o.optString("ph"), o.optString("p"), o.optString("c"), o.optString("n"),
            o.optString("f"), o.optString("s"), o.optString("v"), o.optString("u"),
            o.getDouble("la"), o.getDouble("lo"), o.optDouble("ac", 0.0), o.optBoolean("a", true),
            o.optString("src"), o.optString("by"), o.optLong("at"), o.optBoolean("nw", false), o.optString("ow")
        )

        fun fromDoc(d: DocumentSnapshot): Loc? {
            val lat = d.getDouble("latitude") ?: return null
            val lng = d.getDouble("longitude") ?: return null
            val ts = d.getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            return Loc(
                d.id, d.str("mobile"), d.str("loanProgramme"), d.str("loanCase"), d.str("customerName"),
                d.str("fatherName"), d.str("spouseName"), d.str("village"), d.str("union"),
                lat, lng, d.getDouble("accuracy") ?: 0.0, d.getBoolean("active") ?: true,
                d.str("source"), d.getString("updatedByName") ?: d.str("updatedBy"), ts?.toDate()?.time ?: 0L,
                d.getBoolean("newCustomer") ?: false, d.str("createdBy")
            )
        }
    }
}

class Me(
    val id: String, val name: String, val role: String, val perms: List<String>, val unions: List<String>,
    /** Disbursement permissions saved by the web app (Users.dsbPerms = module -> actions); null = role default. */
    val dsb: Map<String, List<String>>? = null
)

/** One LoanEntries document that is waiting for a Disbursement Date (status "Date Pending") = the Pending Loan list. */
class PendingItem(
    val id: String, val name: String, val union: String, val loanType: String, val prog: String,
    val progName: String, val caseNo: String, val paid: String, val mobile: String,
    val byName: String, val createdMs: Long
) {
    val sName: String = name.lowercase()
    val sCase: String = caseNo.lowercase()
    val sPhone: String = normalizePhone(mobile)
}

class SyncItem(val loc: Loc, val fields: Map<String, Any?>, val kind: String)

class SyncPlan(
    val items: List<SyncItem>, val review: List<Pair<Loc, String>>,
    val phone: Int, val loan: Int, val info: Int, val inactive: Int, val unchanged: Int
)

/** One document of the WCL / CL collections (document id = loan id). [needMore] is only used by WCL. */
class ListItem(val id: String, val needMore: Double?)

/** Last note + promise date of one loan (from the Notes collection, used by the Monitoring list). */
class PromiseItem(val id: String, val text: String, val by: String, val at: Long, val promise: String, val promiseMs: Long)

/** Last note of one loan (document of the Notes collection; the root fields only, never the whole entries[] history). */
class LastNote(val id: String, val text: String, val by: String, val at: Long, val promise: String)

class NoteEntry(val text: String, val promise: String, val by: String, val at: Long)

class NoteDoc(val lastNote: String, val lastBy: String, val lastAt: Long, val promise: String, val entries: List<NoteEntry>)

/* ---------------------------------------------------------------- repository */

object Repo {
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val ls = CopyOnWriteArrayList<() -> Unit>()

    @Volatile var loans: List<Cust> = emptyList()
    @Volatile var byKey: HashMap<String, Cust> = HashMap()
    @Volatile var byPhone: HashMap<String, ArrayList<Cust>> = HashMap()
    val locs = ConcurrentHashMap<String, Loc>()
    @Volatile var locByKey: HashMap<String, Loc> = HashMap()
    @Volatile var locByPhone: HashMap<String, ArrayList<Loc>> = HashMap()
    @Volatile var me: Me? = null
    var status: String = ""
    var lastLat = 0.0
    var lastLng = 0.0
    var hasFix = false

    val promises = ConcurrentHashMap<String, PromiseItem>()
    /** Home-visit records of loan applicants (collection NewCustomers, only the ones this user entered). */
    val newCust = ConcurrentHashMap<String, Loc>()
    @Volatile var newStarted = false
    private var newReg: ListenerRegistration? = null

    // automatic daily sync of CustomerLocations with LoanMonthlyData
    @Volatile private var loansVerified = false
    @Volatile private var locsLoaded = false
    @Volatile private var syncRunning = false
    private var lastSyncCheckMs = 0L
    @Volatile var notesLoaded = false
    private var notesReg: ListenerRegistration? = null
    /** Last note of every loan, kept on the phone (notes.json). Changes arrive live through [startNotes]. */
    val lastNotes = ConcurrentHashMap<String, LastNote>()
    private var notesSinceS = 0L        // newest Notes.lastNoteSyncAt already on this phone (seconds + nanos)
    private var notesSinceN = 0
    private var notesSaveScheduled = false
    private const val NOTE_SYNC_FIELD = "lastNoteSyncAt"
    @Volatile private var loanIds: Set<String> = emptySet()   // ids of LoanMonthlyData: only these loans get notes
    private var notesBusy = false

    val wcl = ConcurrentHashMap<String, ListItem>()
    val cl = ConcurrentHashMap<String, ListItem>()
    @Volatile var listsStarted = false
    private var wclReg: ListenerRegistration? = null
    private var clReg: ListenerRegistration? = null

    /** Pending Loan list (LoanEntries with status "Date Pending"). */
    val pending = ConcurrentHashMap<String, PendingItem>()
    @Volatile var pendingStarted = false
    @Volatile var pendingLoaded = false
    private var pendingReg: ListenerRegistration? = null

    val unionSel = LinkedHashSet<String>()
    var unionInit = false
    private var unionFor = ""

    private var started = false
    private var locsSince = 0L
    private var locReg: ListenerRegistration? = null
    private var meReg: ListenerRegistration? = null
    private var saveScheduled = false
    private const val SCHEMA = 4

    fun touch() { changed() }
    fun addListener(f: () -> Unit) { ls.add(f) }
    fun removeListener(f: () -> Unit) { ls.remove(f) }
    private fun changed() { main.post { for (f in ls) { try { f() } catch (e: Exception) { } } } }
    private fun onMain(fn: () -> Unit) { main.post { fn() } }
    private fun bg(fn: () -> Unit) { io.execute { try { fn() } catch (e: Exception) { } } }
    private fun applyStatus(s: String) { status = s; changed() }

    private fun proj(): String = Prefs.config(app)?.projectId ?: "x"
    private fun file(name: String) = File(app.filesDir, "${proj()}_$name")
    private fun sp(): SharedPreferences = app.getSharedPreferences("lms_repo_${proj()}", Context.MODE_PRIVATE)
    private fun uid(): String = Prefs.userId(app)

    /** Id of the logged-in user. */
    fun myId(): String = uid()

    fun can(p: String): Boolean {
        val m = me ?: return false
        return m.role == "Admin" || m.perms.contains(p)
    }

    fun userName(): String = Prefs.userName(app)

    /**
     * Disbursement permission of the web app (same rules as dsb/perm.js): Admin has everything, otherwise the saved
     * Users.dsbPerms, otherwise the default of the role. [action] "manage" of a module also allows every action.
     */
    fun dsbCan(module: String, action: String): Boolean {
        val m = me ?: return false
        if (m.role == "Admin") return true
        val map: Map<String, List<String>> = m.dsb ?: when (m.role) {
            "Investigation Officer" -> mapOf(
                "loan-entry" to listOf("view", "create"),
                "date-pending" to listOf("view", "edit"),
                "disbursement-management" to listOf("view", "disburse", "reject")
            )
            "General User" -> mapOf("loan-entry" to listOf("view", "create"))
            else -> emptyMap()
        }
        val l = map[module] ?: return false
        return l.contains(action) || l.contains("manage")
    }

    /* ---- lifecycle ---- */

    fun start(ctx: Context) {
        app = ctx.applicationContext
        if (started) return
        started = true
        bg {
            loadCaches()
            onMain {
                startMe()
                startLocs()
                startNotes()
                changed()
            }
            onMain { refreshLoans(false) }
        }
    }

    /**
     * Deletes everything this phone saved from the database: the loan / location files and the saved settings of every
     * project (profile, update signatures, sync times, route list). Called at logout and when the server setup changes.
     */
    fun wipeLocal() {
        try {
            app.filesDir.listFiles()?.forEach { f ->
                if (f.name.endsWith("_loans.json") || f.name.endsWith("_locs.json") || f.name.endsWith("_notes.json")) f.delete()
            }
            val dir = File(app.applicationInfo.dataDir, "shared_prefs")
            dir.listFiles()?.forEach { f ->
                if (f.name.startsWith("lms_repo_") && f.name.endsWith(".xml")) {
                    app.getSharedPreferences(f.name.removeSuffix(".xml"), Context.MODE_PRIVATE).edit().clear().commit()
                }
            }
        } catch (e: Exception) { }
        Prefs.setInfo(app, "")
        Prefs.setSyncInfo(app, "")
    }

    fun reset() {
        locReg?.remove()
        meReg?.remove()
        locReg = null
        meReg = null
        wclReg?.remove()
        clReg?.remove()
        notesReg?.remove()
        notesReg = null
        pendingReg?.remove()
        pendingReg = null
        pending.clear()
        pendingStarted = false
        pendingLoaded = false
        newReg?.remove()
        newReg = null
        newCust.clear()
        newStarted = false
        loansVerified = false
        locsLoaded = false
        syncRunning = false
        lastSyncCheckMs = 0L
        promises.clear()
        lastNotes.clear()
        notesSinceS = 0L
        notesSinceN = 0
        notesBusy = false
        notesLoaded = false
        wclReg = null
        clReg = null
        wcl.clear()
        cl.clear()
        listsStarted = false
        loans = emptyList()
        loanIds = emptySet()
        byKey = HashMap()
        byPhone = HashMap()
        locs.clear()
        locByKey = HashMap()
        locByPhone = HashMap()
        me = null
        sp().edit().remove("me").apply()
        unionSel.clear()
        unionInit = false
        unionFor = ""
        locsSince = 0L
        started = false
        status = ""
    }

    /** Pull everything again (Loan data re-checked, locations fully re-read). */
    fun fullRefresh() {
        locReg?.remove()
        locs.clear()
        locsSince = 0L
        reindexLocs()
        startLocs()
        resyncNotes()
        refreshLoans(true)
    }

    private fun statusLine(): String =
        "${loans.size} customers  \u2022  ${locs.values.count { !it.isNew }} locations"

    /* ---- caches ---- */

    private fun readFile(f: File): String? = try { if (f.exists()) f.readText() else null } catch (e: Exception) { null }

    private fun loadCaches() {
        readFile(file("loans.json"))?.let { t ->
            try {
                val a = JSONArray(t)
                val l = ArrayList<Cust>(a.length())
                for (i in 0 until a.length()) l.add(Cust.fromJson(a.getJSONObject(i)))
                onMainSync { applyLoans(l) }
            } catch (e: Exception) { }
        }
        readFile(file("locs.json"))?.let { t ->
            try {
                val o = JSONObject(t)
                locsSince = o.optLong("since", 0L)
                val a = o.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val l = Loc.fromJson(a.getJSONObject(i))
                    locs[l.id] = l
                }
                onMainSync { reindexLocs() }
            } catch (e: Exception) { }
        }
        readFile(file("notes.json"))?.let { t ->
            try {
                val o = JSONObject(t)
                notesSinceS = o.optLong("ss", 0L)
                notesSinceN = o.optInt("sn", 0)
                val a = o.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val x = a.getJSONObject(i)
                    val id = x.getString("i")
                    lastNotes[id] = LastNote(id, x.optString("t"), x.optString("b"), x.optLong("a"), x.optString("p"))
                }
                rebuildPromises()
                notesLoaded = true
            } catch (e: Exception) { }
        }
        sp().getString("me", null)?.let { t ->
            try {
                val o = JSONObject(t)
                // the saved profile belongs to whoever logged in last: ignore it for another user
                if (o.optString("id") != Prefs.userId(app)) throw IllegalStateException("other user")
                val p = o.getJSONArray("p")
                val u = o.getJSONArray("u")
                var dsb: Map<String, List<String>>? = null
                o.optJSONObject("dp")?.let { dp ->
                    val mm = HashMap<String, List<String>>()
                    for (k in dp.keys()) {
                        val a = dp.optJSONArray(k) ?: continue
                        mm[k] = (0 until a.length()).map { a.getString(it) }
                    }
                    dsb = mm
                }
                me = Me(o.optString("id"), o.optString("n"), o.optString("r"),
                    (0 until p.length()).map { p.getString(it) }, (0 until u.length()).map { u.getString(it) }, dsb)
                onMainSync { initUnion() }
            } catch (e: Exception) { }
        }
    }

    /** Runs [fn] on the main thread and waits for it (used only while loading caches in the background). */
    private fun onMainSync(fn: () -> Unit) {
        val latch = java.util.concurrent.CountDownLatch(1)
        main.post { try { fn() } finally { latch.countDown() } }
        latch.await()
    }

    private fun saveLocsSoon() {
        if (saveScheduled) return
        saveScheduled = true
        main.postDelayed({
            saveScheduled = false
            bg {
                val arr = JSONArray()
                for (l in locs.values) arr.put(l.toJson())
                val o = JSONObject().put("since", locsSince).put("items", arr)
                file("locs.json").writeText(o.toString())
            }
        }, 1500)
    }

    /* ---- loans (LoanMonthlyData) ---- */

    private fun applyLoans(l: List<Cust>) {
        val k = HashMap<String, Cust>()
        val p = HashMap<String, ArrayList<Cust>>()
        for (c in l) {
            k[c.key] = c
            if (c.sPhone.isNotEmpty()) p.getOrPut(c.sPhone) { ArrayList() }.add(c)
        }
        val old = loanIds
        val ids = HashSet<String>(l.size * 2)
        for (c in l) ids.add(c.id)
        loans = l
        byKey = k
        byPhone = p
        loanIds = ids
        // notes follow LoanMonthlyData: start once the loans are known; loans that are new in this list get their note asked
        if (notesReg == null) {
            startNotes()
        } else if (old.isNotEmpty()) {
            val added = ids.filter { it !in old }
            if (added.isNotEmpty()) fetchNotesFor(added, false) { rebuildPromises(); saveNotesSoon(); changed() }
        }
    }

    /**
     * The whole LoanMonthlyData collection is read ONLY when the upload marker in MetaData changed
     * (1 small read otherwise); everything else comes from the phone's own storage.
     */
    fun refreshLoans(force: Boolean) {
        val db = Fb.db(app) ?: return
        applyStatus("Checking for updates...")
        db.collection("MetaData").document("Loan Data Update").get(Source.SERVER)
            .addOnSuccessListener { s ->
                val sig = if (s.exists())
                    (s.data ?: emptyMap<String, Any>()).entries.sortedBy { it.key }.joinToString("|") { "${it.key}=${it.value}" }
                else "none"
                val saved = sp().getString("sig", "") ?: ""
                val age = System.currentTimeMillis() - sp().getLong("loansAt", 0L)
                val stale = sig == "none" && age > 6 * 3600_000L
                val schemaOk = sp().getInt("schema", 0) == SCHEMA
                if (!force && loans.isNotEmpty() && sig == saved && !stale && schemaOk) {
                    applyStatus(statusLine())
                    loansVerified = true
                    autoSyncCheck()
                } else {
                    fetchLoans(db, sig)
                }
            }
            .addOnFailureListener {
                applyStatus(if (loans.isEmpty()) "Offline - no saved data yet" else "Offline - using saved data")
            }
    }

    private fun fetchLoans(db: FirebaseFirestore, sig: String) {
        applyStatus("Downloading customers...")
        db.collection("LoanMonthlyData").get()
            .addOnSuccessListener { snap ->
                bg {
                    val list = ArrayList<Cust>(snap.size())
                    for (d in snap.documents) list.add(Cust.fromDoc(d))
                    val arr = JSONArray()
                    for (c in list) arr.put(c.toJson())
                    file("loans.json").writeText(arr.toString())
                    sp().edit().putString("sig", sig).putLong("loansAt", System.currentTimeMillis()).putInt("schema", SCHEMA).apply()
                    onMain {
                        applyLoans(list)
                        status = statusLine()
                        changed()
                        loansVerified = true
                        autoSyncCheck()
                    }
                }
            }
            .addOnFailureListener {
                applyStatus(if (loans.isEmpty()) "Could not download customers" else "Offline - using saved data")
            }
    }

    /* ---- locations (CustomerLocations) ---- */

    private fun reindexLocs() {
        val k = HashMap<String, Loc>()
        val p = HashMap<String, ArrayList<Loc>>()
        for (l in locs.values) {
            if (l.isNew) continue
            if (l.prog.isNotEmpty() && l.caseNo.isNotEmpty()) k[l.key] = l
            val np = normalizePhone(l.phone)
            if (np.isNotEmpty()) p.getOrPut(np) { ArrayList() }.add(l)
        }
        locByKey = k
        locByPhone = p
    }

    private fun startLocs() {
        val db = Fb.db(app) ?: return
        locReg?.remove()
        var q: Query = db.collection("CustomerLocations")
        if (locsSince > 0L) q = q.whereGreaterThan("updatedAt", Timestamp(Date(locsSince)))
        locReg = q.addSnapshotListener { snap, err ->
            if (err != null || snap == null) return@addSnapshotListener
            var any = false
            for (ch in snap.documentChanges) {
                val d = ch.document
                if (ch.type == DocumentChange.Type.REMOVED) {
                    locs.remove(d.id)
                    any = true
                    continue
                }
                val l = Loc.fromDoc(d) ?: continue
                locs[d.id] = l
                any = true
                if (!d.metadata.hasPendingWrites() && l.updatedAt > locsSince) locsSince = l.updatedAt
            }
            if (any) {
                reindexLocs()
                saveLocsSoon()
            }
            status = statusLine()
            changed()
            // the sync works on the data already in memory (cache + live changes), so any first snapshot is enough
            locsLoaded = true
            autoSyncCheck()
        }
    }

    private fun startMe() {
        val db = Fb.db(app) ?: return
        val id = uid()
        if (id.isEmpty()) return
        meReg?.remove()
        meReg = db.collection("Users").document(id).addSnapshotListener { s, e ->
            if (e != null || s == null || !s.exists()) return@addSnapshotListener
            val perms = (s.get("permissions") as? List<*>)?.map { it.toString() } ?: emptyList()
            val unions = (s.get("unions") as? List<*>)?.map { it.toString() } ?: emptyList()
            var dsb: Map<String, List<String>>? = null
            (s.get("dsbPerms") as? Map<*, *>)?.let { raw ->
                val mm = HashMap<String, List<String>>()
                for ((k, v) in raw) mm[k.toString()] = (v as? List<*>)?.map { it.toString() } ?: emptyList()
                dsb = mm
            }
            val m = Me(s.id, s.getString("name") ?: "", s.getString("role") ?: "", perms, unions, dsb)
            me = m
            val saved = JSONObject().put("id", m.id).put("n", m.name).put("r", m.role)
                .put("p", JSONArray(perms)).put("u", JSONArray(unions))
            dsb?.let { d ->
                val dp = JSONObject()
                for ((k, v) in d) dp.put(k, JSONArray(v))
                saved.put("dp", dp)
            }
            sp().edit().putString("me", saved.toString()).apply()
            initUnion()
            changed()
        }
    }

    /* ---- union filter (shared by all screens) ---- */

    fun initUnion() {
        val m = me ?: return
        if (unionInit && unionFor == m.id) return
        unionInit = true
        unionFor = m.id
        unionSel.clear()
        unionSel.addAll(m.unions)
    }

    fun unionOk(u: String): Boolean = unionSel.isEmpty() || unionSel.contains(u)

    fun allUnions(): List<String> {
        val s = java.util.TreeSet<String>()
        for (c in loans) if (c.union.isNotEmpty()) s.add(c.union)
        for (l in locs.values) if (!l.isNew && l.union.isNotEmpty()) s.add(l.union)
        return s.toList()
    }

    fun unionLabel(): String = when {
        unionSel.isEmpty() -> "All unions"
        unionSel.size == 1 -> unionSel.first()
        else -> "${unionSel.size} unions"
    }

    /* ---- matching ---- */

    fun locFor(c: Cust): Loc? {
        locByKey[c.key]?.let { return it }
        if (c.sPhone.isNotEmpty()) return locByPhone[c.sPhone]?.firstOrNull { sameName(it.name, c.name) }
        return null
    }

    fun custFor(l: Loc): Cust? {
        byKey[l.key]?.let { return it }
        val np = normalizePhone(l.phone)
        if (np.isNotEmpty()) return byPhone[np]?.firstOrNull { sameName(it.name, l.name) }
        return null
    }

    /* ---- Update button: bring CustomerLocations in line with LoanMonthlyData ---- */

    private fun caseOrder(c: Cust): Long = c.caseNo.filter { it in '0'..'9' }.toLongOrNull() ?: 0L

    fun planSync(): SyncPlan {
        val items = ArrayList<SyncItem>()
        val review = ArrayList<Pair<Loc, String>>()
        var nPhone = 0
        var nLoan = 0
        var nInfo = 0
        var nInactive = 0
        var nSame = 0
        for (loc in locs.values) {
            if (loc.isNew) continue
            val np = normalizePhone(loc.phone)
            var match: Cust? = null
            var phoneOther = false
            if (np.isNotEmpty()) {
                val cands = byPhone[np].orEmpty()
                val named = cands.filter { sameName(it.name, loc.name) }
                if (named.isNotEmpty()) {
                    match = named.firstOrNull { it.key == loc.key } ?: named.maxByOrNull { caseOrder(it) }
                } else if (cands.isNotEmpty()) {
                    phoneOther = true
                }
            }
            if (match == null) match = byKey[loc.key]
            if (match == null) {
                if (phoneOther) {
                    review.add(Pair(loc, "Phone number now belongs to a different customer"))
                } else if (loc.active) {
                    items.add(SyncItem(loc, mapOf("active" to false), "inactive"))
                    nInactive++
                } else {
                    nSame++
                }
                continue
            }
            val f = LinkedHashMap<String, Any?>()
            val newPhone = if (match.sPhone.isNotEmpty()) match.sPhone else loc.phone
            val phoneChanged = normalizePhone(loc.phone) != normalizePhone(newPhone)
            val loanChanged = loc.prog != match.prog || loc.caseNo != match.caseNo
            if (phoneChanged) f["mobile"] = newPhone
            if (loc.prog != match.prog) f["loanProgramme"] = match.prog
            if (loc.caseNo != match.caseNo) f["loanCase"] = match.caseNo
            var info = false
            if (loc.name != match.name) { f["customerName"] = match.name; info = true }
            if (loc.father != match.father) { f["fatherName"] = match.father; info = true }
            if (loc.spouse != match.spouse) { f["spouseName"] = match.spouse; info = true }
            if (loc.village != match.village) { f["village"] = match.village; info = true }
            if (loc.union != match.union) { f["union"] = match.union; info = true }
            if (!loc.active) { f["active"] = true; info = true }
            if (f.isEmpty()) {
                nSame++
            } else {
                items.add(SyncItem(loc, f, "update"))
                if (phoneChanged) nPhone++
                if (loanChanged) nLoan++
                if (info) nInfo++
            }
        }
        return SyncPlan(items, review, nPhone, nLoan, nInfo, nInactive, nSame)
    }

    fun applySync(plan: SyncPlan, auto: Boolean, done: (Boolean, String) -> Unit) {
        val db = Fb.db(app)
        if (db == null) { done(false, "Server not set"); return }
        val chunks = plan.items.chunked(400)
        if (chunks.isEmpty()) { done(true, "Nothing to update"); return }
        fun fieldsFor(item: SyncItem): HashMap<String, Any?> {
            val m = HashMap<String, Any?>(item.fields)
            m["updatedAt"] = FieldValue.serverTimestamp()
            m["updatedBy"] = if (auto) "system" else uid()
            m["updatedByName"] = if (auto) "Auto sync" else userName()
            return m
        }
        fun step(i: Int) {
            if (i >= chunks.size) { done(true, "${plan.items.size} locations updated"); return }
            val b = db.batch()
            for (item in chunks[i]) b.update(db.collection("CustomerLocations").document(item.loc.id), fieldsFor(item))
            b.commit().addOnSuccessListener { step(i + 1) }
                .addOnFailureListener {
                    // a single missing document must not stop the whole sync: write this chunk document by document
                    var left = chunks[i].size
                    var bad: String? = null
                    for (item in chunks[i]) {
                        db.collection("CustomerLocations").document(item.loc.id).update(fieldsFor(item))
                            .addOnFailureListener { ex ->
                                val code = (ex as? FirebaseFirestoreException)?.code
                                if (code != FirebaseFirestoreException.Code.NOT_FOUND) bad = ex.message ?: "Update failed"
                            }
                            .addOnCompleteListener {
                                left--
                                if (left == 0) {
                                    val err = bad
                                    if (err != null) done(false, err) else step(i + 1)
                                }
                            }
                    }
                }
        }
        step(0)
    }

    /* ---- add / update one location ---- */

    fun saveLocation(c: Cust, existing: Loc?, lat: Double, lng: Double, acc: Double, source: String) {
        val db = Fb.db(app) ?: return
        val col = db.collection("CustomerLocations")
        val ref = if (existing != null) col.document(existing.id) else col.document()
        val m = HashMap<String, Any?>()
        m["mobile"] = if (c.sPhone.isNotEmpty()) c.sPhone else c.phone
        m["loanProgramme"] = c.prog
        m["loanCase"] = c.caseNo
        m["customerName"] = c.name
        m["fatherName"] = c.father
        m["spouseName"] = c.spouse
        m["village"] = c.village
        m["union"] = c.union
        m["latitude"] = lat
        m["longitude"] = lng
        m["accuracy"] = acc
        m["active"] = true
        m["source"] = source
        m["updatedAt"] = FieldValue.serverTimestamp()
        m["updatedBy"] = uid()
        m["updatedByName"] = userName()
        if (existing == null) {
            m["createdAt"] = FieldValue.serverTimestamp()
            m["createdBy"] = uid()
        }
        // The write is queued by Firestore even when offline; show it on the map straight away.
        val l = Loc(ref.id, m["mobile"] as String, c.prog, c.caseNo, c.name, c.father, c.spouse, c.village, c.union,
            lat, lng, acc, true, source, userName(), System.currentTimeMillis())
        locs[ref.id] = l
        reindexLocs()
        changed()
        ref.set(m, SetOptions.merge()).addOnFailureListener {
            onMain { app.toast("Location not saved: ${it.message}") }
        }
    }

    /* ---- locations of saved customers / new (not yet connected) customers ---- */

    fun savedLocs(): List<Loc> = locs.values.filter { !it.isNew }

    fun newCustomers(): List<Loc> = newCust.values.toList()

    /* ---- automatic daily sync (CustomerLocations <- LoanMonthlyData) ---- */

    /**
     * Called whenever the app opens / comes back. When the last sync (MetaData / "Location Sync") is older than
     * 24 hours, this phone claims the sync (a short lease, so two phones never run it together) and runs it silently.
     */
    private fun syncNote(msg: String) {
        val t = SimpleDateFormat("dd MMM HH:mm", Locale.ENGLISH).format(Date())
        Prefs.setSyncInfo(app, "$msg ($t)")
    }

    fun autoSyncCheck() {
        if (!loansVerified || !locsLoaded || syncRunning) return
        if (loans.size < 10 || locs.isEmpty() || uid().isEmpty()) return
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastSyncCheckMs < 10 * 60_000L) return
        val db = Fb.db(app) ?: return
        val pid = try { db.app.options.projectId ?: "" } catch (e: Exception) { "" }
        val key = "locSyncAt_$pid"
        // the last sync time is remembered on this phone: while it is fresh nothing is read from Firestore at all
        val known = sp().getLong(key, 0L)
        if (known > 0L && known <= nowMs + 3600_000L && nowMs - known < 24L * 3600_000L) return
        lastSyncCheckMs = nowMs
        val ref = db.collection("MetaData").document("Location Sync")
        syncRunning = true
        var seen = 0L
        db.runTransaction(Transaction.Function<Boolean> { tr ->
            val snap = tr.get(ref)
            val now = System.currentTimeMillis()
            val last = snap.getLong("updatedAtMs") ?: 0L
            val lease = snap.getLong("leaseUntilMs") ?: 0L
            seen = last
            // a "last" time far in the future means a wrong phone clock: ignore it
            val fresh = last > 0L && last <= now + 3600_000L && now - last < 24L * 3600_000L
            if (fresh || lease > now) {
                false
            } else {
                // claims the sync (and creates the document when it does not exist yet)
                tr.set(ref, hashMapOf<String, Any>("leaseUntilMs" to (now + 15 * 60_000L), "leaseBy" to uid()), SetOptions.merge())
                true
            }
        }).addOnSuccessListener { claimed ->
            if (seen > 0L) sp().edit().putLong(key, seen).apply()
            if (claimed == true) {
                syncNote("Auto sync running")
                runAutoSync(ref, key)
            } else {
                syncNote("Auto sync not due yet")
                syncRunning = false
            }
        }.addOnFailureListener { e ->
            // any error: nothing is synced now, the next app open tries again
            syncNote("Auto sync error: ${e.message}")
            syncRunning = false
        }
    }

    private fun runAutoSync(ref: DocumentReference, key: String) {
        bg {
            try {
                val plan = planSync()
                val activeLocs = locs.values.count { !it.isNew && it.active }.coerceAtLeast(1)
                if (plan.inactive > 20 && plan.inactive * 100 / activeLocs > 40) {
                    // that many closed loans at once looks like incomplete loan data: change nothing, try again later
                    ref.set(
                        hashMapOf<String, Any>(
                            "leaseUntilMs" to (System.currentTimeMillis() + 6 * 3600_000L),
                            "skipReason" to "too many inactive: ${plan.inactive} of $activeLocs",
                            "skipAtMs" to System.currentTimeMillis()
                        ), SetOptions.merge()
                    )
                    syncNote("Auto sync skipped: ${plan.inactive} locations would be closed")
                    syncRunning = false
                } else {
                    applySync(plan, true) { ok, msg ->
                        val m = HashMap<String, Any>()
                        m["leaseUntilMs"] = 0L
                        if (ok) {
                            sp().edit().putLong(key, System.currentTimeMillis()).apply()
                            syncNote("Auto sync done: phone ${plan.phone}, loan ${plan.loan}, info ${plan.info}, closed ${plan.inactive}")
                            m["updatedAt"] = FieldValue.serverTimestamp()
                            m["updatedAtMs"] = System.currentTimeMillis()
                            m["updatedByName"] = userName()
                            m["phoneUpdated"] = plan.phone
                            m["loanUpdated"] = plan.loan
                            m["infoUpdated"] = plan.info
                            m["inactiveMarked"] = plan.inactive
                            m["unchanged"] = plan.unchanged
                            m["needsReview"] = plan.review.size
                        }
                        if (!ok) syncNote("Auto sync failed: $msg")
                        ref.set(m, SetOptions.merge())
                        syncRunning = false
                    }
                }
            } catch (e: Exception) {
                syncNote("Auto sync error: ${e.message}")
                syncRunning = false
            }
        }
    }

    /* ---- new customers (collection NewCustomers) ---- */

    private fun newFromDoc(d: DocumentSnapshot): Loc? {
        val lat = (d.get("latitude") as? Number)?.toDouble() ?: return null
        val lng = (d.get("longitude") as? Number)?.toDouble() ?: return null
        val ts = d.getTimestamp("createdAt")
        return Loc(
            d.id, d.str("mobile"), "", "", d.str("customerName"), d.str("fatherName"), "", d.str("village"), "",
            lat, lng, numOf(d.get("accuracy")), true, d.str("source"), d.str("createdByName"),
            ts?.toDate()?.time ?: System.currentTimeMillis(), true, d.str("createdBy")
        )
    }

    /** Starts the listener of this user's new customers (opened with the New Customer module). */
    fun ensureNewCustomers() {
        if (newStarted) return
        val db = Fb.db(app) ?: return
        val id = uid()
        if (id.isEmpty()) return
        newStarted = true
        newReg = db.collection("NewCustomers").whereEqualTo("createdBy", id).addSnapshotListener { snap, err ->
            if (err != null || snap == null) return@addSnapshotListener
            val fresh = HashMap<String, Loc>()
            for (d in snap.documents) newFromDoc(d)?.let { fresh[d.id] = it }
            newCust.clear()
            newCust.putAll(fresh)
            changed()
        }
        moveLegacyNew()
    }

    /** Earlier versions kept new customers inside CustomerLocations: move this user's old records to NewCustomers. */
    private fun moveLegacyNew() {
        val db = Fb.db(app) ?: return
        val me = uid()
        val old = locs.values.filter { it.isNew && it.ownerId == me }
        if (old.isEmpty()) return
        val b = db.batch()
        for (l in old.take(200)) {
            val m = HashMap<String, Any?>()
            m["customerName"] = l.name
            m["fatherName"] = l.father
            m["village"] = l.village
            m["mobile"] = l.phone
            m["latitude"] = l.lat
            m["longitude"] = l.lng
            m["accuracy"] = l.accuracy
            m["source"] = l.source
            m["createdAt"] = FieldValue.serverTimestamp()
            m["createdBy"] = me
            m["createdByName"] = l.updatedBy
            b.set(db.collection("NewCustomers").document(l.id), m)
            b.delete(db.collection("CustomerLocations").document(l.id))
            locs.remove(l.id)
        }
        b.commit()
        reindexLocs()
    }

    /** Home-visit record of a loan applicant. */
    fun saveNewCustomer(name: String, rel: String, village: String, phone: String, lat: Double, lng: Double, acc: Double, source: String) {
        val db = Fb.db(app) ?: return
        val ref = db.collection("NewCustomers").document()
        val m = HashMap<String, Any?>()
        m["customerName"] = name
        m["fatherName"] = rel
        m["village"] = village
        m["mobile"] = phone
        m["latitude"] = lat
        m["longitude"] = lng
        m["accuracy"] = acc
        m["source"] = source
        m["createdAt"] = FieldValue.serverTimestamp()
        m["createdBy"] = uid()
        m["createdByName"] = userName()
        newCust[ref.id] = Loc(ref.id, phone, "", "", name, rel, "", village, "", lat, lng, acc, true, source,
            userName(), System.currentTimeMillis(), true, uid())
        changed()
        ref.set(m).addOnFailureListener {
            onMain { app.toast("Not saved: ${it.message}") }
        }
    }

    /** Deletes one new-customer record (the applicant did not get a loan). */
    fun deleteNewCustomer(id: String) {
        val db = Fb.db(app) ?: return
        newCust.remove(id)
        changed()
        db.collection("NewCustomers").document(id).delete().addOnFailureListener {
            onMain { app.toast("Could not delete: ${it.message}") }
        }
    }

    /**
     * Connects a new customer to the loan customer: the location is written to CustomerLocations (same fields as
     * every other saved location) and the NewCustomers record is removed.
     */
    fun connectNew(l: Loc, c: Cust) {
        val db = Fb.db(app) ?: return
        val old = locFor(c)
        val col = db.collection("CustomerLocations")
        val ref = col.document(l.id)
        val mobile = if (c.sPhone.isNotEmpty()) c.sPhone else if (c.phone.isNotEmpty()) c.phone else l.phone
        val m = HashMap<String, Any?>()
        m["mobile"] = mobile
        m["loanProgramme"] = c.prog
        m["loanCase"] = c.caseNo
        m["customerName"] = c.name
        m["fatherName"] = c.father
        m["spouseName"] = c.spouse
        m["village"] = c.village
        m["union"] = c.union
        m["latitude"] = l.lat
        m["longitude"] = l.lng
        m["accuracy"] = l.accuracy
        m["active"] = true
        m["source"] = l.source
        m["createdAt"] = FieldValue.serverTimestamp()
        m["createdBy"] = l.ownerId
        m["updatedAt"] = FieldValue.serverTimestamp()
        m["updatedBy"] = uid()
        m["updatedByName"] = userName()
        val b = db.batch()
        b.set(ref, m)
        b.delete(db.collection("NewCustomers").document(l.id))
        if (old != null && old.id != l.id) {
            b.delete(col.document(old.id))
            locs.remove(old.id)
        }
        locs[l.id] = Loc(l.id, mobile, c.prog, c.caseNo, c.name, c.father, c.spouse, c.village, c.union,
            l.lat, l.lng, l.accuracy, true, l.source, userName(), System.currentTimeMillis(), false, l.ownerId)
        newCust.remove(l.id)
        reindexLocs()
        changed()
        b.commit().addOnFailureListener {
            onMain { app.toast("Could not connect: ${it.message}") }
        }
    }

    /* ---- notes (same structure as the web app) ---- */

    /** Last note of one loan from the phone's own copy (no Firestore read). */
    fun noteFor(id: String): NoteDoc? {
        val n = lastNotes[id] ?: return null
        return NoteDoc(n.text, n.by, n.at, n.promise, listOf(NoteEntry(n.text, n.promise, n.by, n.at)))
    }

    fun addNote(c: Cust, text: String, promise: String, done: (Boolean, String) -> Unit) {
        val db = Fb.db(app)
        if (db == null) { done(false, "Server not set"); return }
        val at = System.currentTimeMillis()
        val entry = hashMapOf<String, Any>(
            "text" to text, "promiseDate" to promise, "by" to userName(), "byId" to uid(), "at" to at
        )
        val m = hashMapOf<String, Any>(
            "loanId" to c.id, "loanProgrammeCode" to c.prog, "loanCaseNo" to c.caseNo,
            "customerName" to c.name, "lastNote" to text, "lastNoteBy" to userName(), "lastNoteAt" to at,
            "lastPromiseDate" to promise, "lastNoteSyncAt" to FieldValue.serverTimestamp(),
            "entries" to FieldValue.arrayUnion(entry)
        )
        // show it at once on this phone; the listener confirms it (or it is rolled back if the server refuses it)
        val prev = lastNotes[c.id]
        lastNotes[c.id] = LastNote(c.id, text, userName(), at, promise)
        rebuildPromises()
        saveNotesSoon()
        changed()
        db.collection("Notes").document(c.id).set(m, SetOptions.merge())
            .addOnSuccessListener { done(true, "Note saved") }
            .addOnFailureListener {
                if (prev != null) lastNotes[c.id] = prev else lastNotes.remove(c.id)
                rebuildPromises()
                saveNotesSoon()
                changed()
                done(false, it.message ?: "Could not save note")
            }
    }

    /* ---- WCL / CL lists (same collections and fields as the web app) ---- */

    /** Kept for the Monitoring screen: the notes listener already runs from app start. */
    fun ensureNotes() { startNotes() }

    private fun DocumentSnapshot.tsOf(k: String): Timestamp? = try { getTimestamp(k) } catch (e: Exception) { null }

    /**
     * Notes of the loans in LoanMonthlyData only (a note whose loan is not in LoanMonthlyData is never loaded).
     * First run: the notes of exactly those loans are asked by document id (in groups of 30), nothing else is read.
     * After that a live listener asks only for notes whose [NOTE_SYNC_FIELD] is newer than the newest one saved on the
     * phone, so being offline for 30 minutes or 30 days costs no extra reads.
     */
    fun startNotes() {
        if (notesReg != null || notesBusy) return
        if (loanIds.isEmpty()) return
        if (Fb.db(app) == null) return
        if (notesSinceS == 0L) {
            notesBusy = true
            var maxS = 0L
            var maxN = 0
            val ids = loanIds.toList()
            fetchNotesFor(ids, true, { s, n ->
                if (s > maxS || (s == maxS && n > maxN)) { maxS = s; maxN = n }
            }) { ok ->
                notesBusy = false
                if (ok) {
                    // nothing carries the sync field yet: start from now (the listener then only reports newer notes)
                    notesSinceS = if (maxS > 0L) maxS else System.currentTimeMillis() / 1000L
                    notesSinceN = if (maxS > 0L) maxN else 0
                    notesLoaded = true
                    rebuildPromises()
                    saveNotesSoon()
                    changed()
                    attachNotes()
                }
            }
        } else {
            attachNotes()
        }
    }

    /** Asks the notes of [ids] (loan ids = Notes document ids). Only existing documents are read; [done] gets false if a group failed. */
    private fun fetchNotesFor(ids: List<String>, advance: Boolean, seen: (Long, Int) -> Unit = { _, _ -> }, done: (Boolean) -> Unit) {
        val db = Fb.db(app)
        val chunks = ids.chunked(30)
        if (db == null || chunks.isEmpty()) { done(db != null); return }
        var left = chunks.size
        var allOk = true
        for (ch in chunks) {
            db.collection("Notes").whereIn(FieldPath.documentId(), ch).get()
                .addOnSuccessListener { snap ->
                    for (d in snap.documents) {
                        lastNotes[d.id] = noteOf(d)
                        val ts = d.tsOf(NOTE_SYNC_FIELD)
                        if (advance && ts != null) seen(ts.seconds, ts.nanoseconds)
                    }
                }
                .addOnFailureListener { allOk = false }
                .addOnCompleteListener {
                    left--
                    if (left == 0) done(allOk)
                }
        }
    }

    private fun noteOf(d: DocumentSnapshot) = LastNote(d.id, d.str("lastNote"), d.str("lastNoteBy"),
        numOf(d.get("lastNoteAt")).toLong(), d.str("lastPromiseDate"))

    private fun attachNotes() {
        if (notesReg != null) return
        val db = Fb.db(app) ?: return
        val q: Query = db.collection("Notes").whereGreaterThan(NOTE_SYNC_FIELD, Timestamp(notesSinceS, notesSinceN))
        notesReg = q.addSnapshotListener { snap, err ->
            if (err != null || snap == null) return@addSnapshotListener
            var any = false
            for (ch in snap.documentChanges) {
                val d = ch.document
                if (!d.metadata.hasPendingWrites()) {
                    val ts = d.tsOf(NOTE_SYNC_FIELD)
                    if (ts != null && (ts.seconds > notesSinceS || (ts.seconds == notesSinceS && ts.nanoseconds > notesSinceN))) {
                        notesSinceS = ts.seconds
                        notesSinceN = ts.nanoseconds
                        any = true
                    }
                }
                if (ch.type == DocumentChange.Type.REMOVED) {
                    if (lastNotes.remove(d.id) != null) any = true
                    continue
                }
                // a note whose loan is not in LoanMonthlyData is not loaded
                if (!loanIds.contains(d.id)) continue
                lastNotes[d.id] = noteOf(d)
                any = true
            }
            if (any) {
                rebuildPromises()
                saveNotesSoon()
            }
            notesLoaded = true
            changed()
        }
    }

    /** Reads every note again (only on a manual full refresh). */
    private fun resyncNotes() {
        notesReg?.remove()
        notesReg = null
        lastNotes.clear()
        notesSinceS = 0L
        notesSinceN = 0
        notesBusy = false
        startNotes()
    }

    private fun rebuildPromises() {
        val fresh = HashMap<String, PromiseItem>()
        for (n in lastNotes.values) {
            if (n.promise.isEmpty()) continue
            val ms = promiseMs(n.promise)
            if (ms <= 0L) continue
            fresh[n.id] = PromiseItem(n.id, n.text, n.by, n.at, n.promise, ms)
        }
        promises.keys.retainAll(fresh.keys)
        promises.putAll(fresh)
    }

    private fun saveNotesSoon() {
        if (notesSaveScheduled) return
        notesSaveScheduled = true
        main.postDelayed({
            notesSaveScheduled = false
            bg {
                val arr = JSONArray()
                for (n in lastNotes.values) {
                    arr.put(JSONObject().put("i", n.id).put("t", n.text).put("b", n.by).put("a", n.at).put("p", n.promise))
                }
                val o = JSONObject().put("ss", notesSinceS).put("sn", notesSinceN).put("items", arr)
                file("notes.json").writeText(o.toString())
            }
        }, 1500)
    }

    fun listMap(name: String): ConcurrentHashMap<String, ListItem> = if (name == "WCL") wcl else cl

    /** Starts the two small list listeners the first time a screen needs them (later opens cost almost nothing). */
    fun ensureLists() {
        if (listsStarted) return
        val db = Fb.db(app) ?: return
        listsStarted = true
        wclReg = listenList(db, "WCL", wcl)
        clReg = listenList(db, "CL", cl)
    }

    private fun listenList(db: FirebaseFirestore, col: String, map: ConcurrentHashMap<String, ListItem>): ListenerRegistration =
        db.collection(col).addSnapshotListener { snap, err ->
            if (err != null || snap == null) return@addSnapshotListener
            val fresh = HashMap<String, ListItem>()
            for (d in snap.documents) {
                val nm = d.get("needMore")
                val v: Double? = when {
                    nm is Number -> nm.toDouble()
                    nm is String && nm.isNotBlank() -> numOf(nm)
                    else -> null
                }
                fresh[d.id] = ListItem(d.id, v)
            }
            map.clear()
            map.putAll(fresh)
            changed()
        }

    fun addToList(name: String, c: Cust) {
        val db = Fb.db(app) ?: return
        val m = hashMapOf<String, Any>("loanProgrammeCode" to c.prog, "customerName" to c.name)
        listMap(name).putIfAbsent(c.id, ListItem(c.id, null))
        changed()
        db.collection(name).document(c.id).set(m, SetOptions.merge()).addOnFailureListener {
            onMain { app.toast("Could not add: ${it.message}") }
        }
    }

    fun removeFromList(name: String, id: String) {
        val db = Fb.db(app) ?: return
        listMap(name).remove(id)
        changed()
        db.collection(name).document(id).delete().addOnFailureListener {
            onMain { app.toast("Could not remove: ${it.message}") }
        }
    }

    /** WCL "Need More" amount (null clears it, like the web app which stores an empty value). */
    fun setNeedMore(id: String, v: Double?) {
        val db = Fb.db(app) ?: return
        listMap("WCL")[id] = ListItem(id, v)
        changed()
        db.collection("WCL").document(id).set(hashMapOf<String, Any>("needMore" to (v ?: "")), SetOptions.merge())
            .addOnFailureListener { onMain { app.toast("Could not save amount: ${it.message}") } }
    }

    /* ---- Pending Loan list (LoanEntries, same collection / fields as the web Date Pending page) ---- */

    /** Live list of "Date Pending" entries; started the first time the Pending Loan module opens. */
    fun ensurePending() {
        if (pendingStarted) return
        val db = Fb.db(app) ?: return
        pendingStarted = true
        pendingReg = db.collection("LoanEntries").whereEqualTo("status", "Date Pending").limit(800)
            .addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                val fresh = HashMap<String, PendingItem>()
                for (d in snap.documents) {
                    val ts = d.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    fresh[d.id] = PendingItem(
                        d.id, d.str("customerName"), d.str("unionName"), d.str("loanType"), d.str("oldProgrammeId"),
                        d.str("oldProgrammeName"), d.str("oldLC"), d.str("paidDate"), d.str("customerMobile"),
                        d.str("createdByName"), ts?.toDate()?.time ?: 0L
                    )
                }
                pending.clear()
                pending.putAll(fresh)
                pendingLoaded = true
                changed()
            }
    }

    /** The loan was marked Paid: it leaves the borrower list (also from this phone's saved copy). */
    fun dropLoan(id: String) {
        val l = loans.filter { it.id != id }
        if (l.size == loans.size) return
        applyLoans(l)
        status = statusLine()
        changed()
        bg {
            val arr = JSONArray()
            for (c in l) arr.put(c.toJson())
            file("loans.json").writeText(arr.toString())
        }
    }

    /* ---- route list (stored on this phone) ---- */

    fun route(): MutableList<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(sp().getString("route", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) { }
        return out
    }

    fun setRoute(l: List<String>) {
        sp().edit().putString("route", JSONArray(l).toString()).apply()
        changed()
    }
}
