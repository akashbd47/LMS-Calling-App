package com.lms.caller

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonOptions
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point

class MapScreen(private val h: HomeActivity) : Screen {
    private val root = FrameLayout(h)
    override val view: View get() = root

    private val mv = MapView(h)
    private var map: MapLibreMap? = null
    private var style: Style? = null
    private var sat = false
    private var pendingInitial = true
    private var located = false
    private var selId: String? = null
    private var gps: Gps? = null
    private var meFeature: Feature? = null
    private val handler = Handler(Looper.getMainLooper())
    private val card = h.vbox()
    private val search = SearchBox(h, "Search name, father, spouse, village")
    private val countPill: TextView = h.label("", 12f, C.text, true)
    private val unionBar: UnionBar
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshData() }

    companion object {
        const val SRC = "locs"
        const val SRC_SEL = "sel"
        const val SRC_ME = "me"
        const val L_ON = "l-on"
        const val L_OFF = "l-off"
        const val L_SEL = "l-sel"
        const val L_ME = "l-me"
        const val L_ME_HALO = "l-me-halo"
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(mv, FrameLayout.LayoutParams(MATCH, MATCH))

        val top = h.vbox()
        top.setPadding(h.dp(10), h.dp(10), h.dp(10), 0)
        search.root.elevation = h.dp(3).toFloat()
        search.edit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.edit.setOnEditorActionListener { v, _, _ ->
            fitAll()
            (h.getSystemService(InputMethodManager::class.java)).hideSoftInputFromWindow(v.windowToken, 0)
            true
        }
        top.addView(search.root)
        unionBar = UnionBar(h) { refreshData() }
        unionBar.root.elevation = h.dp(3).toFloat()
        countPill.background = h.shape(Color.WHITE, 20)
        countPill.setPadding(h.dp(12), h.dp(8), h.dp(12), h.dp(8))
        countPill.elevation = h.dp(3).toFloat()
        val row = h.hbox()
        row.addView(unionBar.root)
        row.addView(countPill, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(8) })
        top.addView(row, h.lp(8))
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        val fabs = h.vbox()
        fun addFab(res: Int, onClick: () -> Unit) {
            fabs.addView(h.fab(res, C.primary, onClick), LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { topMargin = h.dp(10) })
        }
        addFab(R.drawable.ic_back) { h.select(HomeActivity.HOME) }
        addFab(R.drawable.ic_target) { myLocation() }
        addFab(R.drawable.ic_map) { fitAll() }
        addFab(R.drawable.ic_layers) { toggleSat() }
        addFab(R.drawable.ic_search) { nearby() }
        addFab(R.drawable.ic_route) { RouteScreen.open(h) }
        root.addView(fabs, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
            setMargins(0, h.dp(112), h.dp(10), 0)
        })

        card.background = h.shape(Color.WHITE, 18, C.line)
        card.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(14))
        card.elevation = h.dp(8).toFloat()
        card.visibility = View.GONE
        root.addView(card, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            setMargins(h.dp(10), 0, h.dp(10), h.dp(10))
        })

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 250)
            }
        })

        h.registerMap(mv)
        mv.getMapAsync { m ->
            map = m
            m.uiSettings.isRotateGesturesEnabled = false
            m.uiSettings.isCompassEnabled = false
            m.cameraPosition = CameraPosition.Builder().target(LatLng(23.7, 90.4)).zoom(6.0).build()
            m.addOnMapClickListener { ll -> onTap(m, ll) }
            loadStyle(m)
        }
        Repo.addListener(listener)
    }

    /* ---------------- style & layers ---------------- */

    private fun loadStyle(m: MapLibreMap) {
        MapStyle.apply(m, sat) { st ->
            style = st
            setupLayers(st)
            refreshData()
            select(selId)
            meFeature?.let { st.getSourceAs<GeoJsonSource>(SRC_ME)?.setGeoJson(it) }
        }
    }

    /** Teardrop map pin (like the classic blue marker) drawn in code. [scale] 1 = 30 x 42 dp. */
    private fun pinBitmap(fill: Int, edge: Int, scale: Float): Bitmap {
        val d = h.dp(1).toFloat()
        val w = (30f * d * scale).toInt()
        val ht = (42f * d * scale).toInt()
        val bmp = Bitmap.createBitmap(w, ht, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pad = 1.5f * d
        val r = w / 2f - pad
        val cx = w / 2f
        val cy = r + pad
        val path = Path()
        path.addCircle(cx, cy, r, Path.Direction.CW)
        val tip = Path()
        tip.moveTo(cx - r * 0.80f, cy + r * 0.55f)
        tip.lineTo(cx + r * 0.80f, cy + r * 0.55f)
        tip.quadTo(cx + r * 0.30f, cy + r * 1.30f, cx, ht - pad)
        tip.quadTo(cx - r * 0.30f, cy + r * 1.30f, cx - r * 0.80f, cy + r * 0.55f)
        tip.close()
        path.addPath(tip)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // soft shadow under the tip
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#33000000")
        c.drawOval(RectF(cx - r * 0.55f, ht - pad - 3f * d, cx + r * 0.55f, ht - pad + 1f * d), p)
        p.color = fill
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * d
        p.color = edge
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(cx, cy, r * 0.42f, p)
        return bmp
    }

    private fun pinLayer(id: String, src: String, image: String, active: Int): SymbolLayer =
        SymbolLayer(id, src).withFilter(Expression.eq(Expression.get("a"), Expression.literal(active))).withProperties(
            PropertyFactory.iconImage(image),
            PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            PropertyFactory.iconAllowOverlap(true),
            PropertyFactory.iconIgnorePlacement(true)
        )

    private fun setupLayers(st: Style) {
        st.addImage("pin-on", pinBitmap(Color.parseColor("#2A81CB"), Color.parseColor("#1B5E99"), 1f))
        st.addImage("pin-off", pinBitmap(Color.parseColor("#94A3B8"), Color.parseColor("#64748B"), 1f))
        st.addImage("pin-sel", pinBitmap(Color.parseColor("#F59E0B"), Color.parseColor("#B45309"), 1.3f))
        // every customer is its own pin (no clusters / count bubbles)
        st.addSource(GeoJsonSource(SRC, FeatureCollection.fromFeatures(ArrayList<Feature>())))
        st.addSource(GeoJsonSource(SRC_SEL, FeatureCollection.fromFeatures(ArrayList<Feature>())))
        st.addSource(GeoJsonSource(SRC_ME, FeatureCollection.fromFeatures(ArrayList<Feature>())))

        st.addLayer(pinLayer(L_OFF, SRC, "pin-off", 0))
        st.addLayer(pinLayer(L_ON, SRC, "pin-on", 1))
        st.addLayer(
            SymbolLayer(L_SEL, SRC_SEL).withProperties(
                PropertyFactory.iconImage("pin-sel"),
                PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true)
            )
        )
        // the user's own position: a red dot with a halo (different shape and colour from the customer pins)
        st.addLayer(
            CircleLayer(L_ME_HALO, SRC_ME).withProperties(
                PropertyFactory.circleRadius(24f),
                PropertyFactory.circleColor(Color.parseColor("#EF4444")),
                PropertyFactory.circleOpacity(0.22f)
            )
        )
        st.addLayer(
            CircleLayer(L_ME, SRC_ME).withProperties(
                PropertyFactory.circleRadius(9f),
                PropertyFactory.circleColor(Color.parseColor("#EF4444")),
                PropertyFactory.circleStrokeWidth(3f),
                PropertyFactory.circleStrokeColor(Color.WHITE)
            )
        )
    }

    private fun toggleSat() {
        val m = map ?: return
        sat = !sat
        loadStyle(m)
    }

    /* ---------------- data ---------------- */

    private fun onData() {
        unionBar.refresh()
        refreshData()
    }

    private fun visible(): List<Loc> {
        val q = search.edit.text.toString().trim().lowercase()
        val out = ArrayList<Loc>()
        for (l in Repo.locs.values) {
            if (l.isNew || !Repo.unionOk(l.union)) continue
            if (q.isNotEmpty() && !l.name.lowercase().contains(q) && !l.father.lowercase().contains(q) &&
                !l.spouse.lowercase().contains(q) && !l.village.lowercase().contains(q)
            ) continue
            out.add(l)
        }
        return out
    }

    private fun refreshData() {
        val st = style ?: return
        val list = visible()
        val fs = ArrayList<Feature>(list.size)
        for (l in list) {
            val f = Feature.fromGeometry(Point.fromLngLat(l.lng, l.lat))
            f.addStringProperty("id", l.id)
            f.addNumberProperty("a", if (l.active) 1 else 0)
            fs.add(f)
        }
        st.getSourceAs<GeoJsonSource>(SRC)?.setGeoJson(FeatureCollection.fromFeatures(fs))
        countPill.text = "${list.size} pins"
        if (pendingInitial && list.isNotEmpty() && map != null) {
            pendingInitial = false
            initialView()
        }
    }

    private fun fitAll() {
        val m = map ?: return
        val list = visible()
        if (list.isEmpty()) return
        val pts = list.map { LatLng(it.lat, it.lng) }
        val minLat = pts.minOf { it.latitude }
        val maxLat = pts.maxOf { it.latitude }
        val minLng = pts.minOf { it.longitude }
        val maxLng = pts.maxOf { it.longitude }
        if (pts.size == 1 || (maxLat - minLat < 0.0002 && maxLng - minLng < 0.0002)) {
            m.animateCamera(CameraUpdateFactory.newLatLngZoom(pts[0], 16.0))
        } else {
            val b = LatLngBounds.Builder().include(LatLng(minLat, minLng)).include(LatLng(maxLat, maxLng)).build()
            m.animateCamera(CameraUpdateFactory.newLatLngBounds(b, h.dp(70)))
        }
    }

    override fun onShow() {
        pendingInitial = true
        located = false
        refreshData()
    }

    /* ---------------- tap & card ---------------- */

    private fun onTap(m: MapLibreMap, ll: LatLng): Boolean {
        val pt = m.projection.toScreenLocation(ll)
        val r = h.dp(16).toFloat()
        val area = RectF(pt.x - r, pt.y - r, pt.x + r, pt.y + r)
        val ft = m.queryRenderedFeatures(area, L_ON, L_OFF)
        if (ft.isNotEmpty()) {
            select(ft[0].getStringProperty("id"))
            return true
        }
        select(null)
        return false
    }

    private fun select(id: String?) {
        selId = id
        val st = style
        val src = st?.getSourceAs<GeoJsonSource>(SRC_SEL)
        val l = if (id != null) Repo.locs[id] else null
        if (l == null) {
            src?.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
            card.visibility = View.GONE
            return
        }
        src?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(l.lng, l.lat)))
        buildCard(l)
        card.visibility = View.VISIBLE
    }

    private fun cardRow(k: String, v: String) {
        val r = h.hbox()
        r.addView(h.label(k, 13f, C.muted), LinearLayout.LayoutParams(h.dp(64), WRAP))
        r.addView(h.label(if (v.isBlank()) "-" else v, 15f, C.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        card.addView(r, h.lp(7))
    }

    private fun buildCard(l: Loc) {
        card.removeAllViews()
        val top = h.hbox()
        top.addView(h.label("Customer", 12f, C.primary, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (!l.active) top.addView(h.pill("Loan closed", C.warn))
        val x = h.icon(R.drawable.ic_close, C.muted, 20)
        x.setPadding(h.dp(6), h.dp(6), h.dp(6), h.dp(6))
        x.setOnClickListener { select(null) }
        top.addView(x, LinearLayout.LayoutParams(h.dp(32), h.dp(32)).apply { leftMargin = h.dp(6) })
        card.addView(top)
        cardRow("Name", l.name)
        cardRow("Father", l.father)
        cardRow("Spouse", l.spouse)
        cardRow("Village", l.village)

        val inRoute = Repo.route().contains(l.id)
        val acts = h.hbox()
        fun act(res: Int, t: String, on: () -> Unit) {
            val b = h.vbox()
            b.gravity = Gravity.CENTER
            b.setPadding(0, h.dp(8), 0, h.dp(8))
            b.background = h.ripple(h.shape(C.soft, 12), 12)
            b.addView(h.icon(res, C.primary, 20), LinearLayout.LayoutParams(h.dp(20), h.dp(20)))
            b.addView(h.label(t, 11f, C.primary, true), h.lp(3, WRAP, WRAP))
            b.isClickable = true
            b.setOnClickListener { on() }
            acts.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(6) })
        }
        act(R.drawable.ic_phone, "Call") { Act.call(h, l.phone) }
        act(R.drawable.ic_nav, "Navigate") { Act.navigate(h, l.lat, l.lng, l.name) }
        act(R.drawable.ic_note, "Details") { Details.open(h, Repo.custFor(l), l) }
        act(if (inRoute) R.drawable.ic_close else R.drawable.ic_route, if (inRoute) "Remove" else "Route") {
            val r = Repo.route()
            if (inRoute) r.remove(l.id) else r.add(l.id)
            Repo.setRoute(r)
            buildCard(l)
        }
        card.addView(acts, h.lp(12))
    }

    /* ---------------- my location / nearby ---------------- */

    private fun locate(cb: (android.location.Location) -> Unit) {
        h.needLocation { ok ->
            if (!ok) {
                h.toast("Location permission is needed")
            } else {
                gps?.stop()
                var done = false
                val g = Gps(h) { l ->
                    if (!done && l.accuracy <= 60f) {
                        done = true
                        gps?.stop()
                        cb(l)
                    }
                }
                gps = g
                if (!g.start()) {
                    h.toast("Turn on GPS / location in phone settings")
                } else {
                    handler.postDelayed({
                        if (!done) {
                            done = true
                            g.stop()
                            val b = g.best
                            if (b != null) cb(b) else h.toast("Could not get your location")
                        }
                    }, 12000L)
                }
            }
        }
    }

    private fun setMe(lat: Double, lng: Double) {
        val f = Feature.fromGeometry(Point.fromLngLat(lng, lat))
        meFeature = f
        style?.getSourceAs<GeoJsonSource>(SRC_ME)?.setGeoJson(f)
    }

    private fun myLocation() {
        locate { l ->
            setMe(l.latitude, l.longitude)
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(l.latitude, l.longitude), 16.0))
        }
    }

    /** When the map opens: the user's own location is shown (red dot) and the map zooms out to the customers around it. */
    private fun initialView() {
        if (Repo.hasFix) {
            setMe(Repo.lastLat, Repo.lastLng)
            showAround(Repo.lastLat, Repo.lastLng)
            located = true
        }
        locate { l ->
            located = true
            setMe(l.latitude, l.longitude)
            showAround(l.latitude, l.longitude)
        }
        // no location (permission / GPS off): show all customers instead
        handler.postDelayed({ if (!located) fitAll() }, 14000L)
    }

    private fun showAround(lat: Double, lng: Double) {
        val m = map ?: return
        val me = LatLng(lat, lng)
        val near = visible().filter { distM(lat, lng, it.lat, it.lng) <= 3000.0 }
            .sortedBy { distM(lat, lng, it.lat, it.lng) }.take(80)
        if (near.isEmpty()) {
            m.animateCamera(CameraUpdateFactory.newLatLngZoom(me, 14.0))
            return
        }
        val b = LatLngBounds.Builder().include(me)
        for (l in near) b.include(LatLng(l.lat, l.lng))
        val pad = intArrayOf(h.dp(40), h.dp(150), h.dp(40), h.dp(70))
        val cp = m.getCameraForLatLngBounds(b.build(), pad)
        if (cp == null) {
            m.animateCamera(CameraUpdateFactory.newLatLngZoom(me, 14.0))
        } else {
            val z = cp.zoom.coerceIn(12.0, 16.0)
            m.animateCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.Builder(cp).zoom(z).build()))
        }
    }

    private fun nearby() {
        locate { l ->
            setMe(l.latitude, l.longitude)
            val list = visible().sortedBy { distM(l.latitude, l.longitude, it.lat, it.lng) }.take(15)
            if (list.isEmpty()) {
                h.toast("No customer pins to show")
            } else {
                val items = list.map {
                    it.name + "  \u2022  " + it.village + "\n" + fmtDist(distM(l.latitude, l.longitude, it.lat, it.lng))
                }.toTypedArray()
                AlertDialog.Builder(h).setTitle("Nearest customers")
                    .setItems(items) { _, i ->
                        val p = list[i]
                        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(p.lat, p.lng), 17.0))
                        select(p.id)
                    }
                    .setNegativeButton("Close", null).show()
            }
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacksAndMessages(null)
        gps?.stop()
        h.unregisterMap(mv)
    }
}

/** Customers chosen for today's visit (kept on this phone). */
class RouteScreen private constructor(private val h: HomeActivity) {
    val root = h.vbox()
    private val body = h.vbox()
    private val listener: () -> Unit = { fill() }

    companion object {
        fun open(h: HomeActivity) {
            val r = RouteScreen(h)
            h.push(r.root) { Repo.removeListener(r.listener) }
            Repo.addListener(r.listener)
            r.fill()
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(Header(h, "Route list", "Customers to visit", { h.pop() }).root)
        val sv = ScrollView(h)
        body.setPadding(h.dp(14), h.dp(8), h.dp(14), h.dp(24))
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun fill() {
        body.removeAllViews()
        val ids = Repo.route().filter { Repo.locs.containsKey(it) }
        if (ids.isEmpty()) {
            val c = h.card()
            c.addView(h.label("No customers in the route yet.", 15f, C.text, true))
            c.addView(h.label("Open a pin on the map and tap Route to add the customer here.", 13f, C.muted), h.lp(6))
            body.addView(c, h.lp(12))
            return
        }
        for ((i, id) in ids.withIndex()) {
            val l = Repo.locs[id] ?: continue
            val r = h.hbox()
            r.background = h.shape(Color.WHITE, 14, C.line)
            r.setPadding(h.dp(12), h.dp(10), h.dp(8), h.dp(10))
            val n = h.label("${i + 1}", 14f, Color.WHITE, true)
            n.gravity = Gravity.CENTER
            n.background = h.shape(C.primary, 16)
            r.addView(n, LinearLayout.LayoutParams(h.dp(30), h.dp(30)))
            val col = h.vbox()
            col.addView(h.label(l.name, 15f, C.text, true))
            val dist = if (Repo.hasFix) "  \u2022  " + fmtDist(distM(Repo.lastLat, Repo.lastLng, l.lat, l.lng)) else ""
            col.addView(h.label(l.village + dist, 12f, C.muted), h.lp(2))
            r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = h.dp(12) })
            val up = h.icon(R.drawable.ic_up, C.muted, 22)
            up.setOnClickListener { move(ids, i, -1) }
            val dn = h.icon(R.drawable.ic_down, C.muted, 22)
            dn.setOnClickListener { move(ids, i, 1) }
            val rm = h.icon(R.drawable.ic_close, C.bad, 20)
            rm.setOnClickListener { Repo.setRoute(ids.filter { it != id }) }
            for (v in listOf(up, dn, rm)) {
                v.setPadding(h.dp(6), h.dp(6), h.dp(6), h.dp(6))
                r.addView(v, LinearLayout.LayoutParams(h.dp(36), h.dp(36)))
            }
            body.addView(r, h.lp(8))
        }
        body.addView(h.btn("Nearest first (optimize order)", 1, R.drawable.ic_route) { optimize(ids) }, h.lp(16))
        body.addView(h.btn("Start navigation in Google Maps", 0, R.drawable.ic_nav) { start(ids) }, h.lp(10))
        body.addView(h.btn("Clear route", 2) { Repo.setRoute(emptyList()) }, h.lp(10))
    }

    private fun move(ids: List<String>, i: Int, d: Int) {
        val j = i + d
        if (j < 0 || j >= ids.size) return
        val m = ids.toMutableList()
        val t = m[i]
        m[i] = m[j]
        m[j] = t
        Repo.setRoute(m)
    }

    private fun optimize(ids: List<String>) {
        val left = ids.mapNotNull { Repo.locs[it] }.toMutableList()
        val out = ArrayList<String>()
        var lat = if (Repo.hasFix) Repo.lastLat else left[0].lat
        var lng = if (Repo.hasFix) Repo.lastLng else left[0].lng
        while (left.isNotEmpty()) {
            val a = lat
            val b = lng
            val next = left.minByOrNull { distM(a, b, it.lat, it.lng) } ?: break
            out.add(next.id)
            lat = next.lat
            lng = next.lng
            left.remove(next)
        }
        Repo.setRoute(out)
    }

    private fun start(ids: List<String>) {
        val pts = ids.mapNotNull { Repo.locs[it] }.map { Pair(it.lat, it.lng) }
        if (pts.size > 10) h.toast("Google Maps takes 10 stops at a time. Using the first 10.")
        Act.navigateRoute(h, pts.take(10))
    }
}
