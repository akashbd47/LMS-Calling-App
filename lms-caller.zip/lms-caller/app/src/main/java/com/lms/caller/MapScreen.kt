package com.lms.caller

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.Point

/** Draws the teardrop pin images used on the map (no clustering, every customer has its own pin). */
private object Pins {
    const val ON = "pin-on"
    const val OFF = "pin-off"
    const val ME = "pin-me"
    const val SEL = "pin-sel"

    // top / bottom gradient colours of each pin (change here to re-colour the map)
    private val C_ON = intArrayOf(Color.parseColor("#4ADE80"), Color.parseColor("#15803D"))
    private val C_OFF = intArrayOf(Color.parseColor("#CBD5E1"), Color.parseColor("#64748B"))
    private val C_ME = intArrayOf(Color.parseColor("#60A5FA"), Color.parseColor("#1D4ED8"))
    private val C_SEL = intArrayOf(Color.parseColor("#FCD34D"), Color.parseColor("#D97706"))

    fun install(h: HomeActivity, st: Style) {
        st.addImage(ON, make(h, 32, 42, C_ON, false))
        st.addImage(OFF, make(h, 32, 42, C_OFF, false))
        st.addImage(ME, make(h, 40, 52, C_ME, true))
        st.addImage(SEL, make(h, 40, 52, C_SEL, false))
    }

    private fun make(h: HomeActivity, wDp: Int, hDp: Int, col: IntArray, person: Boolean): Bitmap {
        val d = h.resources.displayMetrics.density
        val w = (wDp * d).toInt()
        val ht = (hDp * d).toInt()
        val bmp = Bitmap.createBitmap(w, ht, Bitmap.Config.ARGB_8888)
        bmp.density = h.resources.displayMetrics.densityDpi
        val c = Canvas(bmp)
        val pad = 4f * d
        val r = w / 2f - pad
        val cx = w / 2f
        val cy = 3f * d + r
        val tipY = ht - 3f * d
        val dist = tipY - cy
        val alpha = Math.toDegrees(Math.acos((r / dist).toDouble())).toFloat()
        val a1 = 90f + alpha
        val lx = cx + r * Math.cos(Math.toRadians(a1.toDouble())).toFloat()
        val ly = cy + r * Math.sin(Math.toRadians(a1.toDouble())).toFloat()

        val path = Path()
        path.moveTo(cx, tipY)
        path.lineTo(lx, ly)
        path.arcTo(RectF(cx - r, cy - r, cx + r, cy + r), a1, 360f - 2f * alpha)
        path.close()

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, cy - r, 0f, tipY, col[0], col[1], Shader.TileMode.CLAMP)
        p.setShadowLayer(3f * d, 0f, 1.5f * d, Color.parseColor("#55000000"))
        c.drawPath(path, p)

        p.clearShadowLayer()
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.strokeJoin = Paint.Join.ROUND
        p.color = Color.WHITE
        c.drawPath(path, p)

        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(cx, cy, r * 0.52f, p)
        p.color = col[1]
        if (person) {
            c.drawCircle(cx, cy - r * 0.12f, r * 0.17f, p)
            c.drawArc(RectF(cx - r * 0.3f, cy + r * 0.02f, cx + r * 0.3f, cy + r * 0.62f), 180f, 180f, true, p)
        } else {
            c.drawCircle(cx, cy, r * 0.22f, p)
        }
        return bmp
    }
}

class MapScreen(private val h: HomeActivity) : Screen {
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false

    private val root = object : FrameLayout(h) {
        override fun onWindowVisibilityChanged(visibility: Int) {
            super.onWindowVisibilityChanged(visibility)
            if (visibility == View.VISIBLE) resume()
        }

        override fun onVisibilityChanged(changedView: View, visibility: Int) {
            super.onVisibilityChanged(changedView, visibility)
            if (changedView === this && visibility == View.VISIBLE) resume()
        }
    }
    override val view: View get() = root

    private val mv = MapView(h)
    private var map: MapLibreMap? = null
    private var style: Style? = null
    private var sat = false
    private var focused = false
    private var selId: String? = null
    private var gps: Gps? = null
    private var fix: Location? = null
    private var fixCb: ((Location) -> Unit)? = null
    private var fixFail: () -> Unit = {}
    private var denied = false
    private var meFeature: Feature? = null
    private val card = h.vbox()
    private val legend = h.vbox()
    private val search = SearchBox(h, "Search name, father, spouse, village")
    private val unionBar: UnionBar
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshData() }

    private val fixTimeout = Runnable {
        val c = fixCb
        fixCb = null
        if (c != null) {
            val b = fix
            if (b != null) c(b) else {
                h.toast("Could not get your location")
                fixFail()
            }
        }
    }

    /** Runs while the map is on screen: pulses the "you" marker. Stops (and stops GPS) when the map is hidden. */
    private val tick = object : Runnable {
        override fun run() {
            if (root.windowVisibility != View.VISIBLE || !root.isShown) {
                stopTracking()
                return
            }
            pulse()
            handler.postDelayed(this, 60L)
        }
    }

    companion object {
        const val SRC = "locs"
        const val SRC_SEL = "sel"
        const val SRC_ME = "me"
        const val L_LABEL = "l-label"
        const val L_ON = "l-on"
        const val L_OFF = "l-off"
        const val L_SEL = "l-sel"
        const val L_HALO = "l-halo"
        const val L_ME = "l-me"
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(mv, FrameLayout.LayoutParams(MATCH, MATCH))

        val top = h.vbox()
        top.setPadding(h.dp(10), h.dp(10), h.dp(10), 0)
        search.root.background = h.shape(Color.WHITE, 26)
        search.root.elevation = h.dp(6).toFloat()
        search.edit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.edit.setOnEditorActionListener { v, _, _ ->
            fitAll()
            (h.getSystemService(InputMethodManager::class.java)).hideSoftInputFromWindow(v.windowToken, 0)
            true
        }
        top.addView(search.root)
        unionBar = UnionBar(h) { refreshData() }
        unionBar.root.elevation = h.dp(6).toFloat()
        val row = h.hbox()
        row.addView(unionBar.root)
        top.addView(row, h.lp(8))
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        val fabs = h.vbox()
        fun addFab(res: Int, onClick: () -> Unit) {
            val f = h.fab(res, C.primary, onClick)
            f.elevation = h.dp(6).toFloat()
            fabs.addView(f, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { topMargin = h.dp(10) })
        }
        addFab(R.drawable.ic_back) { h.select(HomeActivity.HOME) }
        addFab(R.drawable.ic_target) { myLocation() }
        addFab(R.drawable.ic_map) { fitAll() }
        addFab(R.drawable.ic_layers) { toggleSat() }
        addFab(R.drawable.ic_search) { nearby() }
        addFab(R.drawable.ic_route) { RouteScreen.open(h) }
        root.addView(fabs, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply {
            setMargins(0, h.dp(66), h.dp(10), 0)
        })

        // small colour legend (bottom-left, above the MapLibre logo); hidden while a customer card is open
        legend.background = h.shape(Color.WHITE, 14)
        legend.setPadding(h.dp(12), h.dp(8), h.dp(14), h.dp(8))
        legend.elevation = h.dp(4).toFloat()
        fun legendRow(color: Int, text: String) {
            val r = h.hbox()
            val dot = View(h)
            dot.background = h.shape(color, 6)
            r.addView(dot, LinearLayout.LayoutParams(h.dp(10), h.dp(10)).apply { rightMargin = h.dp(8) })
            r.addView(h.label(text, 12f, C.text, true))
            legend.addView(r, h.lp(if (legend.childCount == 0) 0 else 5))
        }
        legendRow(Color.parseColor("#2563EB"), "You")
        legendRow(Color.parseColor("#16A34A"), "Active loan")
        legendRow(Color.parseColor("#94A3B8"), "Loan closed")
        root.addView(legend, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(h.dp(10), 0, 0, h.dp(46))
        })

        card.background = h.shape(Color.WHITE, 22)
        card.setPadding(h.dp(16), h.dp(10), h.dp(16), h.dp(16))
        card.elevation = h.dp(12).toFloat()
        card.visibility = View.GONE
        root.addView(card, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply {
            setMargins(h.dp(10), 0, h.dp(10), h.dp(10))
        })

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 250)
            }
        })

        h.registerMap(mv)
        mv.getMapAsync { m ->
            map = m
            m.uiSettings.isRotateGesturesEnabled = false
            m.uiSettings.isCompassEnabled = false
            m.cameraPosition = CameraPosition.Builder().target(LatLng(23.7, 90.4)).zoom(6.0).build()
            m.addOnMapClickListener { ll -> onTap(m, ll) }
            loadStyle(m)
        }
        Repo.addListener(listener)
        ready = true
    }

    /* ---------------- style & layers ---------------- */

    private fun loadStyle(m: MapLibreMap) {
        MapStyle.apply(m, sat) { st ->
            style = st
            setupLayers(st)
            refreshData()
            select(selId)
            meFeature?.let { st.getSourceAs<GeoJsonSource>(SRC_ME)?.setGeoJson(it) }
        }
    }

    private fun pinLayer(id: String, src: String, image: String): SymbolLayer =
        SymbolLayer(id, src).withProperties(
            PropertyFactory.iconImage(image),
            PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
            PropertyFactory.iconAllowOverlap(true),
            PropertyFactory.iconIgnorePlacement(true)
        )

    private fun setupLayers(st: Style) {
        Pins.install(h, st)
        // no clustering: every customer is drawn as its own pin
        st.addSource(GeoJsonSource(SRC, FeatureCollection.fromFeatures(ArrayList<Feature>())))
        st.addSource(GeoJsonSource(SRC_SEL, FeatureCollection.fromFeatures(ArrayList<Feature>())))
        st.addSource(GeoJsonSource(SRC_ME, FeatureCollection.fromFeatures(ArrayList<Feature>())))

        // customer name, only when zoomed in
        val label = SymbolLayer(L_LABEL, SRC).withProperties(
            PropertyFactory.textField(Expression.toString(Expression.get("n"))),
            PropertyFactory.textFont(arrayOf(MapStyle.font(sat))),
            PropertyFactory.textSize(11f),
            PropertyFactory.textAnchor(Property.TEXT_ANCHOR_TOP),
            PropertyFactory.textOffset(arrayOf(0f, 0.3f)),
            PropertyFactory.textMaxWidth(8f),
            PropertyFactory.textOptional(true),
            PropertyFactory.textColor(if (sat) Color.WHITE else Color.parseColor("#0F172A")),
            PropertyFactory.textHaloColor(if (sat) Color.parseColor("#CC000000") else Color.WHITE),
            PropertyFactory.textHaloWidth(1.6f)
        )
        label.minZoom = 15.5f
        st.addLayer(label)

        st.addLayer(
            pinLayer(L_OFF, SRC, Pins.OFF).withFilter(Expression.eq(Expression.get("a"), Expression.literal(0)))
                .withProperties(PropertyFactory.symbolSortKey(Expression.get("sk")))
        )
        st.addLayer(
            pinLayer(L_ON, SRC, Pins.ON).withFilter(Expression.eq(Expression.get("a"), Expression.literal(1)))
                .withProperties(PropertyFactory.symbolSortKey(Expression.get("sk")))
        )
        st.addLayer(pinLayer(L_SEL, SRC_SEL, Pins.SEL))

        // "you": pulsing ring on the ground + a differently coloured pin on top
        st.addLayer(
            CircleLayer(L_HALO, SRC_ME).withProperties(
                PropertyFactory.circleColor(Color.parseColor("#2563EB")),
                PropertyFactory.circleRadius(8f),
                PropertyFactory.circleOpacity(0.3f)
            )
        )
        st.addLayer(pinLayer(L_ME, SRC_ME, Pins.ME))
    }

    private fun pulse() {
        if (meFeature == null) return
        val t = (System.currentTimeMillis() % 2000L) / 2000f
        val r = 6f + 30f * t
        val o = 0.45f * (1f - t) * (1f - t)
        style?.getLayerAs<CircleLayer>(L_HALO)?.setProperties(
            PropertyFactory.circleRadius(r),
            PropertyFactory.circleOpacity(o)
        )
    }

    private fun toggleSat() {
        val m = map ?: return
        sat = !sat
        loadStyle(m)
    }

    /* ---------------- data ---------------- */

    private fun onData() {
        unionBar.refresh()
        refreshData()
    }

    private fun visible(): List<Loc> {
        val q = search.edit.text.toString().trim().lowercase()
        val out = ArrayList<Loc>()
        for (l in Repo.locs.values) {
            if (l.isNew || !Repo.unionOk(l.union)) continue
            if (q.isNotEmpty() && !l.name.lowercase().contains(q) && !l.father.lowercase().contains(q) &&
                !l.spouse.lowercase().contains(q) && !l.village.lowercase().contains(q)
            ) continue
            out.add(l)
        }
        return out
    }

    private fun refreshData() {
        val st = style ?: return
        val list = visible()
        val fs = ArrayList<Feature>(list.size)
        for (l in list) {
            val f = Feature.fromGeometry(Point.fromLngLat(l.lng, l.lat))
            f.addStringProperty("id", l.id)
            f.addStringProperty("n", l.name)
            f.addNumberProperty("a", if (l.active) 1 else 0)
            f.addNumberProperty("sk", -l.lat)   // southern pins are drawn on top of northern ones
            fs.add(f)
        }
        st.getSourceAs<GeoJsonSource>(SRC)?.setGeoJson(FeatureCollection.fromFeatures(fs))
        if (!focused && list.isNotEmpty()) autoFocus()
    }

    private fun fitAll() {
        val m = map ?: return
        val list = visible()
        if (list.isEmpty()) return
        val pts = list.map { LatLng(it.lat, it.lng) }
        val minLat = pts.minOf { it.latitude }
        val maxLat = pts.maxOf { it.latitude }
        val minLng = pts.minOf { it.longitude }
        val maxLng = pts.maxOf { it.longitude }
        if (pts.size == 1 || (maxLat - minLat < 0.0002 && maxLng - minLng < 0.0002)) {
            m.animateCamera(CameraUpdateFactory.newLatLngZoom(pts[0], 16.0))
        } else {
            val b = LatLngBounds.Builder().include(LatLng(minLat, minLng)).include(LatLng(maxLat, maxLng)).build()
            m.animateCamera(CameraUpdateFactory.newLatLngBounds(b, h.dp(70)))
        }
    }

    override fun onShow() {
        refreshData()
        resume()
    }

    /* ---------------- tap & card ---------------- */

    private fun onTap(m: MapLibreMap, ll: LatLng): Boolean {
        val pt = m.projection.toScreenLocation(ll)
        val r = h.dp(16).toFloat()
        val area = RectF(pt.x - r, pt.y - r, pt.x + r, pt.y + r)
        val ft = m.queryRenderedFeatures(area, L_ON, L_OFF)
        if (ft.isNotEmpty()) {
            val id = ft[0].getStringProperty("id")
            select(id)
            val l = Repo.locs[id]
            if (l != null) {
                val z = Math.max(m.cameraPosition.zoom, 14.5)
                m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(l.lat, l.lng), z), 350)
            }
            return true
        }
        select(null)
        return false
    }

    private fun select(id: String?) {
        selId = id
        val st = style
        val src = st?.getSourceAs<GeoJsonSource>(SRC_SEL)
        val l = if (id != null) Repo.locs[id] else null
        if (l == null) {
            src?.setGeoJson(FeatureCollection.fromFeatures(ArrayList<Feature>()))
            card.visibility = View.GONE
            legend.visibility = View.VISIBLE
            return
        }
        src?.setGeoJson(Feature.fromGeometry(Point.fromLngLat(l.lng, l.lat)))
        buildCard(l)
        card.visibility = View.VISIBLE
        legend.visibility = View.GONE
    }

    private fun infoRow(parent: LinearLayout, k: String, v: String) {
        if (v.isBlank()) return
        val r = h.hbox()
        r.addView(h.label(k, 12f, C.muted), LinearLayout.LayoutParams(h.dp(58), WRAP))
        r.addView(h.label(v, 14f, C.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        parent.addView(r, h.lp(if (parent.childCount == 0) 0 else 6))
    }

    private fun buildCard(l: Loc) {
        card.removeAllViews()

        val handle = View(h)
        handle.background = h.shape(C.line, 3)
        card.addView(handle, LinearLayout.LayoutParams(h.dp(36), h.dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = h.dp(12)
        })

        val head = h.hbox()
        val av = h.avatar(46)
        h.paintAvatar(av, l.name)
        head.addView(av)
        val col = h.vbox()
        val nm = h.label(l.name, 17f, C.text, true)
        nm.maxLines = 1
        nm.ellipsize = TextUtils.TruncateAt.END
        col.addView(nm)
        val f = fix
        val dist = if (f != null) "  \u2022  " + fmtDist(distM(f.latitude, f.longitude, l.lat, l.lng)) + " away" else ""
        val sub = h.label(l.village + dist, 12f, C.muted)
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END
        col.addView(sub, h.lp(2))
        head.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = h.dp(12) })
        head.addView(if (l.active) h.pill("Active", C.ok) else h.pill("Loan closed", C.warn))
        val x = h.icon(R.drawable.ic_close, C.muted, 20)
        x.setPadding(h.dp(6), h.dp(6), h.dp(6), h.dp(6))
        x.setOnClickListener { select(null) }
        head.addView(x, LinearLayout.LayoutParams(h.dp(32), h.dp(32)).apply { leftMargin = h.dp(4) })
        card.addView(head)

        if (l.father.isNotBlank() || l.spouse.isNotBlank()) {
            val panel = h.vbox()
            panel.background = h.shape(C.bg, 12)
            panel.setPadding(h.dp(12), h.dp(10), h.dp(12), h.dp(10))
            infoRow(panel, "Father", l.father)
            infoRow(panel, "Spouse", l.spouse)
            card.addView(panel, h.lp(12))
        }

        val inRoute = Repo.route().contains(l.id)
        val acts = h.hbox()
        fun act(res: Int, t: String, filled: Boolean, on: () -> Unit) {
            val b = h.vbox()
            b.gravity = Gravity.CENTER
            b.setPadding(0, h.dp(10), 0, h.dp(10))
            b.background = h.ripple(h.shape(if (filled) C.primary else C.soft, 14), 14)
            val fg = if (filled) Color.WHITE else C.primary
            b.addView(h.icon(res, fg, 20), LinearLayout.LayoutParams(h.dp(20), h.dp(20)))
            b.addView(h.label(t, 11f, fg, true), h.lp(3, WRAP, WRAP))
            b.isClickable = true
            b.setOnClickListener { on() }
            acts.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(6) })
        }
        act(R.drawable.ic_phone, "Call", true) { Act.call(h, l.phone) }
        act(R.drawable.ic_nav, "Navigate", false) { Act.navigate(h, l.lat, l.lng, l.name) }
        act(R.drawable.ic_note, "Details", false) { Details.open(h, Repo.custFor(l), l) }
        act(if (inRoute) R.drawable.ic_close else R.drawable.ic_route, if (inRoute) "Remove" else "Route", false) {
            val r = Repo.route()
            if (inRoute) r.remove(l.id) else r.add(l.id)
            Repo.setRoute(r)
            buildCard(l)
        }
        card.addView(acts, h.lp(12))
    }

    /* ---------------- my location (live) ---------------- */

    /** Called when the map becomes visible: start the pulse and the GPS tracking. */
    private fun resume() {
        if (!ready) return
        handler.removeCallbacks(tick)
        handler.post(tick)
        ensureTracking(false)
    }

    private fun ensureTracking(user: Boolean, onFail: () -> Unit = {}) {
        if (!user && denied) return
        h.needLocation { ok ->
            if (!ok) {
                denied = true
                if (user) h.toast("Location permission is needed")
                onFail()
            } else if (gps?.isRunning != true) {
                val g = Gps(h) { l -> onFix(l) }
                gps = g
                if (!g.start()) {
                    h.toast("Turn on GPS / location in phone settings")
                    onFail()
                }
            }
        }
    }

    private fun stopTracking() {
        gps?.stop()
        handler.removeCallbacks(tick)
    }

    private fun onFix(l: Location) {
        fix = l
        val f = Feature.fromGeometry(Point.fromLngLat(l.longitude, l.latitude))
        meFeature = f
        style?.getSourceAs<GeoJsonSource>(SRC_ME)?.setGeoJson(f)
        val cb = fixCb
        if (cb != null && l.accuracy <= 60f) {
            fixCb = null
            handler.removeCallbacks(fixTimeout)
            cb(l)
        }
    }

    /** Gives [cb] the current fix (waits for one if GPS has just started). */
    private fun wantFix(user: Boolean, onFail: () -> Unit, cb: (Location) -> Unit) {
        val f = fix
        if (f != null && gps?.isRunning == true) {
            cb(f)
            return
        }
        fixCb = cb
        fixFail = onFail
        handler.removeCallbacks(fixTimeout)
        handler.postDelayed(fixTimeout, 12000L)
        ensureTracking(user) {
            fixCb = null
            handler.removeCallbacks(fixTimeout)
            onFail()
        }
    }

    /** First open: go to the user's place, zoomed out so the customers around are visible. No GPS -> show everyone. */
    private fun autoFocus() {
        if (focused) return
        focused = true
        wantFix(false, { fitAll() }) { l -> focusNearby(l) }
    }

    private fun focusNearby(l: Location) {
        val m = map ?: return
        val me = LatLng(l.latitude, l.longitude)
        val sorted = visible().map { Pair(it, distM(l.latitude, l.longitude, it.lat, it.lng)) }.sortedBy { it.second }
        var pick = sorted.filter { it.second <= 3000.0 }.take(30)
        if (pick.size < 6) pick = sorted.filter { it.second <= 15000.0 }.take(6)
        if (pick.isEmpty()) {
            m.animateCamera(CameraUpdateFactory.newLatLngZoom(me, 15.0), 900)
            return
        }
        val bb = LatLngBounds.Builder().include(me)
        for (p in pick) bb.include(LatLng(p.first.lat, p.first.lng))
        val pad = intArrayOf(h.dp(56), h.dp(150), h.dp(76), h.dp(70))
        val cp = m.getCameraForLatLngBounds(bb.build(), pad)
        if (cp == null) {
            m.animateCamera(CameraUpdateFactory.newLatLngZoom(me, 14.0), 900)
        } else {
            val z = cp.zoom.coerceIn(11.0, 17.0)
            m.animateCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.Builder(cp).zoom(z).build()), 900)
        }
    }

    private fun myLocation() {
        wantFix(true, {}) { l -> focusNearby(l) }
    }

    private fun nearby() {
        wantFix(true, {}) { l ->
            val list = visible().sortedBy { distM(l.latitude, l.longitude, it.lat, it.lng) }.take(15)
            if (list.isEmpty()) {
                h.toast("No customer pins to show")
            } else {
                val items = list.map {
                    it.name + "  \u2022  " + it.village + "\n" + fmtDist(distM(l.latitude, l.longitude, it.lat, it.lng))
                }.toTypedArray()
                AlertDialog.Builder(h).setTitle("Nearest customers")
                    .setItems(items) { _, i ->
                        val p = list[i]
                        select(p.id)
                        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(p.lat, p.lng), 17.0), 500)
                    }
                    .setNegativeButton("Close", null).show()
            }
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacksAndMessages(null)
        gps?.stop()
        h.unregisterMap(mv)
    }
}

/** Customers chosen for today's visit (kept on this phone). */
class RouteScreen private constructor(private val h: HomeActivity) {
    val root = h.vbox()
    private val body = h.vbox()
    private val listener: () -> Unit = { fill() }

    companion object {
        fun open(h: HomeActivity) {
            val r = RouteScreen(h)
            h.push(r.root) { Repo.removeListener(r.listener) }
            Repo.addListener(r.listener)
            r.fill()
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(Header(h, "Route list", "Customers to visit", { h.pop() }).root)
        val sv = ScrollView(h)
        body.setPadding(h.dp(14), h.dp(8), h.dp(14), h.dp(24))
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun fill() {
        body.removeAllViews()
        val ids = Repo.route().filter { Repo.locs.containsKey(it) }
        if (ids.isEmpty()) {
            val c = h.card()
            c.addView(h.label("No customers in the route yet.", 15f, C.text, true))
            c.addView(h.label("Open a pin on the map and tap Route to add the customer here.", 13f, C.muted), h.lp(6))
            body.addView(c, h.lp(12))
            return
        }
        for ((i, id) in ids.withIndex()) {
            val l = Repo.locs[id] ?: continue
            val r = h.hbox()
            r.background = h.shape(Color.WHITE, 14, C.line)
            r.setPadding(h.dp(12), h.dp(10), h.dp(8), h.dp(10))
            val n = h.label("${i + 1}", 14f, Color.WHITE, true)
            n.gravity = Gravity.CENTER
            n.background = h.shape(C.primary, 16)
            r.addView(n, LinearLayout.LayoutParams(h.dp(30), h.dp(30)))
            val col = h.vbox()
            col.addView(h.label(l.name, 15f, C.text, true))
            val dist = if (Repo.hasFix) "  \u2022  " + fmtDist(distM(Repo.lastLat, Repo.lastLng, l.lat, l.lng)) else ""
            col.addView(h.label(l.village + dist, 12f, C.muted), h.lp(2))
            r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = h.dp(12) })
            val up = h.icon(R.drawable.ic_up, C.muted, 22)
            up.setOnClickListener { move(ids, i, -1) }
            val dn = h.icon(R.drawable.ic_down, C.muted, 22)
            dn.setOnClickListener { move(ids, i, 1) }
            val rm = h.icon(R.drawable.ic_close, C.bad, 20)
            rm.setOnClickListener { Repo.setRoute(ids.filter { it != id }) }
            for (v in listOf(up, dn, rm)) {
                v.setPadding(h.dp(6), h.dp(6), h.dp(6), h.dp(6))
                r.addView(v, LinearLayout.LayoutParams(h.dp(36), h.dp(36)))
            }
            body.addView(r, h.lp(8))
        }
        body.addView(h.btn("Nearest first (optimize order)", 1, R.drawable.ic_route) { optimize(ids) }, h.lp(16))
        body.addView(h.btn("Start navigation in Google Maps", 0, R.drawable.ic_nav) { start(ids) }, h.lp(10))
        body.addView(h.btn("Clear route", 2) { Repo.setRoute(emptyList()) }, h.lp(10))
    }

    private fun move(ids: List<String>, i: Int, d: Int) {
        val j = i + d
        if (j < 0 || j >= ids.size) return
        val m = ids.toMutableList()
        val t = m[i]
        m[i] = m[j]
        m[j] = t
        Repo.setRoute(m)
    }

    private fun optimize(ids: List<String>) {
        val left = ids.mapNotNull { Repo.locs[it] }.toMutableList()
        val out = ArrayList<String>()
        var lat = if (Repo.hasFix) Repo.lastLat else left[0].lat
        var lng = if (Repo.hasFix) Repo.lastLng else left[0].lng
        while (left.isNotEmpty()) {
            val a = lat
            val b = lng
            val next = left.minByOrNull { distM(a, b, it.lat, it.lng) } ?: break
            out.add(next.id)
            lat = next.lat
            lng = next.lng
            left.remove(next)
        }
        Repo.setRoute(out)
    }

    private fun start(ids: List<String>) {
        val pts = ids.mapNotNull { Repo.locs[it] }.map { Pair(it.lat, it.lng) }
        if (pts.size > 10) h.toast("Google Maps takes 10 stops at a time. Using the first 10.")
        Act.navigateRoute(h, pts.take(10))
    }
}
