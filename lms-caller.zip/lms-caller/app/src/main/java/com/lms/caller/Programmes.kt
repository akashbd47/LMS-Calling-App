package com.lms.caller

object Programmes {
    /** "0110" + "Jubo Rin" -> "0110 - Jubo Rin"; without a name only the code is shown. */
    fun label(code: String, name: String): String {
        val c = code.trim()
        val n = name.trim()
        return when {
            c.isEmpty() && n.isEmpty() -> "-"
            n.isEmpty() -> c
            c.isEmpty() -> n
            else -> "$c - $n"
        }
    }
}
