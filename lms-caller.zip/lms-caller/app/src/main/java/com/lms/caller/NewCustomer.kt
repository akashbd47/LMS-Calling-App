package com.lms.caller

import android.app.AlertDialog
import android.graphics.Color
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView

/** Full-screen customer search (same list as the Customers module); [onPick] gets the tapped customer. */
class CustomerPicker private constructor(
    private val h: HomeActivity, title: String, subText: String, private val onPick: (Cust) -> Unit
) {
    val root = h.vbox()
    private val header = Header(h, title, subText, { h.pop() })
    private val search = SearchBox(h, "Search name, father, spouse, phone, L/C no")
    private val count = h.label("", 13f, C.primary, true)
    private val list = CustList(h, 0) { onPick(it) }
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private val listener: () -> Unit = { refresh() }
    private val doSearch = Runnable { refresh() }

    companion object {
        fun open(h: HomeActivity, title: String, subText: String, onPick: (Cust) -> Unit) {
            val p = CustomerPicker(h, title, subText, onPick)
            h.push(p.root) { p.close() }
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { refresh() }
        header.addChip(unionBar.root)
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(list.view, LinearLayout.LayoutParams(MATCH, 0, 1f))
        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        refresh()
    }

    private fun refresh() {
        unionBar.refresh()
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Cust>()
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) ||
                    c.sCase.contains(q) || (digits.isNotEmpty() && c.sPhone.contains(digits)))) continue
            out.add(c)
        }
        if (q.isEmpty()) out.sortBy { it.sName }
        else out.sortWith(compareBy<Cust>({ if (it.sName.startsWith(q)) 0 else 1 }, { it.sName }))
        count.text = "${out.size} customers"
        list.submit(out)
    }

    private fun close() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}

/** Map with a fixed red target: move the map under it (or use GPS), then "Use this location". */
class PinPicker private constructor(
    private val h: HomeActivity, title: String, subText: String,
    private val initial: DoubleArray?,
    private val onPicked: (Double, Double, Double, String) -> Unit
) {
    val root = h.vbox()
    private val mv = MapView(h)
    private var map: MapLibreMap? = null
    private var sat = false
    private var moved = false
    private var gps: Gps? = null
    private var gpsFix: Location? = null
    private val handler = Handler(Looper.getMainLooper())
    private val gpsText: TextView = h.label("GPS not started", 13f, C.muted)

    companion object {
        /** [initial] = {lat, lng} to open on, or null. [onPicked] = (lat, lng, accuracy, "gps" | "manual"). */
        fun open(h: HomeActivity, title: String, subText: String, initial: DoubleArray?, onPicked: (Double, Double, Double, String) -> Unit) {
            val p = PinPicker(h, title, subText, initial, onPicked)
            h.push(p.root) { p.close() }
            p.start()
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(Header(h, title, subText, { h.pop() }).root)

        val mapBox = FrameLayout(h)
        mapBox.addView(mv, FrameLayout.LayoutParams(MATCH, MATCH))
        val target = h.icon(R.drawable.ic_target, C.bad, 36)
        mapBox.addView(target, FrameLayout.LayoutParams(h.dp(36), h.dp(36), Gravity.CENTER))
        val tip = h.label("Move the map so the red target is exactly on the house", 12f, C.text, true)
        tip.background = h.shape(Color.WHITE, 12)
        tip.setPadding(h.dp(12), h.dp(8), h.dp(12), h.dp(8))
        tip.elevation = h.dp(3).toFloat()
        mapBox.addView(tip, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
            setMargins(h.dp(10), h.dp(10), h.dp(70), 0)
        })
        val satBtn = h.fab(R.drawable.ic_layers) { toggleSat() }
        mapBox.addView(satBtn, FrameLayout.LayoutParams(h.dp(46), h.dp(46), Gravity.TOP or Gravity.END).apply {
            setMargins(0, h.dp(10), h.dp(10), 0)
        })
        root.addView(mapBox, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bottom = h.vbox()
        bottom.setBackgroundColor(Color.WHITE)
        bottom.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(14))
        bottom.elevation = h.dp(8).toFloat()
        bottom.addView(gpsText)
        val row = h.hbox()
        row.addView(h.btn("Use GPS", 1, R.drawable.ic_target) { startGps() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(8) })
        row.addView(h.btn("Use this location", 0, R.drawable.ic_pin) { pick() }, LinearLayout.LayoutParams(0, WRAP, 1.4f))
        bottom.addView(row, h.lp(10))
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun start() {
        h.registerMap(mv)
        mv.getMapAsync { m ->
            map = m
            m.uiSettings.isRotateGesturesEnabled = false
            m.uiSettings.isCompassEnabled = false
            val ini = initial
            val cam = when {
                ini != null -> CameraPosition.Builder().target(LatLng(ini[0], ini[1])).zoom(18.0).build()
                Repo.hasFix -> CameraPosition.Builder().target(LatLng(Repo.lastLat, Repo.lastLng)).zoom(17.0).build()
                else -> CameraPosition.Builder().target(LatLng(23.7, 90.4)).zoom(6.0).build()
            }
            m.cameraPosition = cam
            m.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) moved = true
            }
            MapStyle.apply(m, false) { }
        }
        if (initial == null) startGps()
    }

    private fun toggleSat() {
        val m = map ?: return
        sat = !sat
        MapStyle.apply(m, sat) { }
    }

    private fun startGps() {
        h.needLocation { ok ->
            if (!ok) {
                h.toast("Location permission is needed to use GPS")
            } else {
                moved = false
                var g = gps
                if (g == null) {
                    g = Gps(h) { onFix(it) }
                    gps = g
                }
                if (g.start()) {
                    gpsText.setTextColor(C.muted)
                    gpsText.text = "Searching GPS... stay outside near the house"
                    handler.removeCallbacksAndMessages(null)
                    handler.postDelayed({ stopGps("GPS stopped") }, 45000L)
                } else {
                    gpsText.setTextColor(C.bad)
                    gpsText.text = "Location is turned off. Turn on GPS in phone settings."
                }
            }
        }
    }

    private fun stopGps(msg: String) {
        val g = gps ?: return
        if (!g.isRunning) return
        g.stop()
        val f = gpsFix
        if (f != null) gpsText.text = "$msg  \u2022  best accuracy \u00B1${f.accuracy.toInt()} m"
    }

    private fun onFix(l: Location) {
        gpsFix = l
        val a = l.accuracy.toInt()
        gpsText.setTextColor(if (a <= 20) C.ok else if (a <= 50) C.warn else C.bad)
        gpsText.text = "GPS accuracy \u00B1$a m" + if (a <= 20) "  (good)" else "  (improving...)"
        val m = map
        if (m != null && !moved) m.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(l.latitude, l.longitude), 18.0))
        if (a <= 12) {
            handler.removeCallbacksAndMessages(null)
            stopGps("GPS fixed")
        }
    }

    private fun pick() {
        val m = map
        if (m == null) { h.toast("Map is still loading"); return }
        val t = m.cameraPosition.target
        if (t == null) { h.toast("Map is still loading"); return }
        val fix = gpsFix
        val nearFix = fix != null && distM(fix.latitude, fix.longitude, t.latitude, t.longitude) < 15.0
        if (!nearFix && m.cameraPosition.zoom < 15.0) {
            h.toast("Zoom in and place the target exactly on the house")
            return
        }
        val acc = if (fix != null && nearFix) fix.accuracy.toDouble() else 0.0
        val source = if (nearFix) "gps" else "manual"
        val done = {
            h.pop()
            onPicked(t.latitude, t.longitude, acc, source)
        }
        if (nearFix && acc > 50.0) {
            AlertDialog.Builder(h).setMessage("GPS is weak (\u00B1${acc.toInt()} m). Use this location anyway?")
                .setPositiveButton("Yes") { _, _ -> done() }
                .setNegativeButton("Cancel", null).show()
        } else {
            done()
        }
    }

    private fun close() {
        handler.removeCallbacksAndMessages(null)
        gps?.stop()
        h.unregisterMap(mv)
    }
}

/** Home-visit form of a loan applicant: name, spouse/father, village, mobile + captured location. */
class NewCustomerEditor private constructor(private val h: HomeActivity) {
    val root = h.vbox()
    private val name: EditText = h.field("Customer name *", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
    private val rel: EditText = h.field("Spouse / Father name", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
    private val village: EditText = h.field("Village", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
    private val mobile: EditText = h.field("Mobile no", InputType.TYPE_CLASS_PHONE)
    private val locText: TextView = h.label("Location not captured yet", 14f, C.muted, true)
    private val locIcon: ImageView = h.icon(R.drawable.ic_pin, C.warn, 22)
    private var lat = 0.0
    private var lng = 0.0
    private var acc = 0.0
    private var source = ""
    private var captured = false

    companion object {
        fun open(h: HomeActivity) {
            val e = NewCustomerEditor(h)
            h.push(e.root)
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(Header(h, "New Customer", "Loan applicant home visit", { h.pop() }).root)

        val sv = ScrollView(h)
        val body = h.vbox()
        body.setPadding(h.dp(14), h.dp(14), h.dp(14), h.dp(20))

        val card = h.vbox()
        card.background = h.shape(Color.WHITE, 18, C.line)
        card.elevation = h.dp(1).toFloat()
        card.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(16))
        card.addView(h.label("APPLICANT", 11f, C.primary, true))
        card.addView(name, h.lp(8))
        card.addView(rel, h.lp(10))
        card.addView(village, h.lp(10))
        card.addView(mobile, h.lp(10))
        body.addView(card)

        val lc = h.hbox()
        lc.gravity = Gravity.CENTER_VERTICAL
        lc.background = h.shape(Color.WHITE, 18, C.line)
        lc.elevation = h.dp(1).toFloat()
        lc.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(14))
        lc.addView(locIcon, LinearLayout.LayoutParams(h.dp(26), h.dp(26)).apply { rightMargin = h.dp(12) })
        lc.addView(locText, LinearLayout.LayoutParams(0, WRAP, 1f))
        body.addView(lc, h.lp(12))
        body.addView(h.btn("Capture location", 1, R.drawable.ic_target) { capture() }, h.lp(10))
        body.addView(h.btn("Save new customer", 0, R.drawable.ic_person_add) { save() }, h.lp(10))
        body.addView(
            h.label("If this applicant gets the loan, open New Customer, tap Connect and choose the customer. The location is moved to that customer.", 12f, C.muted),
            h.lp(14)
        )
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun capture() {
        val ini = if (captured) doubleArrayOf(lat, lng) else null
        PinPicker.open(h, "Capture location", name.text.toString().trim(), ini) { la, lo, ac, src ->
            lat = la
            lng = lo
            acc = ac
            source = src
            captured = true
            locIcon.setColorFilter(C.ok)
            locText.setTextColor(C.ok)
            locText.text = "Location captured" + if (src == "gps" && ac > 0.0) "  (\u00B1${ac.toInt()} m)" else ""
        }
    }

    private fun save() {
        val n = name.text.toString().trim()
        if (n.isEmpty()) { h.toast("Enter the customer name"); return }
        if (!captured) { h.toast("Capture the location first"); return }
        val raw = mobile.text.toString().trim()
        var ph = ""
        if (raw.isNotEmpty()) {
            ph = normalizePhone(raw)
            if (ph.isEmpty()) { h.toast("Mobile number is not valid"); return }
        }
        Repo.saveNewCustomer(n, rel.text.toString().trim(), village.text.toString().trim(), ph, lat, lng, acc, source)
        h.toast("New customer saved")
        h.pop()
    }
}

/** New Customer module: the saved home-visit records that are not connected to a loan yet. */
class NewCustomerScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "New Customer", Repo.status, { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, village, mobile")
    private val count = h.label("", 13f, C.bad, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private var rows: List<Loc> = emptyList()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    init {
        root.setBackgroundColor(C.bg)
        header.action(h, R.drawable.ic_add) { NewCustomerEditor.open(h) }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))
        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(4), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))
        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    private fun onData() {
        header.sub.text = Repo.status
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Loc>()
        for (l in Repo.newCustomers()) {
            if (q.isNotEmpty() && !(l.name.lowercase().contains(q) || l.village.lowercase().contains(q) ||
                    l.father.lowercase().contains(q) || (digits.isNotEmpty() && normalizePhone(l.phone).contains(digits)))) continue
            out.add(l)
        }
        out.sortByDescending { it.updatedAt }
        count.text = "${out.size} new customers waiting for a loan"
        rows = out
        recycler.adapter?.notifyDataSetChanged()
    }

    private fun connect(l: Loc) {
        if (Repo.loans.isEmpty()) { h.toast("Customer data is not loaded yet"); return }
        CustomerPicker.open(h, "Connect: " + l.name, "Select the customer who got the loan") { c -> confirmConnect(l, c) }
    }

    private fun confirmConnect(l: Loc, c: Cust) {
        val msg = StringBuilder()
        msg.append("New customer:\n").append(l.name)
        val a = listOf(l.village, l.phone).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
        if (a.isNotEmpty()) msg.append("\n").append(a)
        msg.append("\n\nLoan customer:\n").append(c.name)
        val b = listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString(" / ")
        if (b.isNotEmpty()) msg.append("\n").append(b)
        msg.append("\nProgramme ").append(c.progLabel).append("  \u2022  L/C ").append(c.caseNo)
        msg.append("\n\nThe location will be added to this customer.")
        val old = Repo.locFor(c)
        if (old != null && old.id != l.id) msg.append("\nThis customer already has a location, it will be replaced.")
        AlertDialog.Builder(h)
            .setTitle("Connect?")
            .setMessage(msg.toString())
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Connect") { _, _ ->
                Repo.connectNew(l, c)
                h.pop()
                h.toast("Connected to " + c.name)
            }
            .show()
    }

    private fun confirmDelete(l: Loc) {
        AlertDialog.Builder(h)
            .setTitle("Delete record?")
            .setMessage(l.name + (if (l.village.isNotEmpty()) "\n" + l.village else "") + "\n\nThis new customer and the saved location will be deleted.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> Repo.deleteLoc(l.id) }
            .show()
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val avatar = h.avatar(44)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val connect = h.pill("Connect", C.primary, true)
        val delete = h.pill("Delete", C.bad)
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)
        val nav: ImageView = h.icon(R.drawable.ic_nav, C.primary, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            val top = h.hbox()
            top.gravity = Gravity.CENTER_VERTICAL
            top.addView(avatar, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { rightMargin = h.dp(12) })
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(1))
            top.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            top.addView(call, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { leftMargin = h.dp(6) })
            nav.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            nav.background = h.ripple(h.shape(C.soft, 24), 24)
            top.addView(nav, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { leftMargin = h.dp(6) })
            root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
            val acts = h.hbox()
            acts.addView(connect)
            acts.addView(delete, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(8) })
            root.addView(acts, h.lp(10, WRAP, WRAP))
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.vbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(12), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            fun at(): Loc? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            r.setOnClickListener { at()?.let { Details.open(h, null, it) } }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.phone) } }
            vh.nav.setOnClickListener { at()?.let { Act.navigate(h, it.lat, it.lng, it.name) } }
            vh.connect.setOnClickListener { at()?.let { connect(it) } }
            vh.delete.setOnClickListener { at()?.let { confirmDelete(it) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val l = rows[i]
            h.paintAvatar(v.avatar, l.name)
            v.name.text = l.name
            val a = ArrayList<String>()
            if (l.father.isNotEmpty()) a.add("Spouse/Father: " + l.father)
            v.l2.text = a.joinToString("")
            v.l2.gone(a.isEmpty())
            val b = listOf(l.village, l.phone).filter { it.isNotEmpty() }.toMutableList()
            b.add("by " + l.updatedBy + ", " + fmtDate(l.updatedAt))
            v.l3.text = b.joinToString("  \u2022  ")
            v.call.gone(l.phone.isBlank())
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
