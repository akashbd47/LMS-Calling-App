package com.lms.caller

import android.app.AlertDialog
import android.graphics.Color
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView

/** Full-screen customer search (same list as the Customers module); [onPick] gets the tapped customer. */
class CustomerPicker private constructor(
    private val h: HomeActivity, title: String, subText: String,
    private val filter: (Cust) -> Boolean, private val onPick: (Cust) -> Unit
) {
    val root = h.vbox()
    private val header = Header(h, title, subText, { h.pop() })
    private val search = SearchBox(h, "Search name, father, spouse, phone, L/C no")
    private val count = h.label("", 13f, C.primary, true)
    private val list = CustList(h, 0) { onPick(it) }
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private val listener: () -> Unit = { refresh() }
    private val doSearch = Runnable { refresh() }

    companion object {
        /** [filter] decides which customers are listed (the Connect / Add location lists only show customers without a location). */
        fun open(h: HomeActivity, title: String, subText: String, filter: (Cust) -> Boolean = { true }, onPick: (Cust) -> Unit) {
            val p = CustomerPicker(h, title, subText, filter, onPick)
            h.push(p.root) { p.close() }
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { refresh() }
        header.addChip(unionBar.root)
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(list.view, LinearLayout.LayoutParams(MATCH, 0, 1f))
        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        refresh()
    }

    private fun refresh() {
        unionBar.refresh()
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Cust>()
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) ||
                    c.sCase.contains(q) || (digits.isNotEmpty() && c.sPhone.contains(digits)))) continue
            if (!filter(c)) continue
            out.add(c)
        }
        if (q.isEmpty()) out.sortBy { it.sName }
        else out.sortWith(compareBy<Cust>({ if (it.sName.startsWith(q)) 0 else 1 }, { it.sName }))
        count.text = if (out.isEmpty()) "No customer without a location found" else "${out.size} customers without a location"
        list.submit(out)
    }

    private fun close() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}

/** Captures the phone's GPS position for a new customer (the pin is the GPS location and cannot be moved by hand). */
class PinPicker private constructor(
    private val h: HomeActivity, title: String, subText: String,
    initial: DoubleArray?,
    private val onPicked: (Double, Double, Double, String) -> Unit
) {
    val root = h.vbox()
    private val panel: GpsPinMap

    companion object {
        /** [initial] = {lat, lng} to open the map on, or null. [onPicked] = (lat, lng, accuracy, "gps"). */
        fun open(h: HomeActivity, title: String, subText: String, initial: DoubleArray?, onPicked: (Double, Double, Double, String) -> Unit) {
            val p = PinPicker(h, title, subText, initial, onPicked)
            h.push(p.root) { p.close() }
            p.panel.start()
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(Header(h, title, subText, { h.pop() }).root)
        val start = when {
            initial != null -> doubleArrayOf(initial[0], initial[1], 18.0)
            Repo.hasFix -> doubleArrayOf(Repo.lastLat, Repo.lastLng, 17.0)
            else -> doubleArrayOf(23.7, 90.4, 6.0)
        }
        panel = GpsPinMap(h, start[0], start[1], start[2], null)
        root.addView(panel.view, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val bottom = h.vbox()
        bottom.setBackgroundColor(Color.WHITE)
        bottom.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(14))
        bottom.elevation = h.dp(8).toFloat()
        bottom.addView(panel.status)
        val row = h.hbox()
        row.addView(h.btn("Refresh GPS", 1, R.drawable.ic_target) { panel.refreshGps() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(8) })
        row.addView(h.btn("Use this location", 0, R.drawable.ic_pin) { pick() }, LinearLayout.LayoutParams(0, WRAP, 1.4f))
        bottom.addView(row, h.lp(10))
        root.addView(bottom, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun pick() {
        val fix = panel.fix
        if (fix == null) {
            if (!panel.gpsOn()) panel.refreshGps() else h.toast("GPS location not found yet. Please wait for GPS.")
            return
        }
        val acc = fix.accuracy.toDouble()
        val done = {
            h.pop()
            onPicked(fix.latitude, fix.longitude, acc, "gps")
        }
        if (acc > 50.0) {
            AlertDialog.Builder(h).setMessage("GPS is weak (\u00B1${acc.toInt()} m). Use this location anyway?")
                .setPositiveButton("Yes") { _, _ -> done() }
                .setNegativeButton("Cancel", null).show()
        } else {
            done()
        }
    }

    private fun close() {
        panel.close()
    }
}

/** Home-visit form of a loan applicant: name, spouse/father, village, mobile + captured location. */
class NewCustomerEditor private constructor(private val h: HomeActivity) {
    val root = h.vbox()
    private val name: EditText = h.field("Customer name *", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
    private val rel: EditText = h.field("Spouse / Father name", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
    private val village: EditText = h.field("Village", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
    private val mobile: EditText = h.field("Mobile no", InputType.TYPE_CLASS_PHONE)
    private val locText: TextView = h.label("Location not captured yet", 14f, C.muted, true)
    private val locIcon: ImageView = h.icon(R.drawable.ic_pin, C.warn, 22)
    private var lat = 0.0
    private var lng = 0.0
    private var acc = 0.0
    private var source = ""
    private var captured = false

    companion object {
        fun open(h: HomeActivity) {
            val e = NewCustomerEditor(h)
            h.push(e.root)
        }
    }

    init {
        root.setBackgroundColor(C.bg)
        root.addView(Header(h, "New Customer", "Loan applicant home visit", { h.pop() }).root)

        val sv = ScrollView(h)
        val body = h.vbox()
        body.setPadding(h.dp(14), h.dp(14), h.dp(14), h.dp(20))

        val card = h.vbox()
        card.background = h.shape(Color.WHITE, 18, C.line)
        card.elevation = h.dp(1).toFloat()
        card.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(16))
        card.addView(h.label("APPLICANT", 11f, C.primary, true))
        card.addView(name, h.lp(8))
        card.addView(rel, h.lp(10))
        card.addView(village, h.lp(10))
        card.addView(mobile, h.lp(10))
        body.addView(card)

        val lc = h.hbox()
        lc.gravity = Gravity.CENTER_VERTICAL
        lc.background = h.shape(Color.WHITE, 18, C.line)
        lc.elevation = h.dp(1).toFloat()
        lc.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(14))
        lc.addView(locIcon, LinearLayout.LayoutParams(h.dp(26), h.dp(26)).apply { rightMargin = h.dp(12) })
        lc.addView(locText, LinearLayout.LayoutParams(0, WRAP, 1f))
        body.addView(lc, h.lp(12))
        body.addView(h.btn("Capture location", 1, R.drawable.ic_target) { capture() }, h.lp(10))
        body.addView(h.btn("Save new customer", 0, R.drawable.ic_person_add) { save() }, h.lp(10))
        body.addView(
            h.label("If this applicant gets the loan, open New Customer, tap Connect and choose the customer. The location is moved to that customer.", 12f, C.muted),
            h.lp(14)
        )
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun capture() {
        val ini = if (captured) doubleArrayOf(lat, lng) else null
        PinPicker.open(h, "Capture location", name.text.toString().trim(), ini) { la, lo, ac, src ->
            lat = la
            lng = lo
            acc = ac
            source = src
            captured = true
            locIcon.setColorFilter(C.ok)
            locText.setTextColor(C.ok)
            locText.text = "Location captured" + if (src == "gps" && ac > 0.0) "  (\u00B1${ac.toInt()} m)" else ""
        }
    }

    private fun save() {
        val n = name.text.toString().trim()
        if (n.isEmpty()) { h.toast("Enter the customer name"); return }
        if (!captured) { h.toast("Capture the location first"); return }
        val raw = mobile.text.toString().trim()
        var ph = ""
        if (raw.isNotEmpty()) {
            ph = normalizePhone(raw)
            if (ph.isEmpty()) { h.toast("Mobile number is not valid"); return }
        }
        Repo.saveNewCustomer(n, rel.text.toString().trim(), village.text.toString().trim(), ph, lat, lng, acc, source)
        h.toast("New customer saved")
        h.pop()
    }
}

/** New Customer module: the saved home-visit records that are not connected to a loan yet. */
class NewCustomerScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "New Customer", Repo.status, { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, village, mobile")
    private val count = h.label("", 13f, C.bad, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private var rows: List<Loc> = emptyList()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    init {
        Repo.ensureNewCustomers()
        root.setBackgroundColor(C.bg)
        header.action(h, R.drawable.ic_add) { NewCustomerEditor.open(h) }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))
        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(4), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))
        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    override fun onShow() {
        Repo.ensureNewCustomers()
    }

    private fun onData() {
        header.sub.text = Repo.status
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Loc>()
        val me = Repo.myId()
        for (l in Repo.newCustomers()) {
            if (l.ownerId != me) continue
            if (q.isNotEmpty() && !(l.name.lowercase().contains(q) || l.village.lowercase().contains(q) ||
                    l.father.lowercase().contains(q) || (digits.isNotEmpty() && normalizePhone(l.phone).contains(digits)))) continue
            out.add(l)
        }
        out.sortByDescending { it.updatedAt }
        count.text = if (out.isEmpty()) "No new customer added by you" else "${out.size} added by you, waiting for a loan"
        rows = out
        recycler.adapter?.notifyDataSetChanged()
    }

    private fun connect(l: Loc) {
        if (Repo.loans.isEmpty()) { h.toast("Customer data is not loaded yet"); return }
        CustomerPicker.open(h, "Connect", l.name + "  \u2192  select the loan customer", { Repo.locFor(it) == null }) { c -> confirmConnect(l, c) }
    }

    private fun personCard(tag: String, tagColor: Int, name: String, lines: List<String>, chips: List<String>): LinearLayout {
        val card = h.vbox()
        card.background = h.shape(Color.parseColor("#F8FAFC"), 16, C.line)
        card.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(12))
        card.addView(h.label(tag, 11f, tagColor, true))
        val row = h.hbox()
        row.gravity = Gravity.CENTER_VERTICAL
        val col = h.vbox()
        col.addView(h.label(name, 16f, C.text, true))
        val sub = lines.filter { it.isNotEmpty() }.joinToString("  \u2022  ")
        if (sub.isNotEmpty()) col.addView(h.label(sub, 13f, C.muted), h.lp(2))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        card.addView(row, h.lp(8))
        if (chips.isNotEmpty()) {
            val cr = h.hbox()
            for ((i, t) in chips.withIndex()) {
                val p = h.pill(t, tagColor)
                p.maxLines = 1
                cr.addView(p, LinearLayout.LayoutParams(WRAP, WRAP).apply { if (i > 0) leftMargin = h.dp(6) })
            }
            card.addView(cr, h.lp(10, WRAP, WRAP))
        }
        return card
    }

    private fun noteBox(text: String, color: Int, icon: Int): LinearLayout {
        val r = h.hbox()
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = h.shape((color and 0xFFFFFF) or 0x1A000000, 14)
        r.setPadding(h.dp(12), h.dp(10), h.dp(12), h.dp(10))
        r.addView(h.icon(icon, color, 18), LinearLayout.LayoutParams(h.dp(18), h.dp(18)).apply { rightMargin = h.dp(10) })
        r.addView(h.label(text, 13f, color, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        return r
    }

    private fun confirmConnect(l: Loc, c: Cust) {
        val old = Repo.locFor(c)
        val replace = old != null && old.id != l.id
        val box = h.vbox()
        box.background = h.shape(Color.WHITE, 24)
        box.setPadding(h.dp(18), h.dp(18), h.dp(18), h.dp(16))

        val tr = h.hbox()
        tr.gravity = Gravity.CENTER_VERTICAL
        val ti = h.icon(R.drawable.ic_link, C.primary, 22)
        ti.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
        ti.background = h.shape(C.soft, 24)
        tr.addView(ti, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { rightMargin = h.dp(12) })
        val tc = h.vbox()
        tc.addView(h.label("Connect location", 19f, C.text, true))
        tc.addView(h.label("Please review before connecting", 12f, C.muted), h.lp(1))
        tr.addView(tc)
        box.addView(tr)

        box.addView(personCard("NEW CUSTOMER", C.pink, l.name, listOf(listOf(l.village, l.phone).filter { it.isNotEmpty() }.joinToString("  \u2022  ")), emptyList()), h.lp(16))
        val ar = h.icon(R.drawable.ic_down, C.muted, 22)
        box.addView(ar, LinearLayout.LayoutParams(h.dp(22), h.dp(22)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = h.dp(4)
            bottomMargin = h.dp(4)
        })
        box.addView(
            personCard(
                "LOAN CUSTOMER", C.primary, c.name,
                listOf(listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString(" / ")),
                listOf(c.progLabel, "L/C " + c.caseNo)
            )
        )
        box.addView(noteBox("The visit location will be added to this customer.", C.ok, R.drawable.ic_pin), h.lp(14))
        if (replace) box.addView(noteBox("This customer already has a location. It will be replaced.", Color.parseColor("#D97706"), R.drawable.ic_info), h.lp(8))

        val dlg = AlertDialog.Builder(h).setView(box).create()
        val row = h.hbox()
        row.addView(h.btn("Cancel", 1) { dlg.dismiss() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(8) })
        row.addView(h.btn("Connect", 0, R.drawable.ic_link) {
            dlg.dismiss()
            Repo.connectNew(l, c)
            h.pop()
            h.toast("Connected to " + c.name)
        }, LinearLayout.LayoutParams(0, WRAP, 1.3f))
        box.addView(row, h.lp(16))
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dlg.show()
        dlg.window?.setLayout((h.resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun confirmDelete(l: Loc) {
        AlertDialog.Builder(h)
            .setTitle("Delete record?")
            .setMessage(l.name + (if (l.village.isNotEmpty()) "\n" + l.village else "") + "\n\nThis new customer and the saved location will be deleted.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> Repo.deleteNewCustomer(l.id) }
            .show()
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val connect = h.pill("Connect", C.primary, true)
        val delete = h.pill("Delete", C.bad)
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)
        val nav: ImageView = h.icon(R.drawable.ic_nav, C.primary, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            val top = h.hbox()
            top.gravity = Gravity.CENTER_VERTICAL
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(1))
            top.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            top.addView(call, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { leftMargin = h.dp(6) })
            nav.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            nav.background = h.ripple(h.shape(C.soft, 24), 24)
            top.addView(nav, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { leftMargin = h.dp(6) })
            root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
            val acts = h.hbox()
            acts.addView(connect)
            acts.addView(delete, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(8) })
            root.addView(acts, h.lp(10, WRAP, WRAP))
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.vbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(12), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            fun at(): Loc? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            r.setOnClickListener { at()?.let { Details.open(h, null, it) } }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.phone) } }
            vh.nav.setOnClickListener { at()?.let { Act.navigate(h, it.lat, it.lng, it.name) } }
            vh.connect.setOnClickListener { at()?.let { connect(it) } }
            vh.delete.setOnClickListener { at()?.let { confirmDelete(it) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val l = rows[i]
            v.name.text = l.name
            val a = ArrayList<String>()
            if (l.father.isNotEmpty()) a.add("Spouse/Father: " + l.father)
            v.l2.text = a.joinToString("")
            v.l2.gone(a.isEmpty())
            val b = listOf(l.village, l.phone).filter { it.isNotEmpty() }.toMutableList()
            b.add("by " + l.updatedBy + ", " + fmtDate(l.updatedAt))
            v.l3.text = b.joinToString("  \u2022  ")
            v.call.gone(l.phone.isBlank())
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
