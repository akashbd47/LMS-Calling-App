package com.lms.caller

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Developer password check (only the SHA-256 hash is kept in the app). */
object Auth {
    private const val HASH = "4e3d55693a2be6c6ad7a034cb9b56f67b908959edeb8c42348814389e5108fe3"
    fun check(input: String): Boolean {
        val d = MessageDigest.getInstance("SHA-256").digest(input.trim().toByteArray())
        return d.joinToString("") { "%02x".format(it) } == HASH
    }
}

data class Cfg(val apiKey: String, val appId: String, val projectId: String, val projectNumber: String)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("lms_caller", Context.MODE_PRIVATE)

    fun config(c: Context): Cfg? {
        val s = sp(c)
        val k = s.getString("apiKey", null) ?: return null
        val a = s.getString("appId", null) ?: return null
        val p = s.getString("projectId", null) ?: return null
        val n = s.getString("projectNumber", "") ?: ""
        return Cfg(k, a, p, n)
    }

    fun saveConfig(c: Context, g: Cfg) {
        sp(c).edit().putString("apiKey", g.apiKey).putString("appId", g.appId)
            .putString("projectId", g.projectId).putString("projectNumber", g.projectNumber).apply()
    }

    fun userId(c: Context): String = sp(c).getString("userId", "") ?: ""
    fun userName(c: Context): String = sp(c).getString("userName", "") ?: ""
    fun saveUser(c: Context, id: String, name: String) {
        sp(c).edit().putString("userId", id).putString("userName", name).putBoolean("enabled", true).apply()
    }
    fun clearUser(c: Context) {
        sp(c).edit().remove("userId").remove("userName").putBoolean("enabled", false).apply()
    }
    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun info(c: Context): String = sp(c).getString("info", "") ?: ""
    fun setInfo(c: Context, t: String) { sp(c).edit().putString("info", t).apply() }
}

/** Connects to whichever Firebase project the uploaded google-services.json describes. */
object Fb {
    private const val NAME = "branch"

    @Synchronized
    fun db(c: Context): FirebaseFirestore? {
        val g = Prefs.config(c) ?: return null
        val app = try {
            FirebaseApp.getInstance(NAME)
        } catch (e: IllegalStateException) {
            val o = FirebaseOptions.Builder()
                .setApiKey(g.apiKey)
                .setApplicationId(g.appId)
                .setProjectId(g.projectId)
                .setGcmSenderId(g.projectNumber)
                .build()
            FirebaseApp.initializeApp(c.applicationContext, o, NAME)
        }
        return FirebaseFirestore.getInstance(app)
    }

    @Synchronized
    fun reset() {
        try { FirebaseApp.getInstance(NAME).delete() } catch (e: IllegalStateException) { }
    }

    fun parse(json: String, pkg: String): Cfg {
        val o = JSONObject(json)
        val info = o.getJSONObject("project_info")
        val clients = o.getJSONArray("client")
        var found: JSONObject? = null
        for (i in 0 until clients.length()) {
            val c = clients.getJSONObject(i)
            val p = c.getJSONObject("client_info").optJSONObject("android_client_info")?.optString("package_name")
            if (p == pkg) found = c
        }
        val pick: JSONObject = found ?: clients.getJSONObject(0)
        val key: String = pick.getJSONArray("api_key").getJSONObject(0).getString("current_key")
        val appId: String = pick.getJSONObject("client_info").getString("mobilesdk_app_id")
        return Cfg(
            apiKey = key,
            appId = appId,
            projectId = info.getString("project_id"),
            projectNumber = info.optString("project_number", "")
        )
    }
}

/** Encrypted "setup code": lets the developer move a branch's server settings to another phone without sharing the json file. */
object Setup {
    private fun key(pw: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val k = f.generateSecret(PBEKeySpec(pw.toCharArray(), salt, 60000, 256)).encoded
        return SecretKeySpec(k, "AES")
    }

    fun toJson(g: Cfg): String = JSONObject()
        .put("k", g.apiKey).put("a", g.appId).put("p", g.projectId).put("n", g.projectNumber).toString()

    fun encrypt(plain: String, pw: String): String {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pw, salt), GCMParameterSpec(128, iv))
        val ct = c.doFinal(plain.toByteArray())
        return Base64.encodeToString(salt + iv + ct, Base64.NO_WRAP or Base64.URL_SAFE)
    }

    fun fromCode(code: String, pw: String): Cfg {
        val b = Base64.decode(code, Base64.URL_SAFE)
        val salt = b.copyOfRange(0, 16)
        val iv = b.copyOfRange(16, 28)
        val ct = b.copyOfRange(28, b.size)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(pw, salt), GCMParameterSpec(128, iv))
        val o = JSONObject(String(c.doFinal(ct)))
        return Cfg(o.getString("k"), o.getString("a"), o.getString("p"), o.optString("n", ""))
    }
}
