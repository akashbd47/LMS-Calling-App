package com.lms.caller

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Transaction
import java.security.MessageDigest
import java.util.Calendar

/**
 * "Paid" button logic = the web app's Loan Entry (Old Customer) logic:
 *  paid date -> Disburse Type detection -> LoanEntries/OLD_<sha256(prog::case)> (status "Date Pending")
 *  -> the paid loan is removed from LoanMonthlyData (borrower list).
 */
object Paid {
    private const val T_REV = "Revolving"
    private const val T_OLD = "New but Old"
    private val busy = HashSet<String>()

    // programmes where Revolving is active (RevolvingProgrammes collection) - cached for 10 minutes
    private var revIds: Set<String>? = null
    private var revAt = 0L

    private fun sha256(t: String): String =
        MessageDigest.getInstance("SHA-256").digest(t.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    /** Small "Paid" pill shown left of a customer name. */
    fun button(h: HomeActivity): TextView {
        val b = h.pill("Paid", C.ok, true)
        b.textSize = 11f
        b.setPadding(h.dp(9), h.dp(3), h.dp(9), h.dp(3))
        b.maxLines = 1
        b.setSingleLine()
        b.isClickable = true
        return b
    }

    fun visible(): Boolean = Repo.dsbCan("loan-entry", "create")

    /** Paid button clicked: calendar for the paid date, then submit. */
    fun start(h: HomeActivity, c: Cust) {
        if (!visible()) { h.toast("You do not have permission for Loan Entry"); return }
        if (busy.contains(c.id)) return
        val cal = Calendar.getInstance()
        val dlg = DatePickerDialog(h, { _, y, m, d -> submit(h, c, y, m + 1, d) },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
        dlg.setTitle("Paid date - " + c.name)
        dlg.setButton(DialogInterface.BUTTON_POSITIVE, "Submit", dlg)
        dlg.show()
    }

    private fun validMobile(p: String): String {
        val n = normalizePhone(p)
        return if (Regex("^01[3-9]\\d{8}$").matches(n)) n else ""
    }

    private fun revolvingIds(h: HomeActivity, done: (Set<String>?) -> Unit) {
        val cached = revIds
        if (cached != null && System.currentTimeMillis() - revAt < 10 * 60_000L) { done(cached); return }
        val db = Fb.db(h) ?: run { done(null); return }
        db.collection("RevolvingProgrammes").get()
            .addOnSuccessListener { snap ->
                val ids = HashSet<String>()
                for (d in snap.documents) {
                    val st = (d.getString("status") ?: "").trim().lowercase()
                    val on = d.getBoolean("enabled") == true || st == "enabled" || st == "active"
                    if (!on) continue
                    val id = d.get("programmeId") ?: d.get("programmeCode") ?: d.get("loanProgrammeId") ?: d.id
                    ids.add(id.toString())
                }
                revIds = ids
                revAt = System.currentTimeMillis()
                done(ids)
            }
            .addOnFailureListener { done(null) }
    }

    private fun submit(h: HomeActivity, c: Cust, y: Int, m: Int, d: Int) {
        if (c.name.isBlank()) { h.toast("Customer name is missing"); return }
        if (c.union.isBlank()) { h.toast("Union is missing for this loan"); return }
        val db = Fb.db(h) ?: run { h.toast("No server connection"); return }
        busy.add(c.id)
        h.toast("Checking loan...")
        val cal = Calendar.getInstance()
        cal.clear()
        cal.set(y, m - 1, d, 0, 0, 0)
        val paidMs = cal.timeInMillis
        val paidIso = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m, d)

        revolvingIds(h) { ids ->
            if (ids == null) {
                busy.remove(c.id)
                h.toast("Could not check Revolving programmes. Check internet and try again.")
                return@revolvingIds
            }
            val why = ArrayList<String>()
            if (!ids.contains(c.prog)) why.add("Revolving is not active for this programme")
            if (c.caseNo.contains(".")) why.add("Already Revolving Disbursed")
            if (c.rsNo >= 1) why.add("Reschedule Loan")
            if (c.overdue > 0L && paidMs >= c.overdue) why.add("Overdue Loan (Paid Date >= Overdue Date)")
            if (why.isNotEmpty()) {
                save(h, c, paidIso, why)
            } else {
                // nothing decided yet: read the ONE LoanInfo document of this loan
                db.collection("LoanInfo").document(c.prog + c.caseNo).get()
                    .addOnSuccessListener { s ->
                        val raw = if (s.exists()) s.get("loanDurationMonths") else null
                        val months = when (raw) {
                            is Number -> raw.toDouble()
                            is String -> raw.trim().toDoubleOrNull() ?: Double.NaN
                            else -> Double.NaN
                        }
                        if (months.isNaN()) why.add("Duration not found in Loan Info")
                        else if (months > 12) why.add("Duration " + months.toInt() + " months (more than 12)")
                        save(h, c, paidIso, why)
                    }
                    .addOnFailureListener {
                        why.add("Loan Info could not be read")
                        save(h, c, paidIso, why)
                    }
            }
        }
    }

    private fun save(h: HomeActivity, c: Cust, paidIso: String, why: List<String>) {
        val db = Fb.db(h)
        if (db == null) { busy.remove(c.id); h.toast("No server connection"); return }
        val type = if (why.isEmpty()) T_REV else T_OLD
        val progName = c.progName.ifBlank { c.prog }
        val owner = Repo.myId()
        val ownerName = Repo.me?.name?.ifBlank { Repo.userName() } ?: Repo.userName()
        val id = "OLD_" + sha256(c.prog.trim() + "::" + c.caseNo.trim())
        val e = hashMapOf<String, Any>(
            "paidDate" to paidIso,
            "unionId" to c.union, "unionName" to c.union,
            "oldProgrammeId" to c.prog, "oldProgrammeName" to progName,
            "oldLC" to c.caseNo,
            "customerName" to c.name,
            "customerMobile" to validMobile(c.phone),
            "loanType" to type,
            "loanTypeReasons" to why,
            "status" to "Date Pending",
            "investigatorId" to owner, "investigatorName" to ownerName,
            "createdBy" to owner, "createdByName" to ownerName,
            "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp(),
            "entryId" to id
        )
        if (type == T_REV) { e["newProgrammeId"] = c.prog; e["newProgrammeName"] = progName }
        val ref = db.collection("LoanEntries").document(id)
        db.runTransaction(Transaction.Function<String> { tr ->
            val snap: DocumentSnapshot = tr.get(ref)
            if (snap.exists()) {
                "dup:" + (snap.getString("customerName") ?: "-") + " \u2022 " + (snap.getString("status") ?: "Pending")
            } else {
                tr.set(ref, e)
                "ok"
            }
        }).addOnSuccessListener { res ->
            if (res != "ok") {
                busy.remove(c.id)
                h.toast("Already saved (" + res.removePrefix("dup:") + ")")
                return@addOnSuccessListener
            }
            // the paid loan leaves the borrower list (LoanMonthlyData), exactly like the web Loan Entry
            db.collection("LoanMonthlyData").document(c.id).delete()
                .addOnSuccessListener {
                    busy.remove(c.id)
                    Repo.dropLoan(c.id)
                    h.toast(c.name + " saved to Pending Loan (" + type + ")")
                }
                .addOnFailureListener { ex ->
                    busy.remove(c.id)
                    h.toast("Entry saved, but could not remove from borrower list: " + ex.message)
                }
        }.addOnFailureListener { ex ->
            busy.remove(c.id)
            h.toast("Could not save: " + ex.message)
        }
    }
}

/** Adds the Paid pill in front of a customer name row (name column of a list row). */
fun HomeActivity.nameRowWithPaid(name: TextView, paid: TextView): LinearLayout {
    val r = hbox()
    r.gravity = Gravity.CENTER_VERTICAL
    r.addView(paid, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
    r.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
    return r
}

/**
 * Pending Loan = web "Date Pending" page without Set Date: loans entered as Paid, split into "New but Old" and "Revolving",
 * oldest paid date on top. Only the owner of the list (the investigator whose unions contain the loan's union) can delete.
 */
class PendingScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "Pending Loan", "", { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, L/C no, phone")
    private val info = h.label("", 13f, C.orange, true)
    private val tabOld = h.label("", 13f, C.primary, true)
    private val tabRev = h.label("", 13f, C.primary, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private val hiding = HashSet<String>()
    private var which = "New but Old"
    private var rows: List<PendingItem> = emptyList()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    companion object {
        /** true = Admin may also delete entries of other investigators' unions. */
        const val ADMIN_CAN_DELETE_ALL = false
    }

    init {
        Repo.ensurePending()
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { refreshList() }
        header.addChip(unionBar.root)
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        val seg = h.hbox()
        seg.background = h.shape(Color.WHITE, 14, C.line)
        seg.setPadding(h.dp(4), h.dp(4), h.dp(4), h.dp(4))
        for ((tv, key) in listOf(Pair(tabOld, "New but Old"), Pair(tabRev, "Revolving"))) {
            tv.gravity = Gravity.CENTER
            tv.setPadding(0, h.dp(9), 0, h.dp(9))
            tv.isClickable = true
            tv.setOnClickListener { which = key; refreshList() }
            seg.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(seg, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(h.dp(12), h.dp(12), h.dp(12), 0) })
        root.addView(h.infoRow(info, null), LinearLayout.LayoutParams(MATCH, WRAP))

        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(4), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    override fun onShow() {
        Repo.ensurePending()
        onData()
    }

    private fun paintTab(tv: TextView, on: Boolean) {
        tv.setTextColor(if (on) Color.WHITE else C.primary)
        tv.background = if (on) h.gradient(C.primary, C.dark, 10) else null
    }

    private fun onData() {
        hiding.retainAll(Repo.pending.keys)
        unionBar.refresh()
        refreshList()
    }

    private fun canDelete(p: PendingItem): Boolean {
        val m = Repo.me ?: return false
        if (!Repo.dsbCan("date-pending", "edit")) return false
        if (ADMIN_CAN_DELETE_ALL && m.role == "Admin") return true
        return m.unions.contains(p.union)
    }

    private fun refreshList() {
        if (!Repo.dsbCan("date-pending", "view")) {
            header.sub.text = "No permission to view this list"
            rows = emptyList()
            recycler.adapter?.notifyDataSetChanged()
            return
        }
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val base = ArrayList<PendingItem>()
        for (p in Repo.pending.values) {
            if (hiding.contains(p.id)) continue
            if (p.loanType != "New but Old" && p.loanType != "Revolving") continue   // Pure New has no paid loan
            if (!Repo.unionOk(p.union)) continue
            if (q.isNotEmpty() && !(p.sName.contains(q) || p.sCase.contains(q) || (digits.isNotEmpty() && p.sPhone.contains(digits)))) continue
            base.add(p)
        }
        val nOld = base.count { it.loanType == "New but Old" }
        val nRev = base.count { it.loanType == "Revolving" }
        tabOld.text = "New but Old ($nOld)"
        tabRev.text = "Revolving ($nRev)"
        paintTab(tabOld, which == "New but Old")
        paintTab(tabRev, which == "Revolving")
        val out = base.filter { it.loanType == which }.sortedWith(compareBy<PendingItem>({ it.paid.ifEmpty { "9999" } }, { it.sName }))
        rows = out
        header.sub.text = if (Repo.pendingLoaded) "${nOld + nRev} pending loans" else "Loading..."
        info.text = "${out.size} $which"
        recycler.adapter?.notifyDataSetChanged()
    }

    private fun confirmDelete(p: PendingItem) {
        AlertDialog.Builder(h)
            .setTitle("Delete this entry?")
            .setMessage(p.name + "\nL/C " + p.caseNo + "  \u2022  " + p.progName + "\n\nThe entry will be deleted permanently (the loan will not be disbursed).")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> delete(p) }
            .show()
    }

    private fun delete(p: PendingItem) {
        val db = Fb.db(h) ?: return
        hiding.add(p.id)
        refreshList()
        val ref = db.collection("LoanEntries").document(p.id)
        db.runTransaction(Transaction.Function<String> { tr ->
            val snap = tr.get(ref)
            when {
                !snap.exists() -> "gone"
                (snap.getString("status") ?: "").trim().lowercase() != "date pending" -> "processed"
                else -> { tr.delete(ref); "ok" }
            }
        }).addOnSuccessListener { res ->
            when (res) {
                "ok" -> h.toast(p.name + " deleted")
                "processed" -> { hiding.remove(p.id); refreshList(); h.toast("This entry was already processed") }
                else -> h.toast("Entry not found")
            }
        }.addOnFailureListener { ex ->
            hiding.remove(p.id)
            refreshList()
            h.toast("Could not delete: " + ex.message)
        }
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val stripe = View(h)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val paid = h.pill("", C.orange)
        val del = h.pill("Delete", C.bad)
        val pills = h.hbox()
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l2.maxLines = 1
            l2.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            paid.maxLines = 1
            paid.setSingleLine()
            del.maxLines = 1
            del.setSingleLine()
            root.gravity = Gravity.CENTER_VERTICAL
            root.addView(stripe, LinearLayout.LayoutParams(h.dp(4), MATCH).apply { rightMargin = h.dp(10); topMargin = h.dp(1); bottomMargin = h.dp(1) })
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(1))
            pills.addView(paid)
            pills.addView(del, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(8) })
            col.addView(pills, h.lp(8, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            root.addView(call, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(10), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            val vh = VH(r)
            fun at(): PendingItem? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.mobile) } }
            vh.del.setOnClickListener { at()?.let { if (canDelete(it)) confirmDelete(it) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val p = rows[i]
            v.name.text = p.name
            v.l2.text = listOf(p.union, p.progName).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            v.l2.gone(v.l2.text.isEmpty())
            v.l3.text = "L/C ${p.caseNo}" + (if (p.byName.isNotEmpty()) "  \u2022  by ${p.byName}" else "")
            v.paid.text = "Paid  " + (if (p.paid.isEmpty()) "-" else fmtPromise(p.paid))
            v.del.gone(!canDelete(p))
            v.call.gone(p.sPhone.isEmpty())
            v.stripe.background = h.shape(if (p.loanType == "Revolving") C.ok else C.orange, 3)
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
