package com.lms.caller

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Monitoring List: loans whose last note has a promise date (Today / Expired / Upcoming)
 * plus two "month-OD" lists (overdue date in this month / next month) and a "Current Due" list
 * (same rule as the web app Due List: overdue date is today or earlier OR due amount > 0).
 */
class MonitoringScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private class Row(val c: Cust, val p: PromiseItem?)

    private val header = Header(h, "Monitoring", "", { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, L/C no, phone")
    private val info = h.label("", 13f, C.text, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private val tabs = ArrayList<LinearLayout>()
    private val tabCounts = ArrayList<TextView>()
    private val tabLabels = ArrayList<TextView>()
    private val odBtns = ArrayList<LinearLayout>()
    private val odIcons = ArrayList<ImageView>()
    private val odLabels = ArrayList<TextView>()
    private val odCounts = ArrayList<TextView>()
    private val odNames = arrayOf("", "", "Current Due")
    private var tab = 0
    private var rows: List<Row> = emptyList()
    private var today = todayStart()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    // tab 0..2 = promise lists, tab 3 = this month OD, tab 4 = next month OD, tab 5 = Current Due
    private val c1 = intArrayOf(
        Color.parseColor("#F59E0B"), Color.parseColor("#EF4444"), Color.parseColor("#3B82F6"),
        Color.parseColor("#F97316"), Color.parseColor("#14B8A6"), Color.parseColor("#8B5CF6")
    )
    private val c2 = intArrayOf(
        Color.parseColor("#D97706"), Color.parseColor("#B91C1C"), Color.parseColor("#1D4ED8"),
        Color.parseColor("#C2410C"), Color.parseColor("#0F766E"), Color.parseColor("#6D28D9")
    )
    private val names = arrayOf("Today", "Expired", "Upcoming")

    init {
        Repo.ensureNotes()
        root.setBackgroundColor(C.bg)
        header.sub.gone(true)
        unionBar = UnionBar(h, true) { onData() }
        header.addChip(unionBar.root)
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        // promise tabs (compact)
        val tr = h.hbox()
        tr.setPadding(h.dp(12), h.dp(10), h.dp(12), 0)
        for (i in 0..2) {
            val t = h.hbox()
            t.gravity = Gravity.CENTER
            t.setPadding(h.dp(6), h.dp(8), h.dp(6), h.dp(8))
            val n = h.label("0", 18f, c2[i], true)
            val l = h.label(names[i], 12f, c2[i], true)
            t.addView(n)
            t.addView(l, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(6) })
            t.isClickable = true
            t.setOnClickListener { tab = i; onData() }
            tabs.add(t)
            tabCounts.add(n)
            tabLabels.add(l)
            tr.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                if (i == 0) rightMargin = h.dp(4) else if (i == 2) leftMargin = h.dp(4) else setMargins(h.dp(4), 0, h.dp(4), 0)
            })
        }
        root.addView(tr, LinearLayout.LayoutParams(MATCH, WRAP))

        // this month OD / next month OD / current due buttons on one line
        val orow = h.hbox()
        orow.setPadding(h.dp(12), h.dp(8), h.dp(12), 0)
        for (k in 0..2) {
            val b = h.hbox()
            b.gravity = Gravity.CENTER_VERTICAL
            b.setPadding(h.dp(8), h.dp(9), h.dp(8), h.dp(9))
            val ic = h.icon(R.drawable.ic_calendar, c2[3 + k], 14)
            val lb = h.label("", 12f, c2[3 + k], true)
            lb.maxLines = 1
            lb.ellipsize = TextUtils.TruncateAt.END
            val ct = h.label("0", 12f, c2[3 + k], true)
            b.addView(ic, LinearLayout.LayoutParams(h.dp(14), h.dp(14)).apply { rightMargin = h.dp(4) })
            b.addView(lb, LinearLayout.LayoutParams(0, WRAP, 1f))
            b.addView(ct, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(4) })
            b.isClickable = true
            b.setOnClickListener { tab = 3 + k; onData() }
            odBtns.add(b)
            odIcons.add(ic)
            odLabels.add(lb)
            odCounts.add(ct)
            orow.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                if (k == 0) rightMargin = h.dp(3) else if (k == 2) leftMargin = h.dp(3) else setMargins(h.dp(3), 0, h.dp(3), 0)
            })
        }
        root.addView(orow, LinearLayout.LayoutParams(MATCH, WRAP))

        val ir = h.hbox()
        ir.setPadding(h.dp(16), h.dp(8), h.dp(12), 0)
        ir.addView(info)
        root.addView(ir, LinearLayout.LayoutParams(MATCH, WRAP))

        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(2), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    /** Every time the module is opened it starts on today's promises. */
    override fun onShow() {
        Repo.ensureNotes()
        tab = 0
        onData()
    }

    private fun paintTabs() {
        for (i in 0..2) {
            val on = i == tab
            tabs[i].background = if (on) h.gradient(c1[i], c2[i], 14) else h.shape(Color.WHITE, 14, C.line)
            tabs[i].elevation = h.dp(if (on) 3 else 1).toFloat()
            tabCounts[i].setTextColor(if (on) Color.WHITE else c2[i])
            tabLabels[i].setTextColor(if (on) Color.WHITE else C.muted)
        }
        for (k in 0..2) {
            val on = tab == 3 + k
            odBtns[k].background = if (on) h.gradient(c1[3 + k], c2[3 + k], 14) else h.shape(Color.WHITE, 14, C.line)
            odBtns[k].elevation = h.dp(if (on) 3 else 1).toFloat()
            odIcons[k].setColorFilter(if (on) Color.WHITE else c2[3 + k])
            odLabels[k].setTextColor(if (on) Color.WHITE else c2[3 + k])
            odCounts[k].setTextColor(if (on) Color.WHITE else c2[3 + k])
        }
    }

    private fun onData() {
        unionBar.refresh()
        today = todayStart()
        paintTabs()
        refreshList()
    }

    private fun refreshList() {
        val all = ArrayList<Row>()
        var nToday = 0
        var nExp = 0
        var nUp = 0
        val nOd = intArrayOf(0, 0, 0)
        var amtDue = 0.0
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        // month ranges: [first day, first day of next month)
        val cal = Calendar.getInstance()
        cal.timeInMillis = today
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val ms0 = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val ms1 = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val ms2 = cal.timeInMillis
        val fmt = SimpleDateFormat("MMM", Locale.ENGLISH)
        odNames[0] = fmt.format(Date(ms0)) + "-OD"
        odNames[1] = fmt.format(Date(ms1)) + "-OD"
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            val p = Repo.promises[c.id]
            var kind = -1
            if (p != null) kind = if (p.promiseMs == today) 0 else if (p.promiseMs < today) 1 else 2
            when (kind) { 0 -> nToday++; 1 -> nExp++; 2 -> nUp++ }
            var od = -1
            if (c.overdue > 0L) {
                if (c.overdue >= ms0 && c.overdue < ms1) od = 0 else if (c.overdue >= ms1 && c.overdue < ms2) od = 1
            }
            if (od >= 0) nOd[od]++
            // Current Due = web app "Due List": overdue date today or earlier, OR due amount > 0
            val isOver = c.overdue > 0L && c.overdue <= today
            val isDue = isOver || c.due > 0.0
            if (isDue) nOd[2]++
            val show = when {
                tab == 5 -> isDue
                tab >= 3 -> od == tab - 3
                else -> kind == tab
            }
            if (!show) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) ||
                    c.sCase.contains(q) || (digits.isNotEmpty() && c.sPhone.contains(digits)))) continue
            all.add(Row(c, p))
            // amount rule of the web Due List: overdue loan -> balance, due-but-not-overdue -> due amount
            if (tab == 5) amtDue += if (isOver) c.balance else c.due
        }
        when (tab) {
            0 -> all.sortBy { it.c.sName }
            1 -> all.sortWith(compareByDescending<Row> { it.p?.promiseMs ?: 0L }.thenBy { it.c.sName })
            2 -> all.sortWith(compareBy<Row> { it.p?.promiseMs ?: 0L }.thenBy { it.c.sName })
            5 -> all.sortWith(compareBy<Row> { if (it.c.overdue > 0L) it.c.overdue else Long.MAX_VALUE }.thenBy { it.c.sName })
            else -> all.sortWith(compareBy<Row> { it.c.overdue }.thenBy { it.c.sName })
        }
        tabCounts[0].text = nToday.toString()
        tabCounts[1].text = nExp.toString()
        tabCounts[2].text = nUp.toString()
        for (k in 0..2) {
            odLabels[k].text = odNames[k]
            odCounts[k].text = nOd[k].toString()
        }
        var bal = 0.0
        for (r in all) bal += r.c.balance
        val what = if (tab >= 3) odNames[tab - 3] else names[tab].lowercase() + " promise dates"
        val amountText = if (tab == 5) "Due amount ${money(amtDue)}" else "Balance ${money(bal)}"
        info.text = when {
            tab < 3 && !Repo.notesLoaded -> "Loading promise dates..."
            all.isEmpty() -> "No $what"
            else -> "${all.size} loans  \u2022  $amountText"
        }
        info.setTextColor(c2[tab])
        rows = all
        recycler.adapter?.notifyDataSetChanged()
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val stripe = View(h)
        val avatar = h.avatar(44)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val bal = h.label("", 12f, C.muted)
        val note = h.label("", 13f, C.text)
        val meta = h.label("", 11f, C.muted)
        val date = h.hbox()
        val dateText = h.label("", 12f, C.primary, true)
        val rel = h.pill("", C.muted)
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)
        val paidBtn: TextView = Paid.button(h)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            note.maxLines = 2
            note.ellipsize = TextUtils.TruncateAt.END
            meta.maxLines = 1
            meta.ellipsize = TextUtils.TruncateAt.END
            rel.maxLines = 1
            rel.setSingleLine()
            root.gravity = Gravity.CENTER_VERTICAL
            root.addView(stripe, LinearLayout.LayoutParams(h.dp(4), MATCH).apply { rightMargin = h.dp(10); topMargin = h.dp(1); bottomMargin = h.dp(1) })
            root.addView(avatar, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { rightMargin = h.dp(12) })
            val col = h.vbox()
            col.addView(h.nameRowWithPaid(name, paidBtn))
            col.addView(l2, h.lp(2))
            col.addView(bal, h.lp(2))
            col.addView(note, h.lp(6))
            col.addView(meta, h.lp(3))
            date.gravity = Gravity.CENTER_VERTICAL
            date.setPadding(h.dp(10), h.dp(5), h.dp(12), h.dp(5))
            date.addView(h.icon(R.drawable.ic_calendar, C.primary, 14), LinearLayout.LayoutParams(h.dp(14), h.dp(14)).apply { rightMargin = h.dp(5) })
            date.addView(dateText)
            val pr = h.hbox()
            pr.gravity = Gravity.CENTER_VERTICAL
            pr.addView(date)
            pr.addView(rel, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(6) })
            col.addView(pr, h.lp(8, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            root.addView(call, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(10), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            fun at(): Row? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            r.setOnClickListener { at()?.let { Details.open(h, it.c, null) } }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.c.phone) } }
            vh.paidBtn.setOnClickListener { at()?.let { Paid.start(h, it.c) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val row = rows[i]
            val c = row.c
            val p = row.p
            val col = c2[tab]
            h.paintAvatar(v.avatar, c.name)
            v.stripe.background = h.shape(col, 3)
            v.name.text = c.name
            v.paidBtn.gone(!Paid.visible())
            v.l2.text = listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            v.l2.gone(v.l2.text.isEmpty())
            val bl = StringBuilder("Balance ").append(money(c.balance))
            if (c.due > 0.0) bl.append("  \u2022  Due ").append(money(c.due))
            v.bal.text = bl.toString()
            val txt = p?.text.orEmpty()
            v.note.text = txt
            v.note.gone(txt.isEmpty())
            val m = if (p == null) "" else listOf(p.by, fmtDateTime(p.at)).filter { it.isNotEmpty() && it != "-" }.joinToString("  \u2022  ")
            v.meta.text = m
            v.meta.gone(m.isEmpty())
            v.date.background = h.shape((col and 0xFFFFFF) or 0x24000000, 20)
            v.dateText.setTextColor(col)
            val hasDate = tab < 3 || c.overdue > 0L
            v.date.gone(!hasDate)
            v.rel.gone(!hasDate)
            val dayMs = if (tab >= 3) c.overdue else (p?.promiseMs ?: today)
            v.dateText.text = if (tab >= 3) fmtDmy(c.overdue) else fmtPromise(p?.promise.orEmpty())
            val d = Math.round((dayMs - today) / 86400000.0).toInt()
            val rt = when {
                d == 0 -> "Today"
                d < 0 -> "${-d} day" + (if (-d == 1) "" else "s") + " late"
                else -> "in $d day" + (if (d == 1) "" else "s")
            }
            v.rel.text = rt
            v.rel.setTextColor(C.muted)
            v.rel.background = h.shape(Color.parseColor("#F1F5F9"), 20)
            v.call.gone(c.phone.isBlank())
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}

/** Overdue List: every overdue loan except those in the CL list; pick a month to see that month's overdue loans. */
class OverdueScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "Overdue List", "CL loans are not included", { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, L/C no, phone")
    private val count = h.label("", 13f, C.bad, true)
    private val list = CustList(h, 2, true) { Details.open(h, it, null) }
    private val chips = h.hbox()
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private var base: List<Cust> = emptyList()
    private var sel = 0          // yyyymm of the selected month, 0 = all months
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    private fun key(ms: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        return c.get(Calendar.YEAR) * 100 + c.get(Calendar.MONTH) + 1
    }

    private fun label(k: Int): String =
        java.text.DateFormatSymbols(Locale.ENGLISH).shortMonths[k % 100 - 1] + " " + (k / 100)

    init {
        Repo.ensureLists()
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { onData() }
        header.addChip(unionBar.root)
        header.action(h, R.drawable.ic_sync) {
            Repo.refreshLoans(true)
            h.toast("Refreshing...")
        }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        val sv = android.widget.HorizontalScrollView(h)
        sv.isHorizontalScrollBarEnabled = false
        chips.setPadding(h.dp(12), h.dp(10), h.dp(12), 0)
        sv.addView(chips)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(list.view, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    override fun onShow() {
        Repo.ensureLists()
    }

    private fun chip(text: String, on: Boolean, onClick: () -> Unit): TextView {
        val v = h.label(text, 13f, if (on) Color.WHITE else C.bad, true)
        v.setPadding(h.dp(14), h.dp(7), h.dp(14), h.dp(7))
        v.background = if (on) h.gradient(Color.parseColor("#EF4444"), Color.parseColor("#B91C1C"), 20) else h.shape(Color.WHITE, 20, C.line)
        v.elevation = h.dp(if (on) 3 else 1).toFloat()
        v.isClickable = true
        v.setOnClickListener { onClick() }
        v.layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = h.dp(6) }
        return v
    }

    /** Re-reads the loans (overdue, not CL, union filter) and rebuilds the month chips. */
    private fun onData() {
        header.sub.text = "CL loans are not included"
        unionBar.refresh()
        val t = todayStart()
        val months = java.util.TreeMap<Int, Int>(java.util.Collections.reverseOrder())
        val out = ArrayList<Cust>()
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            if (c.overdue <= 0L || c.overdue > t) continue
            if (Repo.cl.containsKey(c.id)) continue
            out.add(c)
            val k = key(c.overdue)
            months[k] = (months[k] ?: 0) + 1
        }
        base = out
        if (sel != 0 && !months.containsKey(sel)) sel = 0
        chips.removeAllViews()
        chips.addView(chip("All (" + out.size + ")", sel == 0) { sel = 0; onData() })
        for ((k, n) in months) {
            chips.addView(chip(label(k) + " (" + n + ")", sel == k) { sel = k; onData() })
        }
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Cust>()
        var bal = 0.0
        for (c in base) {
            if (sel != 0 && key(c.overdue) != sel) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) ||
                    c.sCase.contains(q) || (digits.isNotEmpty() && c.sPhone.contains(digits)))) continue
            out.add(c)
            bal += c.balance
        }
        out.sortWith(compareBy<Cust>({ it.overdue }, { it.sName }))
        count.text = "${out.size} overdue loans  \u2022  Balance ${money(bal)}"
        list.submit(out)
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
