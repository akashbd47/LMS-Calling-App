package com.lms.caller

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Monitoring List: loans whose last note has a promise date. Today (default) / Expired / Upcoming. */
class MonitoringScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private class Row(val c: Cust, val p: PromiseItem?)

    private val header = Header(h, "Monitoring", "Promise date list", { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, L/C no, phone")
    private val info = h.label("", 13f, C.text, true)
    private val recycler = RecyclerView(h)
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private val tabs = ArrayList<LinearLayout>()
    private val tabCounts = ArrayList<TextView>()
    private val tabLabels = ArrayList<TextView>()
    private var tab = 0
    private var rows: List<Row> = emptyList()
    private var today = todayStart()
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    private val c1 = intArrayOf(Color.parseColor("#F59E0B"), Color.parseColor("#EF4444"), Color.parseColor("#3B82F6"), Color.parseColor("#F97316"))
    private val c2 = intArrayOf(Color.parseColor("#D97706"), Color.parseColor("#B91C1C"), Color.parseColor("#1D4ED8"), Color.parseColor("#C2410C"))
    private val names = arrayOf("Today", "Expired", "Upcoming", "OD")

    // "Current month OD" button (4th list): loans whose overdue date falls in this month.
    private val odBtn = h.hbox()
    private val odIcon: ImageView = h.icon(R.drawable.ic_calendar, C.orange, 20)
    private val odLabel = h.label("", 15f, C.orange, true)
    private val odCount = h.label("0", 15f, C.orange, true)
    private var odName = ""

    init {
        Repo.ensureNotes()
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { onData() }
        header.addChip(unionBar.root)
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        val tr = h.hbox()
        tr.setPadding(h.dp(12), h.dp(14), h.dp(12), 0)
        for (i in 0..2) {
            val t = h.vbox()
            t.gravity = Gravity.CENTER
            t.setPadding(h.dp(6), h.dp(10), h.dp(6), h.dp(10))
            val n = h.label("0", 22f, c2[i], true)
            n.gravity = Gravity.CENTER
            val l = h.label(names[i], 12f, c2[i], true)
            l.gravity = Gravity.CENTER
            t.addView(n)
            t.addView(l, h.lp(1))
            t.isClickable = true
            t.setOnClickListener { tab = i; onData() }
            tabs.add(t)
            tabCounts.add(n)
            tabLabels.add(l)
            tr.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                if (i == 0) rightMargin = h.dp(5) else if (i == 2) leftMargin = h.dp(5) else setMargins(h.dp(5), 0, h.dp(5), 0)
            })
        }
        root.addView(tr, LinearLayout.LayoutParams(MATCH, WRAP))

        odBtn.gravity = Gravity.CENTER_VERTICAL
        odBtn.setPadding(h.dp(14), h.dp(11), h.dp(14), h.dp(11))
        odBtn.addView(odIcon, LinearLayout.LayoutParams(h.dp(20), h.dp(20)).apply { rightMargin = h.dp(10) })
        odBtn.addView(odLabel, LinearLayout.LayoutParams(0, WRAP, 1f))
        odBtn.addView(odCount)
        odBtn.isClickable = true
        odBtn.setOnClickListener { tab = 3; onData() }
        root.addView(odBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(h.dp(12), h.dp(10), h.dp(12), 0) })

        val ir = h.hbox()
        ir.setPadding(h.dp(16), h.dp(12), h.dp(12), h.dp(2))
        ir.addView(info)
        root.addView(ir, LinearLayout.LayoutParams(MATCH, WRAP))

        recycler.layoutManager = LinearLayoutManager(h)
        recycler.adapter = Adapter()
        recycler.clipToPadding = false
        recycler.setPadding(0, h.dp(4), 0, h.dp(16))
        root.addView(recycler, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    /** Every time the module is opened it starts on today's promises. */
    override fun onShow() {
        Repo.ensureNotes()
        tab = 0
        onData()
    }

    private fun paintTabs() {
        for (i in 0..2) {
            val on = i == tab
            tabs[i].background = if (on) h.gradient(c1[i], c2[i], 16) else h.shape(Color.WHITE, 16, C.line)
            tabs[i].elevation = h.dp(if (on) 4 else 1).toFloat()
            tabCounts[i].setTextColor(if (on) Color.WHITE else c2[i])
            tabLabels[i].setTextColor(if (on) Color.parseColor("#FFFFFFE0") else C.muted)
        }
        val on = tab == 3
        odBtn.background = if (on) h.gradient(c1[3], c2[3], 16) else h.shape(Color.WHITE, 16, C.line)
        odBtn.elevation = h.dp(if (on) 4 else 1).toFloat()
        odIcon.setColorFilter(if (on) Color.WHITE else c2[3])
        odLabel.setTextColor(if (on) Color.WHITE else c2[3])
        odCount.setTextColor(if (on) Color.WHITE else c2[3])
    }

    private fun onData() {
        unionBar.refresh()
        today = todayStart()
        paintTabs()
        refreshList()
    }

    private fun refreshList() {
        val all = ArrayList<Row>()
        var nToday = 0
        var nExp = 0
        var nUp = 0
        var nOd = 0
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        // this month: [first day, first day of next month)
        val cal = Calendar.getInstance()
        cal.timeInMillis = today
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val ms0 = cal.timeInMillis
        cal.add(Calendar.MONTH, 1)
        val ms1 = cal.timeInMillis
        odName = SimpleDateFormat("MMMM", Locale.ENGLISH).format(Date(today)) + "-OD"
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            val p = Repo.promises[c.id]
            var kind = -1
            if (p != null) kind = if (p.promiseMs == today) 0 else if (p.promiseMs < today) 1 else 2
            when (kind) { 0 -> nToday++; 1 -> nExp++; 2 -> nUp++ }
            val inOd = c.overdue >= ms0 && c.overdue < ms1 && c.overdue > 0L
            if (inOd) nOd++
            val show = if (tab == 3) inOd else kind == tab
            if (!show) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) ||
                    c.sCase.contains(q) || (digits.isNotEmpty() && c.sPhone.contains(digits)))) continue
            all.add(Row(c, p))
        }
        when (tab) {
            0 -> all.sortBy { it.c.sName }
            1 -> all.sortWith(compareByDescending<Row> { it.p?.promiseMs ?: 0L }.thenBy { it.c.sName })
            2 -> all.sortWith(compareBy<Row> { it.p?.promiseMs ?: 0L }.thenBy { it.c.sName })
            else -> all.sortWith(compareBy<Row> { it.c.overdue }.thenBy { it.c.sName })
        }
        tabCounts[0].text = nToday.toString()
        tabCounts[1].text = nExp.toString()
        tabCounts[2].text = nUp.toString()
        odLabel.text = odName
        odCount.text = nOd.toString()
        var bal = 0.0
        for (r in all) bal += r.c.balance
        val what = if (tab == 3) odName else names[tab].lowercase() + " promise dates"
        info.text = when {
            tab != 3 && !Repo.notesLoaded -> "Loading promise dates..."
            all.isEmpty() -> "No $what"
            else -> "${all.size} loans  \u2022  Balance ${money(bal)}"
        }
        info.setTextColor(c2[tab])
        rows = all
        recycler.adapter?.notifyDataSetChanged()
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val stripe = View(h)
        val avatar = h.avatar(44)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val bal = h.label("", 12f, C.muted)
        val note = h.label("", 13f, C.text)
        val meta = h.label("", 11f, C.muted)
        val date = h.hbox()
        val dateText = h.label("", 12f, C.primary, true)
        val rel = h.pill("", C.muted)
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            note.maxLines = 2
            note.ellipsize = TextUtils.TruncateAt.END
            meta.maxLines = 1
            meta.ellipsize = TextUtils.TruncateAt.END
            rel.maxLines = 1
            rel.setSingleLine()
            root.gravity = Gravity.CENTER_VERTICAL
            root.addView(stripe, LinearLayout.LayoutParams(h.dp(4), MATCH).apply { rightMargin = h.dp(10); topMargin = h.dp(1); bottomMargin = h.dp(1) })
            root.addView(avatar, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { rightMargin = h.dp(12) })
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(bal, h.lp(2))
            col.addView(note, h.lp(6))
            col.addView(meta, h.lp(3))
            date.gravity = Gravity.CENTER_VERTICAL
            date.setPadding(h.dp(10), h.dp(5), h.dp(12), h.dp(5))
            date.addView(h.icon(R.drawable.ic_calendar, C.primary, 14), LinearLayout.LayoutParams(h.dp(14), h.dp(14)).apply { rightMargin = h.dp(5) })
            date.addView(dateText)
            val pr = h.hbox()
            pr.gravity = Gravity.CENTER_VERTICAL
            pr.addView(date)
            pr.addView(rel, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(6) })
            col.addView(pr, h.lp(8, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            root.addView(call, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(10), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            fun at(): Row? {
                val p = vh.bindingAdapterPosition
                return if (p >= 0 && p < rows.size) rows[p] else null
            }
            r.setOnClickListener { at()?.let { Details.open(h, it.c, null) } }
            vh.call.setOnClickListener { at()?.let { Act.call(h, it.c.phone) } }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val row = rows[i]
            val c = row.c
            val p = row.p
            val col = c2[tab]
            h.paintAvatar(v.avatar, c.name)
            v.stripe.background = h.shape(col, 3)
            v.name.text = c.name
            v.l2.text = listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            v.l2.gone(v.l2.text.isEmpty())
            val bl = StringBuilder("Balance ").append(money(c.balance))
            if (c.due > 0.0) bl.append("  \u2022  Due ").append(money(c.due))
            v.bal.text = bl.toString()
            val txt = p?.text.orEmpty()
            v.note.text = txt
            v.note.gone(txt.isEmpty())
            val m = if (p == null) "" else listOf(p.by, fmtDateTime(p.at)).filter { it.isNotEmpty() && it != "-" }.joinToString("  \u2022  ")
            v.meta.text = m
            v.meta.gone(m.isEmpty())
            v.date.background = h.shape((col and 0xFFFFFF) or 0x24000000, 20)
            v.dateText.setTextColor(col)
            val dayMs = if (tab == 3) c.overdue else (p?.promiseMs ?: today)
            v.dateText.text = if (tab == 3) fmtDmy(c.overdue) else fmtPromise(p?.promise.orEmpty())
            val d = Math.round((dayMs - today) / 86400000.0).toInt()
            val rt = when {
                d == 0 -> "Today"
                d < 0 -> "${-d} day" + (if (-d == 1) "" else "s") + " late"
                else -> "in $d day" + (if (d == 1) "" else "s")
            }
            v.rel.text = rt
            v.rel.setTextColor(C.muted)
            v.rel.background = h.shape(Color.parseColor("#F1F5F9"), 20)
            v.call.gone(c.phone.isBlank())
        }
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
