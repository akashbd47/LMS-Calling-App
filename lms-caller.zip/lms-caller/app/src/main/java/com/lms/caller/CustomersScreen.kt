package com.lms.caller

import android.app.AlertDialog
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Pill-shaped union filter shared by every screen (the selection lives in Repo.unionSel).
 * [compact] = small translucent chip that sits inside the blue header.
 */
class UnionBar(private val h: HomeActivity, private val compact: Boolean = false, private val onChange: () -> Unit) {
    val root: LinearLayout = h.hbox()
    private val text: TextView = h.label("", if (compact) 12f else 13f, if (compact) Color.WHITE else C.primary, true)

    init {
        root.gravity = Gravity.CENTER_VERTICAL
        if (compact) {
            root.background = h.ripple(h.shape(Color.parseColor("#33FFFFFF"), 20), 20)
            root.setPadding(h.dp(10), h.dp(7), h.dp(12), h.dp(7))
            root.addView(h.icon(R.drawable.ic_filter, Color.WHITE, 16), LinearLayout.LayoutParams(h.dp(16), h.dp(16)).apply { rightMargin = h.dp(5) })
            text.maxLines = 1
            text.ellipsize = TextUtils.TruncateAt.END
            text.maxWidth = h.dp(92)
            root.addView(text)
        } else {
            root.background = h.ripple(h.shape(Color.WHITE, 20, C.line), 20)
            root.setPadding(h.dp(12), h.dp(8), h.dp(14), h.dp(8))
            root.addView(h.icon(R.drawable.ic_filter, C.primary, 18), LinearLayout.LayoutParams(h.dp(18), h.dp(18)).apply { rightMargin = h.dp(6) })
            root.addView(h.label("Union:", 13f, C.muted))
            root.addView(text, h.lp(0).apply { leftMargin = h.dp(4) })
        }
        root.isClickable = true
        root.setOnClickListener { show() }
        refresh()
    }

    fun refresh() {
        text.text = Repo.unionLabel()
    }

    private fun show() {
        val all = Repo.allUnions().toTypedArray()
        if (all.isEmpty()) { h.toast("No union data yet"); return }
        val checked = BooleanArray(all.size) { Repo.unionSel.contains(all[it]) }
        val b = AlertDialog.Builder(h)
            .setTitle("Filter by union")
            .setMultiChoiceItems(all, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Apply") { _, _ ->
                Repo.unionSel.clear()
                for (i in all.indices) if (checked[i]) Repo.unionSel.add(all[i])
                done()
            }
            .setNeutralButton("All unions") { _, _ ->
                Repo.unionSel.clear()
                done()
            }
        val mine = Repo.me?.unions.orEmpty()
        if (mine.isNotEmpty()) {
            b.setNegativeButton("My unions") { _, _ ->
                Repo.unionSel.clear()
                Repo.unionSel.addAll(mine)
                done()
            }
        } else {
            b.setNegativeButton("Cancel", null)
        }
        b.show()
    }

    private fun done() {
        Repo.unionInit = true
        refresh()
        onChange()
        Repo.touch()
    }
}

/** Customer rows. mode 0 = customer list, mode 2 = reschedule list (shows balance and the reschedule number). */
class CustList(private val h: HomeActivity, private val mode: Int, private val onOpen: (Cust) -> Unit) {
    val view = RecyclerView(h)
    private var rows: List<Cust> = emptyList()
    private var today = todayStart()

    init {
        view.layoutManager = LinearLayoutManager(h)
        view.adapter = Adapter()
        view.clipToPadding = false
        view.setPadding(0, h.dp(4), 0, h.dp(16))
    }

    fun submit(r: List<Cust>) {
        rows = r
        today = todayStart()
        view.adapter?.notifyDataSetChanged()
    }

    private fun style(tv: TextView, color: Int) {
        tv.setTextColor(color)
        tv.background = h.shape((color and 0xFFFFFF) or 0x1F000000, 20)
    }

    private inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val stripe = View(h)
        val avatar = h.avatar(44)
        val name = h.label("", 16f, C.text, true)
        val l2 = h.label("", 13f, C.muted)
        val l3 = h.label("", 12f, C.muted)
        val badge = h.pill("", C.muted)
        val rs = h.pill("", C.violet)
        val pills = h.hbox()
        val call: ImageView = h.icon(R.drawable.ic_phone, C.ok, 20)

        init {
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            l3.maxLines = 1
            l3.ellipsize = TextUtils.TruncateAt.END
            badge.maxLines = 1
            badge.setSingleLine()
            rs.maxLines = 1
            rs.setSingleLine()
            root.gravity = Gravity.CENTER_VERTICAL
            root.addView(stripe, LinearLayout.LayoutParams(h.dp(4), MATCH).apply { rightMargin = h.dp(10); topMargin = h.dp(1); bottomMargin = h.dp(1) })
            root.addView(avatar, LinearLayout.LayoutParams(h.dp(44), h.dp(44)).apply { rightMargin = h.dp(12) })
            val col = h.vbox()
            col.addView(name)
            col.addView(l2, h.lp(2))
            col.addView(l3, h.lp(1))
            pills.addView(badge)
            pills.addView(rs, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(6) })
            col.addView(pills, h.lp(8, WRAP, WRAP))
            root.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            call.setPadding(h.dp(11), h.dp(11), h.dp(11), h.dp(11))
            call.background = h.ripple(h.shape(Color.parseColor("#DCFCE7"), 24), 24)
            root.addView(call, LinearLayout.LayoutParams(h.dp(46), h.dp(46)).apply { leftMargin = h.dp(8) })
        }
    }

    private inner class Adapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val r = h.hbox()
            r.background = h.ripple(h.shape(Color.WHITE, 16, C.line), 16)
            r.elevation = h.dp(1).toFloat()
            r.setPadding(h.dp(10), h.dp(12), h.dp(12), h.dp(12))
            r.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                setMargins(h.dp(12), h.dp(5), h.dp(12), h.dp(5))
            }
            r.isClickable = true
            val vh = VH(r)
            r.setOnClickListener {
                val p = vh.bindingAdapterPosition
                if (p >= 0 && p < rows.size) onOpen(rows[p])
            }
            vh.call.setOnClickListener {
                val p = vh.bindingAdapterPosition
                if (p >= 0 && p < rows.size) Act.call(h, rows[p].phone)
            }
            return vh
        }

        override fun onBindViewHolder(v: VH, i: Int) {
            val c = rows[i]
            h.paintAvatar(v.avatar, c.name)
            v.name.text = c.name
            v.l2.text = listOf(c.village, c.union).filter { it.isNotEmpty() }.joinToString("  \u2022  ")
            v.l2.gone(v.l2.text.isEmpty())
            if (mode == 2) {
                v.l3.text = "L/C ${c.caseNo}  \u2022  ${c.progLabel}  \u2022  Balance ${money(c.balance)}"
                v.l3.gone(false)
            } else {
                val sb = StringBuilder()
                if (c.father.isNotEmpty()) sb.append("Father: ").append(c.father)
                if (c.spouse.isNotEmpty()) {
                    if (sb.isNotEmpty()) sb.append("  \u2022  ")
                    sb.append("Spouse: ").append(c.spouse)
                }
                v.l3.text = sb.toString()
                v.l3.gone(sb.isEmpty())
            }
            v.call.gone(c.phone.isBlank())
            if (c.overdue > 0L) {
                v.badge.visibility = View.VISIBLE
                if (c.overdue <= today) {
                    v.badge.text = "Overdue  " + fmtDate(c.overdue)
                    style(v.badge, C.bad)
                } else {
                    v.badge.text = "Next  " + fmtDate(c.overdue)
                    style(v.badge, C.teal)
                }
            } else {
                v.badge.visibility = View.GONE
            }
            if (c.rs) {
                v.rs.visibility = View.VISIBLE
                v.rs.text = String.format(java.util.Locale.US, "RS-%02d", c.rsNo)
                style(v.rs, C.violet)
            } else {
                v.rs.visibility = View.GONE
            }
            v.pills.gone(v.badge.visibility == View.GONE && v.rs.visibility == View.GONE)
            val sc = when {
                c.overdue > 0L && c.overdue <= today -> C.bad
                c.overdue > 0L -> C.teal
                c.rs -> C.violet
                else -> Color.parseColor("#CBD5E1")
            }
            v.stripe.background = h.shape(sc, 3)
        }
    }
}

/** Slim row under the header: count text on the left, optional extra view (scrolling chips) on the right. */
fun HomeActivity.infoRow(count: TextView, extra: View?): LinearLayout {
    val r = hbox()
    r.gravity = Gravity.CENTER_VERTICAL
    r.setPadding(dp(16), dp(10), dp(8), dp(2))
    r.addView(count)
    if (extra != null) r.addView(extra, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
    return r
}

class CustomersScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "Customers", Repo.status, { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search customer name")
    private val count = h.label("", 13f, C.primary, true)
    private val list = CustList(h, 0) { Details.open(h, it, null) }
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar

    private var inFather = false
    private var inSpouse = false
    private var inPhone = false
    private var inCase = false

    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    init {
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { refreshList() }
        header.addChip(unionBar.root)
        header.action(h, R.drawable.ic_sync) {
            Repo.refreshLoans(true)
            h.toast("Refreshing...")
        }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))

        val chips = h.hbox()
        chips.gravity = Gravity.CENTER_VERTICAL
        chips.addView(h.label("Also search:", 12f, C.muted), LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = h.dp(8) })
        chips.addView(toggle("Father") { inFather = it })
        chips.addView(toggle("Spouse") { inSpouse = it })
        chips.addView(toggle("Phone") { inPhone = it })
        chips.addView(toggle("L/C No") { inCase = it })
        val sv = HorizontalScrollView(h)
        sv.isHorizontalScrollBarEnabled = false
        sv.addView(chips)
        root.addView(h.infoRow(count, sv), LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(list.view, LinearLayout.LayoutParams(MATCH, 0, 1f))

        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    private fun toggle(t: String, set: (Boolean) -> Unit): TextView {
        val v = h.label(t, 12f, C.muted, true)
        var on = false
        fun paint() {
            v.setTextColor(if (on) Color.WHITE else C.primary)
            v.background = h.shape(if (on) C.primary else Color.WHITE, 20, if (on) C.primary else C.line)
        }
        v.setPadding(h.dp(12), h.dp(6), h.dp(12), h.dp(6))
        v.isClickable = true
        v.setOnClickListener {
            on = !on
            set(on)
            paint()
            refreshList()
        }
        paint()
        v.layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = h.dp(6) }
        return v
    }

    private fun onData() {
        header.sub.text = Repo.status
        unionBar.refresh()
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Cust>()
        for (c in Repo.loans) {
            if (!Repo.unionOk(c.union)) continue
            if (q.isNotEmpty()) {
                var ok = c.sName.contains(q)
                if (!ok && inFather) ok = c.sFather.contains(q)
                if (!ok && inSpouse) ok = c.sSpouse.contains(q)
                if (!ok && inCase) ok = c.sCase.contains(q)
                if (!ok && inPhone && digits.isNotEmpty()) ok = c.sPhone.contains(digits)
                if (!ok) continue
            }
            out.add(c)
        }
        if (q.isEmpty()) {
            out.sortWith(compareBy<Cust>({ if (it.overdue > 0L) 0 else 1 }, { it.overdue }, { it.sName }))
        } else {
            out.sortWith(compareBy<Cust>({ if (it.sName.startsWith(q)) 0 else 1 }, { it.sName }))
        }
        count.text = "${out.size} customers"
        list.submit(out)
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}

/** Reschedule list: every loan whose rescheduleNo is 1 or more. */
class RescheduleScreen(private val h: HomeActivity) : Screen {
    private val root = h.vbox()
    override val view: View get() = root

    private val header = Header(h, "Reschedule", Repo.status, { h.select(HomeActivity.HOME) })
    private val search = SearchBox(h, "Search name, L/C no, phone")
    private val count = h.label("", 13f, C.violet, true)
    private val list = CustList(h, 2) { Details.open(h, it, null) }
    private val handler = Handler(Looper.getMainLooper())
    private val unionBar: UnionBar
    private val listener: () -> Unit = { onData() }
    private val doSearch = Runnable { refreshList() }

    init {
        root.setBackgroundColor(C.bg)
        unionBar = UnionBar(h, true) { refreshList() }
        header.addChip(unionBar.root)
        header.action(h, R.drawable.ic_sync) {
            Repo.refreshLoans(true)
            h.toast("Refreshing...")
        }
        header.addSearch(search)
        root.addView(header.root, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(h.infoRow(count, null), LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(list.view, LinearLayout.LayoutParams(MATCH, 0, 1f))
        search.edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(doSearch)
                handler.postDelayed(doSearch, 150)
            }
        })
        Repo.addListener(listener)
        onData()
    }

    private fun onData() {
        header.sub.text = Repo.status
        unionBar.refresh()
        refreshList()
    }

    private fun refreshList() {
        val q = search.edit.text.toString().trim().lowercase()
        val digits = q.filter { it in '0'..'9' }
        val out = ArrayList<Cust>()
        var bal = 0.0
        for (c in Repo.loans) {
            if (!c.rs || !Repo.unionOk(c.union)) continue
            if (q.isNotEmpty() && !(c.sName.contains(q) || c.sFather.contains(q) || c.sSpouse.contains(q) ||
                    c.sCase.contains(q) || (digits.isNotEmpty() && c.sPhone.contains(digits)))) continue
            out.add(c)
            bal += c.balance
        }
        out.sortWith(compareBy<Cust>({ if (it.overdue > 0L) 0 else 1 }, { it.overdue }, { it.sName }))
        count.text = "${out.size} reschedule loans  \u2022  ${money(bal)}"
        list.submit(out)
    }

    override fun onDestroy() {
        Repo.removeListener(listener)
        handler.removeCallbacks(doSearch)
    }
}
