package com.lms.caller

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.Source

class MainActivity : Activity() {

    private enum class Mode { PASSWORD, UPLOAD, LOGIN, STATUS }

    private var mode = Mode.PASSWORD
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        sv.addView(root)
        setContentView(sv)

        mode = when {
            Prefs.config(this) == null -> Mode.PASSWORD
            Prefs.userId(this).isEmpty() -> Mode.LOGIN
            else -> Mode.STATUS
        }
        render()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        if (mode == Mode.STATUS) render()
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 15f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
            root.addView(this)
        }

    private fun field(hint: String, password: Boolean = false, number: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                number -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT
            }
            setSingleLine()
            root.addView(this)
        }

    private fun btn(t: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = t
            setOnClickListener { onClick() }
            root.addView(this)
        }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun render() {
        root.removeAllViews()
        when (mode) {
            Mode.PASSWORD -> screenPassword()
            Mode.UPLOAD -> screenUpload()
            Mode.LOGIN -> screenLogin()
            Mode.STATUS -> screenStatus()
        }
    }

    // ---------- 1. developer password ----------
    private fun screenPassword() {
        label("LMS Caller", 24f, true)
        label("Enter developer password")
        val pw = field("Password", password = true)
        btn("Continue") {
            if (Auth.check(pw.text.toString())) { mode = Mode.UPLOAD; render() } else toast("Wrong password")
        }
        if (Prefs.config(this) != null) {
            btn("Cancel") { mode = if (Prefs.userId(this).isEmpty()) Mode.LOGIN else Mode.STATUS; render() }
        }
    }

    // ---------- 2. upload google-services.json ----------
    private fun screenUpload() {
        label("Server setup", 22f, true)
        val cur = Prefs.config(this)
        label(if (cur != null) "Current server: ${cur.projectId}" else "No server set yet")
        label("Choose the google-services.json file of this branch's Firebase project.")
        btn("Choose google-services.json") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_JSON)
        }
        if (cur != null) {
            btn("Cancel") { mode = if (Prefs.userId(this).isEmpty()) Mode.LOGIN else Mode.STATUS; render() }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_JSON || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            val cfg = Fb.parse(text, packageName)
            stopService(Intent(this, CallService::class.java))
            Prefs.clearUser(this)
            Fb.reset()
            Prefs.saveConfig(this, cfg)
            toast("Server saved: ${cfg.projectId}")
            mode = Mode.LOGIN
            render()
        } catch (e: Exception) {
            toast("Invalid google-services.json: ${e.message}")
        }
    }

    // ---------- 3. user login ----------
    private fun screenLogin() {
        label("Login", 24f, true)
        label("Server: ${Prefs.config(this)?.projectId ?: "-"}")
        val id = field("User ID (GPF number)", number = true)
        val pw = field("Password", password = true)
        val status = label("")
        btn("Login") {
            val uid = id.text.toString().trim()
            val pass = pw.text.toString()
            if (uid.isEmpty() || pass.isEmpty()) { toast("Enter user ID and password"); return@btn }
            val db = Fb.db(this)
            if (db == null) { toast("Server not set"); return@btn }
            status.text = "Checking..."
            db.collection("Users").document(uid).get(Source.SERVER)
                .addOnSuccessListener { s ->
                    when {
                        !s.exists() || s.getString("password") != pass -> status.text = "Wrong user ID or password"
                        s.getString("status") == "pending" -> status.text = "Account is waiting for admin approval"
                        s.getString("status") != "active" -> status.text = "Account is inactive"
                        else -> {
                            Prefs.saveUser(this, uid, s.getString("name") ?: uid)
                            askPermissions()
                            startListener()
                            mode = Mode.STATUS
                            render()
                        }
                    }
                }
                .addOnFailureListener { status.text = "Could not connect: ${it.message}" }
        }
        btn("Change server") { mode = Mode.PASSWORD; render() }
    }

    // ---------- 4. running ----------
    private fun screenStatus() {
        label("LMS Caller", 24f, true)
        label("Server: ${Prefs.config(this)?.projectId ?: "-"}")
        label("User: ${Prefs.userName(this)} (${Prefs.userId(this)})")
        label("Call requests from the web app are received on this phone while the notification is showing.")
        label("SIM: calls use the phone's own default calling SIM (Phone settings).")

        val hasCall = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        if (!hasCall) btn("1. Allow phone calls") { askPermissions() }

        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            btn("2. Battery: set Unrestricted") {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }
        btn("Restart listener") { startListener(); toast("Listener started") }
        btn("Logout") {
            stopService(Intent(this, CallService::class.java))
            Prefs.clearUser(this)
            mode = Mode.LOGIN
            render()
        }
        btn("Change server") { mode = Mode.PASSWORD; render() }
    }

    private fun askPermissions() {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 2)
        }
    }

    private fun startListener() {
        ContextCompat.startForegroundService(this, Intent(this, CallService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (mode == Mode.STATUS) render()
    }

    companion object { private const val REQ_JSON = 10 }
}
