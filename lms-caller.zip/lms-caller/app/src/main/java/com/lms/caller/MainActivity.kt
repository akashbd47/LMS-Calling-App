package com.lms.caller

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.Source

class MainActivity : Activity() {

    private enum class Mode { PASSWORD, UPLOAD, LOGIN, STATUS }

    private val cPrimary = Color.parseColor("#1D4ED8")
    private val cDark = Color.parseColor("#1E3A8A")
    private val cBg = Color.parseColor("#F1F5F9")
    private val cText = Color.parseColor("#0F172A")
    private val cMuted = Color.parseColor("#64748B")
    private val cOk = Color.parseColor("#16A34A")
    private val cBad = Color.parseColor("#DC2626")

    private val tText = InputType.TYPE_CLASS_TEXT
    private val tPass = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    private val tNum = InputType.TYPE_CLASS_NUMBER
    private val tMulti = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE

    private var mode = Mode.PASSWORD
    private var devPass = ""
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var body: LinearLayout
    private lateinit var hdrTitle: TextView
    private lateinit var hdrSub: TextView
    private var dot: TextView? = null
    private var statusTitle: TextView? = null
    private var activityView: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            if (mode == Mode.STATUS) {
                refreshStatus()
                handler.postDelayed(this, 2000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cDark

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(26), dp(24), dp(30))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cDark, cPrimary))
        }
        val logo = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(76), dp(76)))
        hdrTitle = TextView(this).apply {
            textSize = 26f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        }
        hdrSub = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#CFE0FF"))
        }
        hdrTitle.setOnLongClickListener {
            if (!Prefs.isBundled(this) && (mode == Mode.LOGIN || mode == Mode.STATUS)) {
                mode = Mode.PASSWORD
                render()
            }
            true
        }
        header.addView(hdrTitle, lp(12))
        header.addView(hdrSub, lp(2))

        val sv = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(2), dp(16), dp(24))
        }
        sv.addView(body)
        page.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        page.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)

        mode = when {
            Prefs.config(this) == null -> Mode.PASSWORD
            Prefs.userId(this).isEmpty() -> Mode.LOGIN
            else -> Mode.STATUS
        }
        fromHome = intent.getBooleanExtra(EXTRA_STATUS, false)
        if (mode == Mode.STATUS) CallService.ensure(this)
        if (mode == Mode.STATUS && !fromHome) {
            goHome()
            return
        }
        render()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private var fromHome = false

    /** Opens the customer / location / map app (fresh task, so a previous session can never leak in). */
    private fun goHome() {
        startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    override fun onResume() {
        super.onResume()
        if (mode == Mode.STATUS) render()
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(topDp: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(topDp) }

    private fun shape(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = shape(Color.WHITE, 16)
        c.setPadding(dp(18), dp(18), dp(18), dp(18))
        c.elevation = dp(2).toFloat()
        body.addView(c, lp(14))
        return c
    }

    private fun tv(p: LinearLayout, t: String, size: Float = 15f, color: Int = cText, bold: Boolean = false, gap: Int = 0): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        p.addView(v, lp(gap))
        return v
    }

    private fun chip(p: LinearLayout, t: String, color: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 13f
        v.setTextColor(color)
        v.setTypeface(v.typeface, Typeface.BOLD)
        v.background = shape((color and 0xFFFFFF) or 0x22000000, 20)
        v.setPadding(dp(12), dp(6), dp(12), dp(6))
        p.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        return v
    }

    private fun input(p: LinearLayout, hint: String, kind: Int, lines: Int = 1): EditText {
        val e = EditText(this)
        e.hint = hint
        e.inputType = kind
        e.textSize = 16f
        e.setTextColor(cText)
        e.setHintTextColor(cMuted)
        e.background = shape(Color.parseColor("#F8FAFC"), 12, Color.parseColor("#CBD5E1"))
        e.setPadding(dp(14), dp(14), dp(14), dp(14))
        if (lines == 1) {
            e.setSingleLine()
        } else {
            e.minLines = lines
            e.gravity = Gravity.TOP
        }
        p.addView(e, lp(12))
        return e
    }

    /** kind: 0 = primary, 1 = outlined, 2 = danger */
    private fun button(p: LinearLayout, t: String, kind: Int = 0, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setAllCaps(false)
        b.textSize = 16f
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.stateListAnimator = null
        b.minimumHeight = dp(52)
        b.minHeight = dp(52)
        when (kind) {
            0 -> { b.setTextColor(Color.WHITE); b.background = shape(cPrimary, 12) }
            1 -> { b.setTextColor(cPrimary); b.background = shape(Color.WHITE, 12, cPrimary) }
            else -> { b.setTextColor(cBad); b.background = shape(Color.WHITE, 12, Color.parseColor("#FCA5A5")) }
        }
        b.setOnClickListener { onClick() }
        p.addView(b, lp(12))
        return b
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun backMode(): Mode = if (Prefs.userId(this).isEmpty()) Mode.LOGIN else Mode.STATUS

    private fun render() {
        handler.removeCallbacks(tick)
        body.removeAllViews()
        when (mode) {
            Mode.PASSWORD -> screenPassword()
            Mode.UPLOAD -> screenUpload()
            Mode.LOGIN -> screenLogin()
            Mode.STATUS -> screenStatus()
        }
    }

    // ---------- 1. developer password ----------
    private fun screenPassword() {
        hdrTitle.text = "KB LMS"
        hdrSub.text = "Developer setup"
        val c = card()
        tv(c, "Developer access", 18f, bold = true)
        tv(c, "Enter the developer password to set up this phone.", 14f, cMuted, gap = 4)
        val pw = input(c, "Password", tPass)
        button(c, "Continue") {
            if (Auth.check(pw.text.toString())) {
                devPass = pw.text.toString().trim()
                mode = Mode.UPLOAD
                render()
            } else {
                toast("Wrong password")
            }
        }
        if (Prefs.config(this) != null) {
            button(c, "Cancel", 1) { mode = backMode(); render() }
        }
    }

    // ---------- 2. server setup ----------
    private fun screenUpload() {
        hdrTitle.text = "Server setup"
        hdrSub.text = "Connect this phone to a branch"
        val cur = Prefs.config(this)

        val c1 = card()
        tv(c1, "Config file", 17f, bold = true)
        tv(c1, "Select this branch's config file.", 14f, cMuted, gap = 4)
        if (cur != null) chip(c1, "Current: ${cur.projectId}", cPrimary)
        button(c1, "Choose file") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_JSON)
        }

        val c2 = card()
        tv(c2, "Setup code", 17f, bold = true)
        tv(c2, "Paste a setup code made on another phone.", 14f, cMuted, gap = 4)
        val code = input(c2, "Paste setup code here", tMulti, 3)
        button(c2, "Import setup code") {
            val raw = code.text.toString().trim().split(Regex("\\s+")).last()
            try {
                applyConfig(Setup.fromCode(raw, devPass))
            } catch (e: Exception) {
                toast("Invalid setup code")
            }
        }

        if (cur != null) {
            val c3 = card()
            button(c3, "Share setup code", 1) { shareSetup() }
            button(c3, "Back", 1) { mode = backMode(); render() }
        }
    }

    private fun applyConfig(cfg: Cfg) {
        stopService(Intent(this, CallService::class.java))
        Prefs.clearUser(this)
        Repo.reset()
        Repo.wipeLocal()
        // delete the old server's offline copy first, then switch to the new server settings
        Fb.wipeCache(this) {
            Fb.reset()
            Prefs.saveConfig(this, cfg)
            toast("Setup saved")
            mode = Mode.LOGIN
            render()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_JSON || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            applyConfig(Fb.parse(text, packageName))
        } catch (e: Exception) {
            toast("Invalid config file")
        }
    }

    // ---------- 3. user login ----------
    private fun screenLogin() {
        hdrTitle.text = "Welcome"
        hdrSub.text = "Sign in to receive call requests"
        val c = card()
        tv(c, "Sign in", 18f, bold = true)
        val id = input(c, "User ID (GPF number)", tNum)
        val pw = input(c, "Password", tPass)
        val status = tv(c, "", 14f, cBad, gap = 10)
        button(c, "Login") {
            val uid = id.text.toString().trim()
            val pass = pw.text.toString()
            if (uid.isEmpty() || pass.isEmpty()) { status.text = "Enter user ID and password"; return@button }
            val db = Fb.db(this)
            if (db == null) { status.text = "Server not set"; return@button }
            status.setTextColor(cMuted)
            status.text = "Checking..."
            db.collection("Users").document(uid).get(Source.SERVER)
                .addOnSuccessListener { s ->
                    status.setTextColor(cBad)
                    when {
                        !s.exists() || s.getString("password") != pass -> status.text = "Wrong user ID or password"
                        s.getString("status") == "pending" -> status.text = "Account is waiting for admin approval"
                        s.getString("status") != "active" -> status.text = "Account is inactive"
                        else -> {
                            Prefs.saveUser(this, uid, s.getString("name") ?: uid)
                            askPermissions()
                            startListener()
                            mode = Mode.STATUS
                            render()
                        }
                    }
                }
                .addOnFailureListener {
                    status.setTextColor(cBad)
                    status.text = "Could not connect: ${it.message}"
                }
        }
    }

    // ---------- 4. running ----------
    private fun screenStatus() {
        hdrTitle.text = "Hello, ${Prefs.userName(this)}"
        hdrSub.text = "User ID ${Prefs.userId(this)}"

        val c1 = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val d = TextView(this)
        d.text = "\u25CF"
        d.textSize = 22f
        dot = d
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        statusTitle = tv(col, "", 18f, bold = true)
        activityView = tv(col, "", 13f, cMuted, gap = 2)
        row.addView(d)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        c1.addView(row)
        refreshStatus()

        val c2 = card()
        tv(c2, "Setup checklist", 16f, bold = true)
        val hasCall = phoneGranted()
        checkRow(c2, "Phone call permission", hasCall, "Allow") { askPermissions() }
        val pm = getSystemService(PowerManager::class.java)
        checkRow(c2, "Battery: Unrestricted", pm.isIgnoringBatteryOptimizations(packageName), "Fix") { openBattery() }
        if (Build.VERSION.SDK_INT >= 30) {
            checkRow(c2, "Auto-pause if unused: OFF", packageManager.isAutoRevokeWhitelisted, "Fix") { openAutoPause() }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            val n = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            checkRow(c2, "Notifications", n, "Allow") {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        val c3 = card()
        if (!fromHome) button(c3, "Open Customers, Location & Map", 0) { goHome() }
        button(c3, "Restart listener", if (fromHome) 0 else 1) { startListener(); toast("Listener restarted") }
        button(c3, "Logout", 2) {
            stopService(Intent(this, CallService::class.java))
            Prefs.clearUser(this)
            Repo.reset()
            Repo.wipeLocal()     // no customer / loan / location data stays on the phone after logout
            Fb.wipeCache(this)
            fromHome = false
            mode = Mode.LOGIN
            render()
        }

        handler.postDelayed(tick, 2000)
    }

    private fun checkRow(p: LinearLayout, title: String, ok: Boolean, action: String, onClick: () -> Unit) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 15f
        t.setTextColor(cText)
        r.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val b = TextView(this)
        b.textSize = 13f
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.setPadding(dp(14), dp(8), dp(14), dp(8))
        if (ok) {
            b.text = "\u2713 Done"
            b.setTextColor(cOk)
            b.background = shape(Color.parseColor("#DCFCE7"), 20)
        } else {
            b.text = action
            b.setTextColor(Color.WHITE)
            b.background = shape(cPrimary, 20)
            b.setOnClickListener { onClick() }
        }
        r.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        p.addView(r, lp(12))
    }

    @Suppress("DEPRECATION")
    private fun serviceRunning(): Boolean {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        return am.getRunningServices(100).any { it.service.className == CallService::class.java.name }
    }

    private fun refreshStatus() {
        if (!CallService.alive) CallService.ensure(this)
        val run = serviceRunning() || CallService.alive
        val col = if (run) cOk else cBad
        dot?.setTextColor(col)
        statusTitle?.text = if (run) "Listening for call requests" else "Listener stopped"
        statusTitle?.setTextColor(col)
        val last = Prefs.info(this)
        val sync = Prefs.syncInfo(this)
        activityView?.text = (if (last.isEmpty()) "No activity yet" else last) +
            (if (sync.isNotEmpty()) "\n\nLocation sync: $sync" else "")
    }

    private fun openBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun shareSetup() {
        val cfg = Prefs.config(this) ?: return
        val et = EditText(this)
        et.hint = "Developer password"
        et.inputType = tPass
        et.setPadding(dp(20), dp(16), dp(20), dp(16))
        AlertDialog.Builder(this)
            .setTitle("Share setup code")
            .setMessage("Enter the developer password. The code is encrypted and only works with this password.")
            .setView(et)
            .setPositiveButton("Share") { _, _ ->
                val pw = et.text.toString().trim()
                if (!Auth.check(pw)) {
                    toast("Wrong password")
                } else {
                    val code = Setup.encrypt(Setup.toJson(cfg), pw)
                    val send = Intent(Intent.ACTION_SEND)
                    send.type = "text/plain"
                    send.putExtra(Intent.EXTRA_TEXT, "KB LMS setup code:\n$code")
                    startActivity(Intent.createChooser(send, "Share setup code"))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun phoneGranted(): Boolean =
        checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        if (!phoneGranted()) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE), 2)
        }
    }

    private fun openAutoPause() {
        try {
            startActivity(Intent(Intent.ACTION_AUTO_REVOKE_PERMISSIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun startListener() {
        ContextCompat.startForegroundService(this, Intent(this, CallService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (mode == Mode.STATUS) render()
    }

    companion object {
        private const val REQ_JSON = 10
        const val EXTRA_STATUS = "status"
    }
}
