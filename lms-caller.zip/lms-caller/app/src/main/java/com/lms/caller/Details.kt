package com.lms.caller

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Color
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.firebase.firestore.ListenerRegistration
import java.util.Calendar

/** Full-screen customer details. Works for a loan row, a saved location, or both. */
class Details private constructor(private val h: HomeActivity, private var cust: Cust?, private var loc: Loc?) {
    val root = h.vbox()
    private val body = h.vbox()
    private val header: Header
    private var note: NoteDoc? = null
    private var noteLoaded = false
    private var reg: ListenerRegistration? = null
    private val listener: () -> Unit = { relink(); fill() }

    init {
        header = Header(h, cust?.name ?: loc?.name ?: "Customer", "", { h.pop() })
        root.setBackgroundColor(C.bg)
        root.addView(header.root)
        val sv = ScrollView(h)
        sv.isFillViewport = true
        body.setPadding(h.dp(14), h.dp(10), h.dp(14), h.dp(24))
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    companion object {
        private val PIN_COLOR = Color.parseColor("#7C3AED")

        fun open(h: HomeActivity, c: Cust?, l: Loc?) {
            val d = Details(h, c, l)
            h.push(d.root) { d.close() }
            d.start()
        }
    }

    private fun start() {
        relink()
        Repo.addListener(listener)
        cust?.let { c ->
            reg = Repo.noteListen(c.id) { n ->
                note = n
                noteLoaded = true
                fill()
            }
        }
        if (cust == null) noteLoaded = true
        fill()
    }

    private fun close() {
        Repo.removeListener(listener)
        reg?.remove()
        reg = null
    }

    private fun relink() {
        val c = cust
        val l = loc
        if (c != null) {
            loc = Repo.locFor(c) ?: l
        } else if (l != null) {
            loc = Repo.locs[l.id] ?: l
            cust = Repo.custFor(loc!!)
        }
    }

    private fun phone(): String = cust?.phone?.takeIf { it.isNotBlank() } ?: loc?.phone ?: ""

    private fun kv(p: LinearLayout, k: String, v: String, color: Int = C.text) {
        val r = h.hbox()
        r.gravity = Gravity.TOP
        r.addView(h.label(k, 13f, C.muted), LinearLayout.LayoutParams(0, WRAP, 0.4f))
        val t = h.label(if (v.isBlank()) "-" else v, 14f, color, true)
        r.addView(t, LinearLayout.LayoutParams(0, WRAP, 0.6f))
        p.addView(r, h.lp(9))
    }

    private fun section(t: String): LinearLayout {
        val c = h.card()
        c.addView(h.label(t, 13f, C.primary, true))
        body.addView(c, h.lp(12))
        return c
    }

    private fun tile(res: Int, name: String, enabled: Boolean, color: Int, onClick: () -> Unit): LinearLayout {
        val col = h.vbox()
        col.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        val fg = if (enabled) color else Color.parseColor("#94A3B8")
        val tint = if (enabled) (color and 0xFFFFFF) or 0x1F000000.toInt() else Color.parseColor("#F1F5F9")
        val ic = h.icon(res, fg, 22)
        ic.setPadding(h.dp(15), h.dp(15), h.dp(15), h.dp(15))
        ic.background = h.ripple(h.shape(tint, 30), 30)
        col.addView(ic, LinearLayout.LayoutParams(h.dp(56), h.dp(56)))
        val t = h.label(name, 12f, if (enabled) C.text else C.muted, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        col.addView(t, h.lp(7, WRAP, WRAP))
        col.isClickable = true
        col.setOnClickListener { if (enabled) onClick() }
        return col
    }

    private fun fill() {
        body.removeAllViews()
        val c = cust
        val l = loc
        header.title.text = c?.name ?: l?.name ?: "Customer"
        header.sub.text = listOf(c?.village ?: l?.village ?: "", c?.union ?: l?.union ?: "")
            .filter { it.isNotEmpty() }.joinToString("  \u2022  ")

        val tiles = h.hbox()
        tiles.gravity = Gravity.TOP
        tiles.background = h.shape(Color.WHITE, 18, C.line)
        tiles.elevation = h.dp(2).toFloat()
        tiles.setPadding(h.dp(6), h.dp(16), h.dp(6), h.dp(14))
        val hasPhone = normalizePhone(phone()).isNotEmpty()
        val tw = { LinearLayout.LayoutParams(0, WRAP, 1f) }
        tiles.addView(tile(R.drawable.ic_pin, if (l != null) "Update Location" else "Add Location", c != null, PIN_COLOR) {
            c?.let { LocationEditor.open(h, it) }
        }, tw())
        tiles.addView(tile(R.drawable.ic_nav, "Navigation", l != null, C.primary) {
            l?.let { Act.navigate(h, it.lat, it.lng, it.name) }
        }, tw())
        tiles.addView(tile(R.drawable.ic_edit, "Add Note", c != null, C.warn) { addNoteDialog() }, tw())
        tiles.addView(tile(R.drawable.ic_phone, "Call", hasPhone, C.ok) { Act.call(h, phone()) }, tw())
        body.addView(tiles, h.lp(4))

        val s1 = section("CUSTOMER")
        kv(s1, "Name", c?.name ?: l?.name ?: "")
        kv(s1, "Father", c?.father ?: l?.father ?: "")
        kv(s1, "Spouse", c?.spouse ?: l?.spouse ?: "")
        kv(s1, "Village", c?.village ?: l?.village ?: "")
        kv(s1, "Union", c?.union ?: l?.union ?: "")
        kv(s1, "Phone", phone())

        if (c != null) {
            val s2 = section("LOAN")
            kv(s2, "Programme", c.progLabel)
            kv(s2, "Loan case", c.caseNo)
            val late = c.overdue > 0L && c.overdue <= todayStart()
            kv(s2, "Overdue date", fmtDate(c.overdue), if (late) C.bad else C.text)
            kv(s2, "Balance", fmtAmt(c.balance))
            kv(s2, "Due", fmtAmt(c.due))
            kv(s2, "Received", fmtAmt(c.received))
        }

        val s4 = section("NOTES")
        val n = note
        if (c == null) {
            s4.addView(h.label("Notes are available for customers with an active loan.", 14f, C.muted), h.lp(8))
        } else if (!noteLoaded) {
            s4.addView(h.label("Loading...", 14f, C.muted), h.lp(8))
        } else {
            val last = n?.entries?.firstOrNull()
            val text = n?.lastNote.orEmpty().ifEmpty { last?.text.orEmpty() }
            if (n == null || text.isEmpty()) {
                s4.addView(h.label("No notes yet.", 14f, C.muted), h.lp(8))
            } else {
                val by = n.lastBy.ifEmpty { last?.by.orEmpty() }
                val at = if (n.lastAt > 0L) n.lastAt else (last?.at ?: 0L)
                val promise = n.promise.ifEmpty { last?.promise.orEmpty() }
                val b = h.vbox()
                b.background = h.shape(Color.parseColor("#F8FAFC"), 14, C.line)
                b.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(12))
                val top = h.hbox()
                top.gravity = Gravity.TOP
                top.addView(h.label(text, 15f, C.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))
                if (promise.isNotEmpty()) top.addView(datePill(promise), LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(10) })
                b.addView(top)
                val meta = listOf(by, fmtDateTime(at)).filter { it.isNotEmpty() && it != "-" }.joinToString("  \u2022  ")
                if (meta.isNotEmpty()) b.addView(h.label(meta, 11f, C.muted), h.lp(6))
                s4.addView(b, h.lp(10))
            }
            if (Repo.can("note-add")) {
                s4.addView(h.btn("Add note", 0, R.drawable.ic_add) { addNoteDialog() }, h.lp(14))
            }
        }
    }

    /** Highlighted promise date (dd-MM-yyyy): red = expired, amber = today, blue = upcoming. */
    private fun datePill(promise: String): LinearLayout {
        val ms = promiseMs(promise)
        val today = todayStart()
        val col = if (ms in 1 until today) C.bad else if (ms == today) Color.parseColor("#D97706") else C.primary
        val r = h.hbox()
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = h.shape((col and 0xFFFFFF) or 0x24000000, 20)
        r.setPadding(h.dp(10), h.dp(6), h.dp(12), h.dp(6))
        r.addView(h.icon(R.drawable.ic_calendar, col, 14), LinearLayout.LayoutParams(h.dp(14), h.dp(14)).apply { rightMargin = h.dp(5) })
        r.addView(h.label(fmtPromise(promise), 13f, col, true))
        return r
    }

    private fun addNoteDialog() {
        val c = cust ?: return
        if (!Repo.can("note-add")) { h.toast("You do not have permission to add notes"); return }
        val col = h.vbox()
        col.setPadding(h.dp(20), h.dp(8), h.dp(20), 0)
        val et = EditText(h)
        et.hint = "Write note..."
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.minLines = 3
        et.gravity = Gravity.TOP
        et.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(1000))
        col.addView(et)
        var date = ""
        val dateTv: TextView = h.label("Promise date: tap to select", 15f, C.primary, true)
        dateTv.setPadding(0, h.dp(16), 0, h.dp(8))
        dateTv.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(h, { _, y, m, d ->
                date = String.format("%04d-%02d-%02d", y, m + 1, d)
                dateTv.text = "Promise date: $date"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        col.addView(dateTv)
        val dlg = AlertDialog.Builder(h)
            .setTitle("Note - " + c.name)
            .setView(col)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val text = et.text.toString().trim()
            if (text.isEmpty()) { h.toast("Note text is required"); return@setOnClickListener }
            if (date.isEmpty()) { h.toast("Promise date is required"); return@setOnClickListener }
            dlg.dismiss()
            h.toast("Saving note...")
            Repo.addNote(c, text, date) { ok, msg -> h.toast(if (ok) "Note saved" else msg) }
        }
    }
}
