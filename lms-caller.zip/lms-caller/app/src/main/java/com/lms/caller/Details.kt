package com.lms.caller

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

/** Full-screen customer details. Works for a loan row, a saved location, or both. */
class Details private constructor(private val h: HomeActivity, private var cust: Cust?, private var loc: Loc?) {
    val root = h.vbox()
    private val body = h.vbox()
    private val header: Header
    private var note: NoteDoc? = null
    private var noteLoaded = false
    private val listener: () -> Unit = { relink(); loadNote(); fill() }

    init {
        header = Header(h, cust?.name ?: loc?.name ?: "Customer", "", { h.pop() })
        root.setBackgroundColor(C.bg)
        root.addView(header.root)
        val sv = ScrollView(h)
        sv.isFillViewport = true
        body.setPadding(h.dp(14), h.dp(10), h.dp(14), h.dp(24))
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    companion object {
        private val PIN_COLOR = Color.parseColor("#7C3AED")

        fun open(h: HomeActivity, c: Cust?, l: Loc?) {
            val d = Details(h, c, l)
            h.push(d.root) { d.close() }
            d.start()
        }
    }

    private fun start() {
        relink()
        Repo.addListener(listener)
        loadNote()
        fill()
    }

    private fun close() {
        Repo.removeListener(listener)
    }

    /** The last note comes from the phone's own copy (kept live by Repo), so opening a customer costs no read. */
    private fun loadNote() {
        val c = cust
        note = if (c != null) Repo.noteFor(c.id) else null
        noteLoaded = c == null || Repo.notesLoaded
    }

    private fun relink() {
        val c = cust
        val l = loc
        if (c != null) {
            loc = Repo.locFor(c) ?: l
        } else if (l != null) {
            loc = Repo.locs[l.id] ?: l
            cust = Repo.custFor(loc!!)
        }
    }

    private fun phone(): String = cust?.phone?.takeIf { it.isNotBlank() } ?: loc?.phone ?: ""

    private val DAY = 86400000L

    private fun medium(t: TextView): TextView {
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return t
    }

    /** Value cell: light dotted border, small caption on top, value below (everything left aligned). */
    private fun cell(k: String, v: String, color: Int = C.text): LinearLayout {
        val b = h.vbox()
        val bg = h.shape(Color.parseColor("#FAFBFE"), 12)
        bg.setStroke(h.dp(1), Color.parseColor("#C5D0E2"), h.dp(4).toFloat(), h.dp(3).toFloat())
        b.background = bg
        b.setPadding(h.dp(12), h.dp(9), h.dp(12), h.dp(10))
        b.addView(h.label(k, 11f, C.muted))
        val t = medium(h.label(if (v.isBlank()) "-" else v, 14.5f, color))
        t.maxLines = 2
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        b.addView(t, h.lp(3))
        return b
    }

    /** One line of the info card: one wide cell, or two cells side by side. */
    private fun line(p: LinearLayout, a: View, b: View? = null) {
        val r = LinearLayout(h)
        r.orientation = LinearLayout.HORIZONTAL
        if (b == null) {
            r.addView(a, LinearLayout.LayoutParams(MATCH, WRAP))
        } else {
            r.addView(a, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = h.dp(4) })
            r.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = h.dp(4) })
        }
        p.addView(r, h.lp(8))
    }

    private fun heading(p: LinearLayout, t: String, chip: View? = null) {
        val head = h.hbox()
        val bar = View(h)
        bar.background = h.shape(C.primary, 2)
        head.addView(bar, LinearLayout.LayoutParams(h.dp(3), h.dp(14)).apply { rightMargin = h.dp(8) })
        val title = h.label(t, 12f, Color.parseColor("#475569"), true)
        title.letterSpacing = 0.08f
        head.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (chip != null) head.addView(chip)
        p.addView(head)
    }

    /** One white card with a soft shadow; the Customer Info and Loan Information sections sit inside it. */
    private fun infoCard(): LinearLayout {
        val c = h.vbox()
        c.background = h.shape(Color.WHITE, 20, Color.parseColor("#E6EBF2"))
        h.softShadow(c, 4)
        c.setPadding(h.dp(14), h.dp(16), h.dp(14), h.dp(16))
        body.addView(c, h.lp(12))
        return c
    }

    private fun section(t: String): LinearLayout {
        val c = h.vbox()
        c.background = h.shape(Color.WHITE, 20, Color.parseColor("#E6EBF2"))
        h.softShadow(c, 4)
        c.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(8))
        val head = h.hbox()
        val bar = View(h)
        bar.background = h.shape(C.primary, 2)
        head.addView(bar, LinearLayout.LayoutParams(h.dp(3), h.dp(14)).apply { rightMargin = h.dp(8) })
        val title = h.label(t, 12f, Color.parseColor("#475569"), true)
        title.letterSpacing = 0.08f
        head.addView(title)
        c.addView(head)
        body.addView(c, h.lp(12))
        return c
    }

    private fun tile(res: Int, name: String, enabled: Boolean, color: Int, onClick: () -> Unit): LinearLayout {
        val col = h.vbox()
        col.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        val fg = if (enabled) color else Color.parseColor("#94A3B8")
        val tint = if (enabled) (color and 0xFFFFFF) or 0x1A000000 else Color.parseColor("#F1F5F9")
        val ic = h.icon(res, fg, 22)
        ic.setPadding(h.dp(15), h.dp(15), h.dp(15), h.dp(15))
        ic.background = h.ripple(h.shape(tint, 28), 28)
        col.addView(ic, LinearLayout.LayoutParams(h.dp(54), h.dp(54)))
        val t = medium(h.label(name, 12f, if (enabled) C.text else C.muted))
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        col.addView(t, h.lp(7, WRAP, WRAP))
        col.isClickable = true
        col.setOnClickListener { if (enabled) onClick() }
        return col
    }

    private fun amtOrDash(v: Double): String = if (v > 0.0) money(v) else "-"

    private fun fill() {
        body.removeAllViews()
        val c = cust
        val l = loc
        header.title.text = c?.name ?: l?.name ?: "Customer"
        header.sub.text = listOf(c?.village ?: l?.village ?: "", c?.union ?: l?.union ?: "")
            .filter { it.isNotEmpty() }.joinToString("  \u2022  ")

        val tiles = h.hbox()
        tiles.gravity = Gravity.TOP
        tiles.background = h.shape(Color.WHITE, 20, Color.parseColor("#E6EBF2"))
        h.softShadow(tiles, 4)
        tiles.setPadding(h.dp(6), h.dp(16), h.dp(6), h.dp(14))
        val hasPhone = normalizePhone(phone()).isNotEmpty()
        val tw = { LinearLayout.LayoutParams(0, WRAP, 1f) }
        tiles.addView(tile(R.drawable.ic_h_pin, if (l != null) "Update Location" else "Add Location", c != null, PIN_COLOR) {
            c?.let { LocationEditor.open(h, it) }
        }, tw())
        tiles.addView(tile(R.drawable.ic_h_navigate, "Navigation", l != null, C.primary) {
            l?.let { Act.navigate(h, it.lat, it.lng, it.name) }
        }, tw())
        tiles.addView(tile(R.drawable.ic_h_edit, "Add Note", c != null, C.warn) { addNoteDialog() }, tw())
        tiles.addView(tile(R.drawable.ic_h_call, "Call", hasPhone, C.ok) { Act.call(h, phone()) }, tw())
        body.addView(tiles, h.lp(4))

        val info = infoCard()
        heading(info, "CUSTOMER INFO")
        line(info, cell("Name", c?.name ?: l?.name ?: ""))
        line(info, cell("Father", c?.father ?: l?.father ?: ""), cell("Spouse", c?.spouse ?: l?.spouse ?: ""))
        line(info, cell("Village", c?.village ?: l?.village ?: ""), cell("Union", c?.union ?: l?.union ?: ""))
        line(info, cell("Phone", phone()))

        if (c != null) {
            val today = todayStart()
            val late = c.overdue > 0L && c.overdue <= today
            val days = if (late) ((today - c.overdue) / DAY).toInt() else 0
            val chip: View = when {
                late -> h.pill(if (days > 0) "Overdue \u2022 $days days" else "Overdue today", C.bad)
                c.due > 0.0 -> h.pill("Installment due", C.warn)
                else -> h.pill("Regular", C.ok)
            }
            val gap = View(h)
            info.addView(gap, LinearLayout.LayoutParams(MATCH, h.dp(10)))
            val divider = View(h)
            divider.setBackgroundColor(Color.parseColor("#EEF2F7"))
            info.addView(divider, LinearLayout.LayoutParams(MATCH, h.dp(1)))
            val hp = View(h)
            info.addView(hp, LinearLayout.LayoutParams(MATCH, h.dp(14)))
            heading(info, "LOAN INFORMATION", chip)
            line(info, cell("Programme", c.progLabel))
            val od = if (c.overdue > 0L) fmtDate(c.overdue) else "-"
            line(info, cell("Loan case", c.caseNo), cell("Overdue date", od, if (late) C.bad else C.text))
            line(info, cell("Installment", amtOrDash(c.installment), C.primary), cell("Balance", money(c.balance)))
            val dueFg = if (late) C.bad else if (c.due > 0.0) Color.parseColor("#B45309") else C.text
            line(info, cell("Due", money(c.due), dueFg), cell("Received", money(c.received), Color.parseColor("#15803D")))
        }

        val s4 = section("NOTES")
        val n = note
        if (c == null) {
            s4.addView(h.label("Notes are available for customers with an active loan.", 14f, C.muted), h.lp(8))
        } else if (!noteLoaded) {
            s4.addView(h.label("Loading...", 14f, C.muted), h.lp(8))
        } else {
            val last = n?.entries?.firstOrNull()
            val text = n?.lastNote.orEmpty().ifEmpty { last?.text.orEmpty() }
            if (n == null || text.isEmpty()) {
                s4.addView(h.label("No notes yet.", 14f, C.muted), h.lp(8))
            } else {
                val by = n.lastBy.ifEmpty { last?.by.orEmpty() }
                val at = if (n.lastAt > 0L) n.lastAt else (last?.at ?: 0L)
                val promise = n.promise.ifEmpty { last?.promise.orEmpty() }
                val b = h.vbox()
                b.background = h.shape(Color.parseColor("#F8FAFC"), 14, C.line)
                b.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(12))
                val top = h.hbox()
                top.gravity = Gravity.TOP
                top.addView(medium(h.label(text, 15f, C.text)), LinearLayout.LayoutParams(0, WRAP, 1f))
                if (promise.isNotEmpty()) top.addView(datePill(promise), LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(10) })
                b.addView(top)
                val meta = listOf(by, fmtDateTime(at)).filter { it.isNotEmpty() && it != "-" }.joinToString("  \u2022  ")
                if (meta.isNotEmpty()) b.addView(h.label(meta, 11f, C.muted), h.lp(6))
                s4.addView(b, h.lp(10))
            }
            if (Repo.can("note-add")) {
                s4.addView(h.btn("Add note", 0, R.drawable.ic_add) { addNoteDialog() }, h.lp(14))
                s4.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(16))
            }
        }
    }

    /** Highlighted promise date (dd-MM-yyyy): red = expired, amber = today, blue = upcoming. */
    private fun datePill(promise: String): LinearLayout {
        val ms = promiseMs(promise)
        val today = todayStart()
        val col = if (ms in 1 until today) C.bad else if (ms == today) Color.parseColor("#D97706") else C.primary
        val r = h.hbox()
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = h.shape((col and 0xFFFFFF) or 0x24000000, 20)
        r.setPadding(h.dp(10), h.dp(6), h.dp(12), h.dp(6))
        r.addView(h.icon(R.drawable.ic_calendar, col, 14), LinearLayout.LayoutParams(h.dp(14), h.dp(14)).apply { rightMargin = h.dp(5) })
        r.addView(h.label(fmtPromise(promise), 13f, col, true))
        return r
    }

    private fun addNoteDialog() {
        val c = cust ?: return
        if (!Repo.can("note-add")) { h.toast("You do not have permission to add notes"); return }
        val col = h.vbox()
        col.setPadding(h.dp(20), h.dp(8), h.dp(20), 0)
        val et = EditText(h)
        et.hint = "Write note..."
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.minLines = 3
        et.gravity = Gravity.TOP
        et.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(1000))
        col.addView(et)
        var date = ""
        val dateTv: TextView = h.label("Promise date: tap to select", 15f, C.primary, true)
        dateTv.setPadding(0, h.dp(16), 0, h.dp(8))
        dateTv.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(h, { _, y, m, d ->
                date = String.format("%04d-%02d-%02d", y, m + 1, d)
                dateTv.text = "Promise date: $date"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        col.addView(dateTv)
        val dlg = AlertDialog.Builder(h)
            .setTitle("Note - " + c.name)
            .setView(col)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val text = et.text.toString().trim()
            if (text.isEmpty()) { h.toast("Note text is required"); return@setOnClickListener }
            if (date.isEmpty()) { h.toast("Promise date is required"); return@setOnClickListener }
            dlg.dismiss()
            h.toast("Saving note...")
            Repo.addNote(c, text, date) { ok, msg -> h.toast(if (ok) "Note saved" else msg) }
        }
    }
}
