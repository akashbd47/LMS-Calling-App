package com.lms.caller

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TableRow
import android.widget.TableLayout
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

/** Full-screen customer details. Works for a loan row, a saved location, or both. */
private val INK = Color.parseColor("#0F172A")
private val EDGE = Color.parseColor("#475569")
private val HAIR = Color.parseColor("#CBD5E1")
private val BAND = Color.parseColor("#BDD7EE")

class Details private constructor(private val h: HomeActivity, private var cust: Cust?, private var loc: Loc?) {
    val root = h.vbox()
    private val body = h.vbox()
    private val header: Header
    private val headVillage = h.label("", 12f, Color.parseColor("#DCE7FF"), true)
    private val headUnion = h.label("", 11f, Color.parseColor("#A9C2F5"))
    private val headRight = h.vbox()
    private var note: NoteDoc? = null
    private var noteLoaded = false
    private val listener: () -> Unit = { relink(); loadNote(); fill() }

    init {
        header = Header(h, cust?.name ?: loc?.name ?: "Customer", "", { h.pop() })
        root.setBackgroundColor(C.bg)
        headVillage.gravity = Gravity.END
        headUnion.gravity = Gravity.END
        for (t in listOf(headVillage, headUnion)) {
            t.maxLines = 1
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            t.maxWidth = h.dp(150)
        }
        headRight.gravity = Gravity.END
        headRight.addView(headVillage)
        headRight.addView(headUnion, h.lp(1))
        header.actions.gravity = Gravity.CENTER_VERTICAL
        header.actions.addView(headRight, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = h.dp(6) })
        header.sub.visibility = View.GONE
        root.addView(header.root)
        val sv = ScrollView(h)
        sv.isFillViewport = true
        body.setPadding(h.dp(14), h.dp(10), h.dp(14), h.dp(24))
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    companion object {
        private val PIN_COLOR = Color.parseColor("#7C3AED")

        fun open(h: HomeActivity, c: Cust?, l: Loc?) {
            val d = Details(h, c, l)
            h.push(d.root) { d.close() }
            d.start()
        }
    }

    private fun start() {
        relink()
        Repo.addListener(listener)
        loadNote()
        fill()
    }

    private fun close() {
        Repo.removeListener(listener)
    }

    /** The last note comes from the phone's own copy (kept live by Repo), so opening a customer costs no read. */
    private fun loadNote() {
        val c = cust
        note = if (c != null) Repo.noteFor(c.id) else null
        noteLoaded = c == null || Repo.notesLoaded
    }

    private fun relink() {
        val c = cust
        val l = loc
        if (c != null) {
            loc = Repo.locFor(c) ?: l
        } else if (l != null) {
            loc = Repo.locs[l.id] ?: l
            cust = Repo.custFor(loc!!)
        }
    }

    private fun phone(): String = cust?.phone?.takeIf { it.isNotBlank() } ?: loc?.phone ?: ""

    /** Kept for readability: the app font (Times style) is set by the theme, no weight in between exists. */
    private fun medium(t: TextView): TextView = t


    private fun hairLine(t: TableLayout, thick: Boolean = false) {
        val tr = TableRow(h)
        val v = View(h)
        v.setBackgroundColor(if (thick) EDGE else HAIR)
        tr.addView(v, TableRow.LayoutParams(MATCH, if (thick) h.dp(1) else 1).apply { span = 3 })
        t.addView(tr, TableLayout.LayoutParams(MATCH, WRAP))
    }

    /** Blue band with the red centred title ("Customer Information" ...), like the Excel format. */
    private fun band(t: TableLayout, title: String) {
        val tr = TableRow(h)
        val tv = h.label(title, 16f, Color.parseColor("#D91C1C"), true)
        tv.gravity = Gravity.CENTER
        tv.setBackgroundColor(BAND)
        tv.setPadding(h.dp(8), h.dp(7), h.dp(8), h.dp(7))
        tr.addView(tv, TableRow.LayoutParams(MATCH, WRAP).apply { span = 3 })
        t.addView(tr, TableLayout.LayoutParams(MATCH, WRAP))
    }

    /** One data row: title (first column, as wide as its longest title) | value (second column). */
    private fun trow(t: TableLayout, k: String, v: String, color: Int = INK) {
        val tr = TableRow(h)
        val key = h.label(k, 15f, Color.parseColor("#334155"), true)
        key.setPadding(h.dp(10), h.dp(6), h.dp(10), h.dp(6))
        tr.addView(key, TableRow.LayoutParams(WRAP, WRAP))
        val sep = View(h)
        sep.setBackgroundColor(EDGE)
        tr.addView(sep, TableRow.LayoutParams(h.dp(1), MATCH))
        val value = h.label(if (v.isBlank()) "-" else v, 15.5f, color, true)
        value.setPadding(h.dp(10), h.dp(6), h.dp(10), h.dp(6))
        tr.addView(value, TableRow.LayoutParams(0, WRAP, 1f))
        t.addView(tr, TableLayout.LayoutParams(MATCH, WRAP))
    }

    private fun dmy(ms: Long): String =
        if (ms <= 0L) "-" else java.text.SimpleDateFormat("dd-MMM-yyyy", java.util.Locale.ENGLISH).format(java.util.Date(ms))

    private fun section(t: String): LinearLayout {
        val c = h.vbox()
        c.background = h.shape(Color.WHITE, 20, Color.parseColor("#E6EBF2"))
        h.softShadow(c, 4)
        c.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(8))
        val head = h.hbox()
        val bar = View(h)
        bar.background = h.shape(C.primary, 2)
        head.addView(bar, LinearLayout.LayoutParams(h.dp(3), h.dp(14)).apply { rightMargin = h.dp(8) })
        val title = h.label(t, 12f, Color.parseColor("#475569"), true)
        title.letterSpacing = 0.08f
        head.addView(title)
        c.addView(head)
        body.addView(c, h.lp(12))
        return c
    }

    private fun tile(res: Int, name: String, enabled: Boolean, color: Int, onClick: () -> Unit): LinearLayout {
        val col = h.vbox()
        col.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        val fg = if (enabled) color else Color.parseColor("#94A3B8")
        val tint = if (enabled) (color and 0xFFFFFF) or 0x1A000000 else Color.parseColor("#F1F5F9")
        val ic = h.icon(res, fg, 18)
        ic.setPadding(h.dp(10), h.dp(10), h.dp(10), h.dp(10))
        ic.background = h.ripple(h.shape(tint, 20), 20)
        col.addView(ic, LinearLayout.LayoutParams(h.dp(38), h.dp(38)))
        val t = h.label(name, 11f, if (enabled) C.text else C.muted, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        col.addView(t, h.lp(3, WRAP, WRAP))
        col.isClickable = true
        col.setOnClickListener { if (enabled) onClick() }
        return col
    }

    private fun amtOrDash(v: Double): String = if (v > 0.0) money(v) else "-"

    private fun fill() {
        body.removeAllViews()
        val c = cust
        val l = loc
        header.title.text = c?.name ?: l?.name ?: "Customer"
        headVillage.text = c?.village ?: l?.village ?: ""
        headUnion.text = c?.union ?: l?.union ?: ""

        val tiles = h.hbox()
        tiles.gravity = Gravity.TOP
        tiles.background = h.shape(Color.WHITE, 20, Color.parseColor("#E6EBF2"))
        h.softShadow(tiles, 4)
        tiles.setPadding(h.dp(6), h.dp(9), h.dp(6), h.dp(8))
        val hasPhone = normalizePhone(phone()).isNotEmpty()
        val tw = { LinearLayout.LayoutParams(0, WRAP, 1f) }
        tiles.addView(tile(R.drawable.ic_h_pin, if (l != null) "Location" else "Add Location", c != null, PIN_COLOR) {
            c?.let { LocationEditor.open(h, it) }
        }, tw())
        tiles.addView(tile(R.drawable.ic_h_navigate, "Navigation", l != null, C.primary) {
            l?.let { Act.navigate(h, it.lat, it.lng, it.name) }
        }, tw())
        tiles.addView(tile(R.drawable.ic_h_edit, "Add Note", c != null, C.warn) { addNoteDialog() }, tw())
        tiles.addView(tile(R.drawable.ic_h_call, "Call", hasPhone, C.ok) { Act.call(h, phone()) }, tw())
        body.addView(tiles, h.lp(4))

        val table = TableLayout(h)
        table.isStretchAllColumns = false
        table.setColumnStretchable(2, true)
        table.setColumnShrinkable(2, true)
        val wrap = FrameLayout(h)
        wrap.background = h.shape(Color.WHITE, 10, EDGE)
        wrap.clipToOutline = true
        h.softShadow(wrap, 3)
        wrap.addView(table, FrameLayout.LayoutParams(MATCH, WRAP))
        body.addView(wrap, h.lp(12))

        band(table, "Customer Information")
        hairLine(table, true)
        trow(table, "Name", c?.name ?: l?.name ?: "")
        hairLine(table)
        trow(table, "Father", c?.father ?: l?.father ?: "")
        hairLine(table)
        trow(table, "Spouse", c?.spouse ?: l?.spouse ?: "")
        hairLine(table)
        trow(table, "Village", c?.village ?: l?.village ?: "")
        hairLine(table)
        trow(table, "Union", c?.union ?: l?.union ?: "")
        hairLine(table)
        trow(table, "Phone", phone())

        if (c != null) {
            val late = c.overdue > 0L && c.overdue <= todayStart()
            hairLine(table, true)
            band(table, "Loan Information")
            hairLine(table, true)
            trow(table, "Program", c.progLabel)
            hairLine(table)
            trow(table, "Loan Case", c.caseNo)
            hairLine(table)
            trow(table, "Overdue", dmy(c.overdue), if (late) Color.parseColor("#E11D1D") else INK)
            hairLine(table)
            trow(table, "Installment", if (c.installment > 0.0) fmtAmt(c.installment) else "-")
            hairLine(table)
            trow(table, "Balance", fmtAmt(c.balance))
            hairLine(table)
            trow(table, "Due", fmtAmt(c.due), if (c.due > 0.0) Color.parseColor("#E11D1D") else INK)
            hairLine(table)
            trow(table, "Received", fmtAmt(c.received), Color.parseColor("#00A651"))
        }

        val s4 = section("NOTES")
        val n = note
        if (c == null) {
            s4.addView(h.label("Notes are available for customers with an active loan.", 14f, C.muted), h.lp(8))
        } else if (!noteLoaded) {
            s4.addView(h.label("Loading...", 14f, C.muted), h.lp(8))
        } else {
            val last = n?.entries?.firstOrNull()
            val text = n?.lastNote.orEmpty().ifEmpty { last?.text.orEmpty() }
            if (n == null || text.isEmpty()) {
                s4.addView(h.label("No notes yet.", 14f, C.muted), h.lp(8))
            } else {
                val by = n.lastBy.ifEmpty { last?.by.orEmpty() }
                val at = if (n.lastAt > 0L) n.lastAt else (last?.at ?: 0L)
                val promise = n.promise.ifEmpty { last?.promise.orEmpty() }
                val b = h.vbox()
                b.background = h.shape(Color.parseColor("#F8FAFC"), 14, C.line)
                b.setPadding(h.dp(14), h.dp(12), h.dp(14), h.dp(12))
                val top = h.hbox()
                top.gravity = Gravity.TOP
                top.addView(medium(h.label(text, 15f, C.text)), LinearLayout.LayoutParams(0, WRAP, 1f))
                if (promise.isNotEmpty()) top.addView(datePill(promise), LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = h.dp(10) })
                b.addView(top)
                val meta = listOf(by, fmtDateTime(at)).filter { it.isNotEmpty() && it != "-" }.joinToString("  \u2022  ")
                if (meta.isNotEmpty()) b.addView(h.label(meta, 11f, C.muted), h.lp(6))
                s4.addView(b, h.lp(10))
            }
            if (Repo.can("note-add")) {
                s4.addView(h.btn("Add note", 0, R.drawable.ic_add) { addNoteDialog() }, h.lp(14))
                s4.setPadding(h.dp(16), h.dp(14), h.dp(16), h.dp(16))
            }
        }
    }

    /** Highlighted promise date (dd-MM-yyyy): red = expired, amber = today, blue = upcoming. */
    private fun datePill(promise: String): LinearLayout {
        val ms = promiseMs(promise)
        val today = todayStart()
        val col = if (ms in 1 until today) C.bad else if (ms == today) Color.parseColor("#D97706") else C.primary
        val r = h.hbox()
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = h.shape((col and 0xFFFFFF) or 0x24000000, 20)
        r.setPadding(h.dp(10), h.dp(6), h.dp(12), h.dp(6))
        r.addView(h.icon(R.drawable.ic_calendar, col, 14), LinearLayout.LayoutParams(h.dp(14), h.dp(14)).apply { rightMargin = h.dp(5) })
        r.addView(h.label(fmtPromise(promise), 13f, col, true))
        return r
    }

    private fun addNoteDialog() {
        val c = cust ?: return
        if (!Repo.can("note-add")) { h.toast("You do not have permission to add notes"); return }
        val col = h.vbox()
        col.setPadding(h.dp(20), h.dp(8), h.dp(20), 0)
        val et = EditText(h)
        et.hint = "Write note..."
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.minLines = 3
        et.gravity = Gravity.TOP
        et.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(1000))
        col.addView(et)
        var date = ""
        val dateTv: TextView = h.label("Promise date: tap to select", 15f, C.primary, true)
        dateTv.setPadding(0, h.dp(16), 0, h.dp(8))
        dateTv.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(h, { _, y, m, d ->
                date = String.format("%04d-%02d-%02d", y, m + 1, d)
                dateTv.text = "Promise date: $date"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        col.addView(dateTv)
        val dlg = AlertDialog.Builder(h)
            .setTitle("Note - " + c.name)
            .setView(col)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val text = et.text.toString().trim()
            if (text.isEmpty()) { h.toast("Note text is required"); return@setOnClickListener }
            if (date.isEmpty()) { h.toast("Promise date is required"); return@setOnClickListener }
            dlg.dismiss()
            h.toast("Saving note...")
            Repo.addNote(c, text, date) { ok, msg -> h.toast(if (ok) "Note saved" else msg) }
        }
    }
}
