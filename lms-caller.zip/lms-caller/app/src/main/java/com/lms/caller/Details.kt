package com.lms.caller

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Color
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.firebase.firestore.ListenerRegistration
import java.util.Calendar

/** Full-screen customer details. Works for a loan row, a saved location, or both. */
class Details private constructor(private val h: HomeActivity, private var cust: Cust?, private var loc: Loc?) {
    val root = h.vbox()
    private val body = h.vbox()
    private val header: Header
    private var note: NoteDoc? = null
    private var noteLoaded = false
    private var reg: ListenerRegistration? = null
    private val listener: () -> Unit = { relink(); fill() }

    init {
        header = Header(h, cust?.name ?: loc?.name ?: "Customer", "", { h.pop() })
        root.setBackgroundColor(C.bg)
        root.addView(header.root)
        val sv = ScrollView(h)
        sv.isFillViewport = true
        body.setPadding(h.dp(14), h.dp(14), h.dp(14), h.dp(28))
        sv.addView(body)
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    companion object {
        fun open(h: HomeActivity, c: Cust?, l: Loc?) {
            val d = Details(h, c, l)
            h.push(d.root) { d.close() }
            d.start()
        }
    }

    private fun start() {
        relink()
        Repo.addListener(listener)
        cust?.let { c ->
            reg = Repo.noteListen(c.id) { n ->
                note = n
                noteLoaded = true
                fill()
            }
        }
        if (cust == null) noteLoaded = true
        fill()
    }

    private fun close() {
        Repo.removeListener(listener)
        reg?.remove()
        reg = null
    }

    private fun relink() {
        val c = cust
        val l = loc
        if (c != null) {
            loc = Repo.locFor(c) ?: l
        } else if (l != null) {
            loc = Repo.locs[l.id] ?: l
            cust = Repo.custFor(loc!!)
        }
    }

    private fun phone(): String = cust?.phone?.takeIf { it.isNotBlank() } ?: loc?.phone ?: ""

    private fun divider(): View = View(h).apply { setBackgroundColor(C.line) }

    private fun kv(p: LinearLayout, k: String, v: String, color: Int = C.text) {
        if (p.childCount > 1) p.addView(divider(), LinearLayout.LayoutParams(MATCH, h.dp(1)).apply { topMargin = h.dp(11) })
        val r = h.hbox()
        r.gravity = Gravity.TOP
        r.addView(h.label(k, 13f, C.muted), LinearLayout.LayoutParams(0, WRAP, 0.4f))
        val t = h.label(if (v.isBlank()) "-" else v, 14f, color, true)
        t.gravity = Gravity.END
        r.addView(t, LinearLayout.LayoutParams(0, WRAP, 0.6f))
        p.addView(r, h.lp(11))
    }

    private fun section(t: String): LinearLayout {
        val c = h.card()
        val title = h.label(t.uppercase(), 12f, C.muted, true)
        title.letterSpacing = 0.1f
        c.addView(title)
        body.addView(c, h.lp(12))
        return c
    }

    private fun stat(k: String, v: String, color: Int = C.text): LinearLayout {
        val col = h.vbox()
        col.addView(h.label(k, 12f, C.muted))
        col.addView(h.label(v, 16f, color, true), h.lp(3))
        return col
    }

    private fun tile(res: Int, name: String, enabled: Boolean, accent: Int, onClick: () -> Unit): LinearLayout {
        val col = h.vbox()
        col.gravity = Gravity.CENTER_HORIZONTAL
        val fg = if (enabled) accent else Color.parseColor("#94A3B8")
        val bgc = if (enabled) (accent and 0xFFFFFF) or 0x1A000000 else Color.parseColor("#F1F5F9")
        val ic = h.icon(res, fg, 22)
        ic.setPadding(h.dp(14), h.dp(14), h.dp(14), h.dp(14))
        ic.background = h.ripple(h.shape(bgc, 28), 28)
        col.addView(ic, LinearLayout.LayoutParams(h.dp(56), h.dp(56)))
        val tv = h.label(name, 12f, if (enabled) C.text else C.muted, true)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        col.addView(tv, h.lp(7, MATCH, WRAP))
        col.isClickable = true
        col.setOnClickListener { if (enabled) onClick() }
        return col
    }

    private fun fill() {
        body.removeAllViews()
        val c = cust
        val l = loc
        header.title.text = c?.name ?: l?.name ?: "Customer"
        header.sub.text = listOf(c?.village ?: l?.village ?: "", c?.union ?: l?.union ?: "")
            .filter { it.isNotEmpty() }.joinToString("  \u2022  ")

        /* ---- loan summary (bank-style balance card) ---- */
        if (c != null) {
            val late = c.overdue > 0L && c.overdue <= todayStart()
            val sum = h.card()
            val top = h.hbox()
            top.addView(h.label("Outstanding balance", 13f, C.muted), LinearLayout.LayoutParams(0, WRAP, 1f))
            top.addView(if (late) h.pill("Overdue", C.bad) else h.pill("Active", C.ok))
            sum.addView(top)
            val bal = h.label("\u09F3 " + fmtAmt(c.balance), 30f, C.dark, true)
            sum.addView(bal, h.lp(6))
            sum.addView(divider(), LinearLayout.LayoutParams(MATCH, h.dp(1)).apply { topMargin = h.dp(14) })
            val st = h.hbox()
            st.addView(stat("Due", "\u09F3 " + fmtAmt(c.due), if (c.due > 0) C.bad else C.text), LinearLayout.LayoutParams(0, WRAP, 1f))
            st.addView(stat("Received", "\u09F3 " + fmtAmt(c.received), if (c.received > 0) C.ok else C.text), LinearLayout.LayoutParams(0, WRAP, 1f))
            sum.addView(st, h.lp(14))
            body.addView(sum, h.lp(2))
        }

        /* ---- actions ---- */
        val acts = h.card()
        val tiles = h.hbox()
        tiles.gravity = Gravity.CENTER
        val hasPhone = normalizePhone(phone()).isNotEmpty()
        val tw = { LinearLayout.LayoutParams(0, WRAP, 1f) }
        tiles.addView(tile(R.drawable.ic_phone, "Call", hasPhone, C.ok) { Act.call(h, phone()) }, tw())
        tiles.addView(tile(R.drawable.ic_nav, "Navigate", l != null, C.primary) {
            l?.let { Act.navigate(h, it.lat, it.lng, it.name) }
        }, tw())
        tiles.addView(tile(R.drawable.ic_edit, "Add Note", c != null, C.warn) { addNoteDialog() }, tw())
        tiles.addView(tile(R.drawable.ic_pin, if (l != null) "Edit Location" else "Add Location", c != null, Color.parseColor("#7C3AED")) {
            c?.let { LocationEditor.open(h, it) }
        }, tw())
        acts.addView(tiles)
        body.addView(acts, h.lp(12))

        /* ---- customer ---- */
        val s1 = section("Customer")
        kv(s1, "Name", c?.name ?: l?.name ?: "")
        kv(s1, "Father", c?.father ?: l?.father ?: "")
        kv(s1, "Spouse", c?.spouse ?: l?.spouse ?: "")
        kv(s1, "Village", c?.village ?: l?.village ?: "")
        kv(s1, "Union", c?.union ?: l?.union ?: "")
        kv(s1, "Phone", phone(), if (hasPhone) C.primary else C.text)

        /* ---- loan details ---- */
        if (c != null) {
            val s2 = section("Loan details")
            val late = c.overdue > 0L && c.overdue <= todayStart()
            kv(s2, "Programme", Programmes.label(c.prog, c.progName))
            kv(s2, "Loan case", c.caseNo)
            kv(s2, "Overdue date", fmtDate(c.overdue), if (late) C.bad else C.text)
        }

        /* ---- home location ---- */
        val s3 = section("Home location")
        if (l == null) {
            s3.addView(h.label("No location saved for this customer.", 14f, C.muted), h.lp(10))
        } else {
            val r = h.hbox()
            r.addView(h.pill("Saved", C.ok))
            if (!l.active) r.addView(h.pill("Loan closed", C.warn), h.lp(0, WRAP, WRAP).apply { leftMargin = h.dp(8) })
            s3.addView(r, h.lp(10, WRAP, WRAP))
            if (l.accuracy > 0) kv(s3, "Accuracy", "\u00B1" + l.accuracy.toInt() + " m")
            kv(s3, "Saved by", l.updatedBy)
            kv(s3, "Last update", fmtDateTime(l.updatedAt))
            kv(s3, "Coordinates", String.format(java.util.Locale.US, "%.6f, %.6f", l.lat, l.lng))
        }

        /* ---- latest note only ---- */
        val s4 = section("Latest note")
        val n = note
        if (c == null) {
            s4.addView(h.label("Notes are available for customers with an active loan.", 14f, C.muted), h.lp(10))
        } else if (!noteLoaded) {
            s4.addView(h.label("Loading...", 14f, C.muted), h.lp(10))
        } else {
            val e: NoteEntry? = n?.entries?.firstOrNull()
                ?: n?.takeIf { it.lastNote.isNotEmpty() }?.let { NoteEntry(it.lastNote, it.promise, it.lastBy, it.lastAt) }
            if (e == null) {
                s4.addView(h.label("No notes yet.", 14f, C.muted), h.lp(10))
            } else {
                val row = h.hbox()
                row.gravity = Gravity.TOP
                val bar = View(h)
                bar.background = h.shape(C.primary, 2)
                row.addView(bar, LinearLayout.LayoutParams(h.dp(3), MATCH))
                val b = h.vbox()
                b.setPadding(h.dp(12), h.dp(2), 0, h.dp(2))
                b.addView(h.label(e.text, 14f, C.text))
                val meta = StringBuilder(e.by).append("  \u2022  ").append(fmtDateTime(e.at))
                b.addView(h.label(meta.toString(), 12f, C.muted), h.lp(6))
                if (e.promise.isNotEmpty()) b.addView(h.pill("Promise: " + e.promise, C.primary), h.lp(8, WRAP, WRAP))
                row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
                s4.addView(row, h.lp(12))
            }
        }
    }

    private fun addNoteDialog() {
        val c = cust ?: return
        if (!Repo.can("note-add")) { h.toast("You do not have permission to add notes"); return }
        val col = h.vbox()
        col.setPadding(h.dp(20), h.dp(8), h.dp(20), 0)
        val et = EditText(h)
        et.hint = "Write note..."
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.minLines = 3
        et.gravity = Gravity.TOP
        et.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(1000))
        col.addView(et)
        var date = ""
        val dateTv: TextView = h.label("Promise date: tap to select", 15f, C.primary, true)
        dateTv.setPadding(0, h.dp(16), 0, h.dp(8))
        dateTv.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(h, { _, y, m, d ->
                date = String.format("%04d-%02d-%02d", y, m + 1, d)
                dateTv.text = "Promise date: $date"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        col.addView(dateTv)
        val dlg = AlertDialog.Builder(h)
            .setTitle("Note - " + c.name)
            .setView(col)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val text = et.text.toString().trim()
            if (text.isEmpty()) { h.toast("Note text is required"); return@setOnClickListener }
            if (date.isEmpty()) { h.toast("Promise date is required"); return@setOnClickListener }
            dlg.dismiss()
            h.toast("Saving note...")
            Repo.addNote(c, text, date) { ok, msg -> h.toast(if (ok) "Note saved" else msg) }
        }
    }
}
