plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lms.caller"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lms.caller"
        minSdk = 26
        targetSdk = 34
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        versionCode = 11
        versionName = "2.1"
    }

    // Fixed keystore: every build has the same signature, so a new APK installs over the old one.
    signingConfigs {
        create("lms") {
            storeFile = file("lms.keystore")
            storePassword = "lmscaller"
            keyAlias = "lms"
            keyPassword = "lmscaller"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("lms")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-firestore")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.maplibre.gl:android-sdk:11.5.2")
}
