# KB LMS (Loan Monitoring System) — Android app  (project folder `lms-caller`)

> **Read this first (for any AI / developer).** This file describes the whole Android app: architecture, every file, every
> Firestore collection and field, every module/screen, all business rules, the build pipeline and how to change things safely.
> Keep this README updated whenever the app changes (see section 16 "Changelog").
>
> Owner / developer: **Md. Golam Rosul (GPF-2361)**, Contact +8801893-264663. The owner chats in **Banglish**
> (Bengali written in English letters) and wants working code delivered as a zip (`lms-caller.zip`).

---

## 1. What the app is

* **App name on the phone:** `KB LMS`. Package / applicationId: `com.lms.caller`. Internal project/folder name: `lms-caller`
  (the old name was "LMS Caller"; do NOT rename the folder, the GitHub workflow depends on it).
* Mobile companion of a **web app** (plain HTML/JS + Firebase Firestore, no build step, "LMS - Loan Monitoring System").
  Both use the **same Firestore database** (one Firebase project per branch). The web app is the main system: loan data is
  uploaded there (a PDF parser inserts it automatically into `LoanMonthlyData`), users/permissions are managed there, and
  the web app sends **call requests** to the phone.
* Users are field officers of a bank branch (investigators / callers). The app lets them: see customers and loans, call and
  navigate to them, write notes with promise dates, work on CL / WCL lists, follow overdue / reschedule / promise-date lists,
  see a due summary, capture customer home locations (GPS), record new loan applicants (home visit), and receive call requests
  from the web app (the phone places the call).
* UI language is **English**, UI is built **in code** (no XML layouts). Numbers use **lakh format** (`1,32,47,278`), dates `dd-MM-yyyy`
  or `dd MMM yyyy`.

## 2. Tech stack / build facts

| Item | Value |
|---|---|
| Language | Kotlin 1.9.24, Android Gradle Plugin 8.5.2, Gradle 8.9 (workflow), Java 17 |
| SDK | minSdk 26, targetSdk/compileSdk 34 (adaptive icon always available) |
| Libraries | Firebase BoM 33.1.2 → `firebase-firestore` only (no Firebase Auth), `androidx.core-ktx`, `androidx.recyclerview`, `org.maplibre.gl:android-sdk:11.5.2` (maps) |
| UI | Pure Kotlin views (helpers in `Ui.kt`); `Activity` based (no AppCompat, no Compose, no Fragments) |
| Version | `versionCode 10`, `versionName 2.0` in `app/build.gradle.kts` (bump on release) |
| Signing | Fixed keystore `app/lms.keystore` (alias `lms`, password `lmscaller`) so every APK updates the old one |
| ABI | `arm64-v8a`, `armeabi-v7a` |
| Maps | MapLibre with raster tiles (see `MapStyle` in `LocationScreen.kt`), Google Maps app is used only for navigation intents |
| I have no compiler in chat | Code is generated without compiling. Re-check braces/imports carefully; the user compiles through GitHub Actions and reports errors. |

### Build pipeline (GitHub Actions, `build.yml` in the repo root next to `lms-caller.zip`)
1. Repo contains `lms-caller.zip` (the project folder `lms-caller/` zipped) and `.github/workflows/build.yml`.
2. Workflow: `unzip -o lms-caller.zip` → (optional) write `lms-caller/app/src/main/assets/branch.json` from secret `<BRANCH>_BRANCH`
   when the workflow is started with a branch code → `gradle assembleRelease` in `lms-caller/` → copy APK as `KB-LMS[-BRANCH].apk` → upload artifact.
3. `branch.json` (optional) = Firebase config of a branch built into the APK (`Prefs.bundled`). Without it the phone must be set up
   once with the developer password (section 4).
4. Never rename the zip's inner folder `lms-caller` or the zip name `lms-caller.zip` without also changing `build.yml`.

## 3. Source map (`app/src/main/java/com/lms/caller/`)

| File | Purpose |
|---|---|
| `SplashActivity.kt` | **Launcher activity.** Full-screen animated logo (3D flip, tilt, shine, loading line, ~2.3 s), then starts `MainActivity`. Theme `SplashTheme` (dark gradient; Android 12 system splash made invisible in `values-v31`). |
| `MainActivity.kt` | Not exported. Router + setup + login + "Caller" status screen. Modes: developer password → config (setup code or manual) → login → status. If a user is logged in and not opened from Home it immediately calls `goHome()`. |
| `HomeActivity.kt` | Main container. Holds `content` (screens) and an overlay stack (`push`/`pop`) for full-screen sub-pages. `select(i)` switches module; constants `HOME, CUSTOMERS, LOCATION, MAP, LISTS, SUMMARY, RESCHEDULE, NEWCUST, MONITOR, OVERDUE`. Back button: pop overlay → go Home → exit. Also hosts MapView lifecycle (`registerMap/unregisterMap`), runtime permission helper `needLocation`, `openCaller()`. `onResume` starts the call service if needed and calls `Repo.autoSyncCheck()`. |
| `Repo.kt` | **Central data layer (singleton `Repo`)**: models (`Cust`, `Loc`, `ListItem`, `PromiseItem`, `Me`, notes), caches, all Firestore listeners and writes, union filter, location matching + automatic daily sync, helpers (`fmtAmt`, `fmtDate`, `parseAnyDate`, `normalizePhone`, `rescheduleNumber`, `promiseMs`, ...). |
| `Store.kt` | `Prefs` (SharedPreferences `lms_caller`: config, userId, userName, enabled, info), `Fb` (FirebaseApp/Firestore creation per config), `Setup` (AES-GCM encrypted setup code), `Auth` (developer password hash). |
| `Ui.kt` | UI toolkit: `C` colours, `dp`, `vbox/hbox/label/icon/pill/btn/field/fab/shape/ripple/gradient/avatar/paintAvatar`, `Header`, `SearchBox`, `money()`, `Screen` interface, `View.gone()`. |
| `Modules.kt` | `HomeScreen` (launcher grid + developer card), `ListsScreen` (CL/WCL), `SummaryScreen`. |
| `CustomersScreen.kt` | `UnionBar`, `CustList` (shared customer row list), `infoRow`, `CustomersScreen`, `RescheduleScreen`. |
| `LoanEntry.kt` | `Paid` (Paid button = web Loan Entry logic: calendar → Disburse Type detection → `LoanEntries` + delete from `LoanMonthlyData`) and `PendingScreen` (Pending Loan module = web Date Pending without Set Date). |
| `Monitoring.kt` | `MonitoringScreen` (promise dates + month-OD lists) and `OverdueScreen`. |
| `Details.kt` | Customer details page (`Details.open(h, cust, loc)`): top 4 action tiles, customer, loan, notes, add-note dialog. |
| `LocationScreen.kt` | `MapStyle`, `LocationScreen` (saved locations list), `LocationEditor` (add/update a customer's GPS location). |
| `GpsPinMap.kt` | Shared **GPS-only** map component used by `LocationEditor` and `PinPicker`. |
| `NewCustomer.kt` | `CustomerPicker`, `PinPicker`, `NewCustomerEditor`, `NewCustomerScreen`. |
| `MapScreen.kt` | Customers map (MapLibre clusters/markers, search, route builder, navigation). |
| `Gps.kt` | `Gps` (LocationManager wrapper, best-fix logic) and `Act` (call / navigate intents with permission checks). |
| `CallService.kt` | Foreground service: listens to `CallQueue/{userId}` and places the call; heartbeat to `CallDevices`. `CallService.ensure(ctx)` starts it. |
| `BootReceiver.kt` | Restarts the service after phone reboot. |

Resources: `res/drawable/ic_*.xml` (vector icons), `res/drawable-nodpi/logo.png` + `ic_launcher_foreground.png`, `res/mipmap-*/ic_launcher.png`,
`res/mipmap-anydpi-v26/ic_launcher.xml` (adaptive icon: gradient background `drawable/ic_launcher_background.xml` + foreground png),
`res/values/{strings,styles,ic_colors}.xml`, `res/values-v31/styles.xml`.

## 4. Setup, login, session

1. **Developer password** (hash in `Auth`) protects phone setup. Then the Firebase config is entered manually or via an encrypted
   **setup code** (`Setup.encrypt/fromCode`, AES-GCM, key from the developer password) or is **bundled** (`assets/branch.json`).
2. **Login**: user ID (GPF) + password are checked against `Users/{userId}` (`password` stored plain text *by decision* in the web app,
   `status` must be `active`; `pending` = waiting for admin approval). On success `Prefs.saveUser`, listener service is started.
3. **Logout** (Caller status page): stop `CallService`, `Prefs.clearUser`, `Repo.reset()` (listeners, in-memory maps, union filter), **`Repo.wipeLocal()`** (deletes `*_loans.json`, `*_locs.json`, clears every `lms_repo_*` prefs file = profile, signatures, sync times, route list, and the saved call/sync info) and **`Fb.wipeCache()`** (waits up to 4 s for pending writes, `terminate()` + `clearPersistence()` of the Firestore offline cache, then drops the FirebaseApp). No customer/loan/location data stays on the phone after logout; the next login downloads everything again. While the wipe runs `Fb.db()` returns null (a login attempt in that first moment fails, retry). The same wipe runs when the server setup is changed (`applyConfig`).
4. The profile (`Me`: id, name, role, permissions[], unions[]) comes from `Users/{userId}` (live listener, also cached in prefs key `me`
   **only valid for the same user id**).
5. **Permissions** (strings in `Users.permissions[]`, role `Admin` has all): `call-request`, `note-add`, `wcl-edit`, `cl-edit`
   (the web app has many more; the app only checks these via `Repo.can(...)`).
6. **Union filter**: `Repo.unionSel` (set of union names) defaults to the user's own `unions[]`; empty set = all unions.
   Shown as a compact chip in every module header (`UnionBar`). `Repo.unionOk(union)` is used by all lists. Re-initialised per user id (`unionFor`).

## 5. Firestore data model (same database as the web app)

| Collection / doc | Doc id | Fields used by the app | Written by app? |
|---|---|---|---|
| `LoanMonthlyData` | programme code + loan case no | `loanProgrammeCode`, `loanProgrammeName`, `loanCaseNo`, `customerName`, `fatherName`, `spouseName`, `village`, `union`, `phone`, `overdueDate`, `currentBalance`, `due`, `receivedAmount`, `rescheduleNo` | **Never** (inserted by the PDF parser / web app) |
| `MetaData` / `Loan Data Update` | – | any Timestamp field = last upload time. App compares it with the saved signature (`sig`) to decide when to re-download loans. | No (read with `Source.SERVER`) |
| `MetaData` / `Location Sync` | – | `updatedAt` (server ts), `updatedAtMs`, `updatedByName`, `leaseUntilMs`, `leaseBy`, counts (`phoneUpdated`, `loanUpdated`, `infoUpdated`, `inactiveMarked`, `unchanged`, `needsReview`), `skipReason`, `skipAtMs` | Yes (auto sync) |
| `Users` | GPF | `name`, `password`, `role`, `status`, `permissions[]`, `unions[]` | No |
| `Notes` | loan id | `entries[]` {text, promiseDate, by, byId, at}, `lastNote`, `lastNoteBy`, `lastNoteAt`, `lastPromiseDate`, `loanId`, `loanProgrammeCode`, `loanCaseNo`, `customerName`, `lastNoteSyncAt` | Yes (add note) |
| `WCL` | loan id | `loanProgrammeCode`, `customerName`, `needMore` (number or "") | Yes (add / remove / need more) |
| `CL` | loan id | `loanProgrammeCode`, `customerName` | Yes (add / remove) |
| `CustomerLocations` | auto id | `mobile`, `loanProgramme`, `loanCase`, `customerName`, `fatherName`, `spouseName`, `village`, `union`, `latitude`, `longitude`, `accuracy`, `active`, `source` (`gps`; old data may have `manual`), `createdAt`, `createdBy`, `updatedAt`, `updatedBy`, `updatedByName`. Legacy docs may carry `newCustomer: true` (moved to `NewCustomers` automatically by the owner's next visit to the New Customer module). | Yes |
| `NewCustomers` | auto id | `customerName`, `fatherName` (= spouse/father), `village`, `mobile`, `latitude`, `longitude`, `accuracy`, `source`, `createdAt`, `createdBy` (user id), `createdByName` | Yes |
| `CallQueue` | user id | `status` (`Pending` → app sets `Received` / `Failed` / `Expired` / `Busy`), `number`, `time`, `customerName` | Yes (status only) |
| `CallDevices` | user id | `userId`, `lastSeen`, `device`, `app` (heartbeat) | Yes |

* **Loan id** = programme code + loan case no (the `LoanMonthlyData` doc id) and is used as the doc id of `Notes`, `WCL`, `CL`.
* Security rules are not in this repo. If rules are per collection, `NewCustomers` and `MetaData/Location Sync` must be writable.
  An error like `PERMISSION_DENIED` at login means the Firestore rules expired/changed (e.g. test-mode date limit).

## 6. Data layer (`Repo.kt`) — how it works

* **Loans**: `refreshLoans(force)` compares the server `MetaData/Loan Data Update` signature with the saved one. Unchanged → use cache
  (`files/loans.json`); changed/forced → download the whole `LoanMonthlyData` (~hundreds of docs) and rewrite the cache. `SCHEMA` constant
  (currently 3) forces a re-download when the stored loan fields change (bump it when you add a field to `Cust`).
  Loans are kept in memory in `Repo.loans` plus indexes `byKey` ("prog|case") and `byPhone`.
* **Locations**: listener on `CustomerLocations` (incremental by `updatedAt`, cached in `files/locs.json`) → `Repo.locs` (map id→`Loc`).
  `Repo.locFor(cust)` finds a customer's location by key or phone; `Repo.custFor(loc)` the reverse.
  `Loc.isNew` is only true for legacy new-customer docs (ignored by sync/map/lists).
* **Lazy listeners** (started when needed, `ensure*`): `ensureLists()` (WCL + CL collections), `ensureNotes()` (whole `Notes` collection → `Repo.promises`
  = last promise date of every loan), `ensureNewCustomers()` (only this user's `NewCustomers`).
* **Listeners** notify UI via `Repo.addListener { }` / `removeListener`; screens refresh in their own `onData()`.
* **Notes**: `addNote` appends to `entries[]` with `arrayUnion` and updates the `last*` fields; `noteListen(id)` for the details page.
* **Reset**: `Repo.reset()` removes every listener, clears caches/profile/union filter (on logout).

### Automatic location sync (daily, silent)
Goal: `CustomerLocations` must follow `LoanMonthlyData` because customers repay (8–12 months) and take new loans (new programme code / loan case,
sometimes a new phone).
* Trigger: `Repo.autoSyncCheck()` — called after the loans were verified with the server (`refreshLoans`) and after the first locations snapshot
  (`locsLoaded`, **cache is enough**, no server snapshot needed), and from `HomeActivity.onResume`. At most one check per 10 minutes per process.
  It works only on data already in memory (`Repo.loans` + `Repo.locs`, i.e. local cache + live changes): **no extra Firestore reads for matching**.
* **24 h check without reads:** the last sync time is remembered on the phone (prefs `locSyncAt_<projectId>`). While it is < 24 h old nothing is read from Firestore.
* Otherwise a transaction on `MetaData/Location Sync` runs: if the document does **not exist it is created** (lease fields), if `updatedAtMs` is older than 24 h
  and no lease (`leaseUntilMs`) is active the phone takes a 15-minute lease and syncs, so only one phone runs it.
* The sync keeps running when the app goes to the background (singleton `Repo` + `CallService` foreground process).
* **Errors stop the sync** (nothing is changed, retried on the next app open). A failed batch is retried document by document and a missing document (`NOT_FOUND`) is ignored.
* Diagnostics: the last result/error text is kept in prefs `syncInfo` and shown on the **Caller** status page ("Location sync: ...",
  e.g. `Auto sync error: PERMISSION_DENIED ...` when Firestore rules do not allow writing `MetaData/Location Sync`).
* `planSync()` (rules, unchanged from the former manual "Update" button):
  1. Match each location **by phone** (normalised) with loans; if several loans share the phone the **customer name** (`sameName`) decides; if the phone
     belongs to a *different* customer it is only listed in `review` (not changed automatically).
  2. Phone not found → match by **programme code + loan case**; update the **phone** (and other customer info) from the loan.
  3. Neither matches → mark `active = false` (loan closed). A closed location becomes active again if it matches later.
  4. Info (name, father, spouse, village, union) is refreshed from the matched loan.
* Safety: if more than 20 and more than 40 % of active locations would become inactive the run is skipped (looks like incomplete loan data) and retried after 6 h.
* Auto-sync writes `updatedBy = "system"`, `updatedByName = "Auto sync"` and bumps `updatedAt` (needed so other phones receive the change).
* There is **no manual Update button** any more.

## 7. Modules (what each screen does)

Home (`HomeScreen`) is a launcher: header with logo + the user's full name (no "Welcome"), refresh button; module cards in rows of 3,3,2,2
(fixed height, no scrolling); developer credit card at the bottom with a call (dialer) button.
Order: Customers, CL/WCL, Summary / Overdue, Monitoring, Reschedule / Location, Map / New Customer, Caller.

| Module | Class | Behaviour |
|---|---|---|
| **Customers** | `CustomersScreen` | All loans (union filtered). Search by **customer name by default**; chips under the search box **Father / Spouse / Loan Case / Phone** switch the single search field (tap again to go back to name). Sorted overdue first. Row → `Details`. |
| **CL / WCL** | `ListsScreen` | Tabs WCL / CL (counts). Shows loans that are in the `WCL`/`CL` collection. With `wcl-edit`/`cl-edit`: "+" add (programme + L/C no lookup, confirm), Remove, WCL **Need more** amount (own line above the overdue badge). |
| **Summary** | `SummaryScreen` | For the (union-filtered) loans of the logged-in user: Total Due (overdue balance + due of not-overdue loans, % of balance), Overdue, Only Due, Reschedule, WCL, CL, All loans — count + amount. |
| **Overdue** | `OverdueScreen` | Loans with overdue date ≤ today **excluding loans in CL**. Month chips (All, `Nov 2026 (5)` …) filter by overdue month. Oldest first. |
| **Monitoring** | `MonitoringScreen` | Promise-date list from `Notes.lastPromiseDate`. Tabs **Today** (default on every open), **Expired**, **Upcoming**, plus two buttons on one line: **`<CurrentMonth>-OD`** and **`<NextMonth>-OD`** = loans whose overdue date falls in that month. Rows show balance/due, last note text, promise date pill (`dd-MM-yyyy`) and "X days late / in X days". |
| **Reschedule** | `RescheduleScreen` | Loans with `rescheduleNo >= 1`; badge `RS-01`, `RS-02`… |
| **Location** | `LocationScreen` | Saved locations from `CustomerLocations` (also of customers whose loan is paid, badge "Active loan" / "Loan closed"). Row → Details (customer if still a loan) with navigation. "+" = pick a customer **without** a location → `LocationEditor`. |
| **Map** | `MapScreen` | Saved locations on a map (new customers excluded). **No clustering / no counts**: every customer has its own teardrop pin (green = active, grey = loan closed, amber = selected). The user's live location is a separate blue "You" pin with a pulsing ring. On open the map goes to the user's location, zoomed out so the nearest customers (within ~3 km, at least 6 within 15 km) are visible; without GPS it shows all pins. Search, satellite toggle, my-location (re-focus), route list + navigation. Customer names appear at zoom >= 15.5. |
| **New Customer** | `NewCustomerScreen` | Home visit of a loan applicant: "+" form (name*, spouse/father, village, mobile, **GPS location**) saved to `NewCustomers`. List shows **only the records of the logged-in user**. **Connect**: pick a customer **without a location** (`CustomerPicker`), review card, confirm → location written to `CustomerLocations` with the customer's loan data and the `NewCustomers` doc is deleted. **Delete** removes a record (applicant got no loan). |
| **Pending Loan** | `PendingScreen` | Live list of `LoanEntries` with `status == "Date Pending"` (needs web `date-pending` → `view`). Tabs **New but Old** / **Revolving**, oldest paid date on top, search name / L/C / phone. Union chip defaults to the user's unions, others can be viewed. Only **Delete** (no Set Date): allowed only when the entry's union is one of the logged-in user's own unions and `date-pending` → `edit` (transaction deletes only if still Date Pending). Call button uses `customerMobile`. |
| **Caller** | `MainActivity` (status mode) | Shows whether the call listener runs, last call info, restart / logout / setup code. |

### Customer details page (`Details`)
Header (name, village • union). Four tiles in this order: **Update Location / Add Location**, **Navigation**, **Add Note**, **Call**.
Sections: Customer, Loan (programme `code - name`, loan case, overdue date, balance, due, received), **Notes**: only the **last note** — text, highlighted promise date
(`dd-MM-yyyy`; red expired, amber today, blue upcoming) and a small line `user • date time`; "Add note" button (needs `note-add`; promise date required).
There is **no Home Location card** any more.

### Location capture rules (GPS only)
* `GpsPinMap` shows a red pin **attached to the phone's GPS coordinate** (+ accuracy circle). Panning/zooming never changes it and it cannot be moved by hand.
  When updating an existing location, the old saved pin is shown in grey.
* Phone **GPS must be ON** (`LocationManager.GPS_PROVIDER`). If off → dialog "Turn on GPS" opens location settings and capture continues automatically when
  GPS is switched on (PROVIDERS_CHANGED receiver). Runtime location permission is requested first.
* Save/Use uses only the latest GPS fix (`panel.fix`), `source = "gps"`. Accuracy > 50 m asks for confirmation. Replacing an existing location asks for confirmation.
* Buttons: **Refresh GPS**, satellite toggle, re-centre.

## 8. Call listener (`CallService`)
* Foreground service (type `specialUse`, notification channel `lms_caller`). Listens to `CallQueue/{userId}`; only fresh **server** data is acted on.
* For `status == "Pending"`: validates number `^01\d{9}$`, request age ≤ 60 s, phone idle, 10 s cool-down, permission `CALL_PHONE`, then sets status
  (`Received`/`Failed`/`Expired`/`Busy`) in a transaction and places **one** call. Heartbeat every 30 s to `CallDevices/{userId}` (wake lock).
* It is started at login, at boot (`BootReceiver`), by "Restart listener", **and every time the app is opened** (`CallService.ensure`) — earlier versions only
  started it at login, so it stayed dead after the OS killed it. Foreground-start failures are caught.
* Phone battery settings should be "Unrestricted" / auto-start allowed or some OEMs kill the service.

## 9. UI conventions (keep consistent)
* Colours in `C` (`primary` blue, `dark`, `bg`, `line`, `text`, `muted`, `ok` green, `warn`, `bad` red, `violet`, `teal`, `pink`, `orange`).
* Every list module: blue gradient `Header` (rounded bottom) with **title + sub text, compact union chip, action icons and the search box inside the header**,
  then (optional) tabs/chips, then the list. Rows are white rounded cards with a status stripe, coloured letter avatar, pills (`pill()`), green call button.
* Home cards: gradient, centred icon in translucent circle, title + short hint, fixed 104 dp rows.
* Amounts: `money()` → `৳ 1,32,47,278` (lakh grouping in `fmtAmt`). Promise dates `dd-MM-yyyy` (`fmtPromise`), other dates `dd MMM yyyy`.
* Reschedule badge `RS-%02d`. Overdue = overdue date ≤ today (`todayStart()` local midnight).
* Phone numbers are normalised with `normalizePhone` (11-digit `01XXXXXXXXX`).
* A new screen: implement `Screen` (`view`, `onShow`, `onDestroy`), add a constant + `when` branch in `HomeActivity.select`, a card in `HomeScreen`,
  register listeners with `Repo.addListener` and remove them in `onDestroy`.
* A full-screen sub-page: build a view and `h.push(view) { onClose }`, close with `h.pop()`.

## 10. Branding
* App name `KB LMS`; logo `res/drawable-nodpi/logo.png` (login header, Home header, splash). Launcher icon = adaptive icon, white card of the logo zoomed to fill the icon on
  a blue gradient background; legacy PNG icons in `mipmap-*`.
* Splash: 3D flip/tilt of the logo, shine sweep, "KB LMS / Loan Monitoring System", loading line; tap to skip; ~2.3 s.

## 11. Business rules cheat-sheet
* Reschedule loan: `rescheduleNo >= 1` (number or text, commas ignored).
* Overdue: `overdueDate <= today` (amount = balance). Only Due: not overdue and `due > 0` (amount = due). Total Due = Overdue + Only Due.
* Overdue List excludes CL loans; Summary still counts them.
* Month-OD: overdue date inside the current / next calendar month (includes dates still in the future of that month).
* Promise lists use only the **last** note's promise date: today = equal, expired = before today, upcoming = after.
* A customer may have only one location; Connect and "+ Add location" list only customers **without** a location.
* New Customer records are private to the user who created them.
* A customer's loan renewal (new programme code/case) is handled by the daily sync (phone first, then programme+case).
* Logout deletes all locally cached data (files, prefs, Firestore offline cache) so another user/branch never sees or mixes old data.

## 12. Typical change recipes
* **Add a loan field** → read it in `Cust.fromDoc`, add to `Cust` constructor + `toJson/fromJson`, bump `SCHEMA` in `Repo`, show it in `Details`/lists.
* **Add a module** → screen class (see section 9), `HomeActivity` constant/branch/array size, card in `HomeScreen.items` (keep the 3,3,2,2 row plan or adjust),
  icon in `res/drawable`.
* **Change colours/design** → `Ui.kt` (`C`, `Header`, `SearchBox`) and the card builders in `Modules.kt`.
* **New Firestore collection** → add listener/writes in `Repo` (lazy `ensure*`), remember Firestore rules.
* **Sync rules** → `Repo.planSync/applySync/autoSyncCheck`.
* After editing, check: balanced braces, imports, `R.drawable.*` exist, no leftover references; zip as `lms-caller.zip` (folder `lms-caller/` inside).

## 13. Known limitations
* Not compiled in chat; build errors appear in GitHub Actions and are fixed in the next iteration.
* If both the phone number **and** the loan case/programme of a customer change, the daily sync cannot re-link that location (add it again manually).
* Passwords are plain text in `Users` (decision of the web app owner); Firestore rules are outside this repo.
* Notes: the last note of every loan **that exists in `LoanMonthlyData`** is kept on the phone (`files/<project>_notes.json`). A note whose loan is not in LoanMonthlyData is never loaded (notes already saved locally stay). First run: notes are asked by document id for the loan ids only (`whereIn(documentId)`, groups of 30), then a live listener (`Repo.attachNotes()`) asks only for notes with `lastNoteSyncAt` newer than the newest one saved, so long offline periods cost no extra reads. Loans that are new after a LoanMonthlyData download get their note asked by id. Monitoring, Details and `Repo.noteFor(id)` read the local copy only. **The web app must set `lastNoteSyncAt` (Firestore Timestamp, serverTimestamp) on every note save**, otherwise its notes are not picked up after the first run.
* Promise list covers only loans currently in `LoanMonthlyData`.

## 14. Web app relation (for reference)
Web files: `index.html`, `core.js` (collections `COL`, login, loading, notes, call queue, summary maths), `app.js`, `modules/*.js`
(loan-table, loan-list, loan-filter, wcl-report, cl-report, employee-summary, total-summary, user-management, permission-management), `branches.js`
(branch code → Firebase config, e.g. `0536` = Mollahat Branch). The app mirrors web logic for: overdue/due summary, WCL/CL lists, notes + promise dates,
reschedule, user permissions/unions and the call queue.

## 15. Owner preferences (how to work with this owner)
* Replies in **Banglish**; short, clear; list what changed and anything the owner must do.
* Deliver the full updated project as `lms-caller.zip` (and `build.yml` if the pipeline changes).
* Owner asks to **confirm doubts before coding** when behaviour is unclear; otherwise implement and explain defaults.
* The owner values a professional, colourful, compact UI; everything on Home must fit one screen without scrolling; lists should show as many rows as possible.

## 16. Changelog (high level)
* v2.0 baseline: login, customers list, details, call listener, map, location capture (manual), notes.
* Details redesign (programme name, last note only, new tiles), Home launcher, CL/WCL module, Summary, Reschedule, Location list, New Customer module.
* Monitoring (promise dates, month-OD lists), Overdue list, lakh number format, RS-01 badges, union chip + search inside header, customers search by chosen field.
* Fixes: login "Missing permissions" diagnosis (Firestore rules), call listener auto-start, union filter after switching user, reschedule parsing.
* New Customer moved to `NewCustomers`; daily automatic location sync with `MetaData/Location Sync`; GPS-only location capture with GPS-on enforcement.
* Logout now wipes all cached data (files, prefs, Firestore persistence).
* Sync fix: no longer waits for a server snapshot of locations (it never came when nothing changed), uses cache/memory, local 24 h check, error diagnostics on the Caller page.
* Branding: KB LMS name, logo icon, 3D splash, developer credit card on Home.

* **Paid button / Pending Loan:** small green **Paid** pill left of the customer name in Customers, Overdue, Reschedule, Monitoring and CL/WCL lists (needs web `loan-entry` → `create`, i.e. `Users.dsbPerms` or role default; Admin all). Click → date picker (title = customer) → Submit runs the web Loan Entry (Old Customer) logic: Disburse Type = `New but Old` if Revolving not active for the programme (`RevolvingProgrammes`), reschedule ≥ 1, case no has a decimal, paid date ≥ overdue date, or `LoanInfo/<prog+case>.loanDurationMonths` > 12 / missing; else `Revolving`. Writes `LoanEntries/OLD_<sha256(prog::case)>` (same id as web, duplicate → "Already saved"), status `Date Pending`, then deletes the `LoanMonthlyData` doc and drops the loan from the phone cache (`Repo.dropLoan`). `Me` now carries `dsb` (Users.dsbPerms); `Repo.dsbCan(module, action)` mirrors web `dsb/perm.js`. New module constant `HomeActivity.PENDING`, Home grid rows 3,3,3,2.
* v2.1 (versionCode 11): Map module redesigned - clustering and pin counts removed, individual premium pins (bitmaps drawn in `Pins` object in `MapScreen.kt`), live blue "You" pin, auto-focus on user + nearby customers, new customer card (avatar, distance, status), legend. GPS tracking runs only while the map is visible.
* v2.1 notes: `Repo.lastNotes` + `startNotes()` (incremental by `lastNoteSyncAt`, saved in notes.json, optimistic local update in `addNote`), `noteListen` removed, `fullRefresh()` re-reads all notes.
* v2.1 Monitoring: third button **Current Due** next to the two month-OD buttons. Rule copied from the web app Due List (`loan-table.js`): overdue date is today or earlier OR `due` > 0. Amount line = overdue loan -> current balance, due-but-not-overdue -> due amount (same as the web `stats()`); sorted by overdue date (no overdue date last). Month buttons now use short month names (Dec-OD) so three buttons fit one line.
* v2.3: Details screen redesigned (loan summary tiles: Installment / Balance / Due / Received, status chip, divider rows). `Cust.installment` = `installmentAmount` of LoanMonthlyData (json key `ia`); `SCHEMA` 4 so LoanMonthlyData is downloaded once again to fill it. Home page: white cards with thin border, soft tinted icon chips, new outline icons (`ic_h_*.xml`, stroke vectors, tinted in code).
* v2.4: Home page restyled to the owner's mockup (`HomeHeaderBg` wave header, glass refresh button, gradient cards with accent border, glossy gradient icon tiles, developer card). `Context.softShadow()` in Ui.kt = soft blue shadow (Android 9+). Details: one card with two sections (Customer Info / Loan Information), every value in a left-aligned dotted-border cell; quick actions and Notes are separate cards.
* v2.5: Details = one card, sections **Customer Information** and **Loan Information**, every data item is a row (title column + value column) with a light dotted border. `HeaderBg` (Ui.kt) is now the background of the shared `Header` too, so every screen has the same deep-blue wave header as Home; status bar colour is #071A4F (top colour of the header).
* v2.6: Details table follows the owner's Excel format (`Customer_Data_Table.xlsm`): one bordered table, blue band + red centred titles (Customer Information / Loan Information), first column title (auto width), second column value, thin dividers, Overdue/Due red, Received green, compact 13sp text. Village + Union moved to the right side of the Details header. Header height reduced on every screen. Bug fix: `HeaderBg` reused one Paint whose alpha leaked from the wave drawing into the next gradient draw, which made headers look pale after returning to a screen (alpha reset to 255 now). Constants used by Details' init-time `fill()` must be top-level (not declared after `init`).
* v2.7 Write Off: `Cust.loanStatus` (LoanMonthlyData `LoanStatus`, json `ls`, SCHEMA 5 = one full re-download) and `Cust.writeOff` (status contains "write-off" in any spelling/case). New module **Write Off** (`WriteOff.kt`, `HomeActivity.WRITEOFF`): list of write-off loans with each loan's last note (from the local notes copy), promise date, search, union filter; oldest last note first, loans without a note on top. Write-off loans are skipped in Monitoring **Current Due** and the two month-OD buttons, in the **Overdue** module and in all Summary figures (own WRITE OFF box instead). Their notes still appear in Monitoring Today / Expired / Upcoming. Home now has 12 modules (4 rows of 3).
* v2.8: first-letter avatar removed from every list / card (Customers, CL/WCL, Overdue, Monitoring, Reschedule, Location, Map card, New Customer, Pending, Write Off). Details table text enlarged (15 / 15.5 / 16sp).
* v2.9: same as 2.8; the extra "status" field fallback for write-off detection was removed again (write-off / Overdue / Current Due rules are exactly as in 2.7).
* v3.0: Customers list search-by chip **Loan Case** switches the keyboard to the number keyboard (with dot, e.g. 356.1); Phone keeps the phone keyboard; the keyboard is restarted so it switches at once.
* v3.1: Overdue module excludes only CL loans again (write-off loans are inside CL). Monitoring Current Due / month-OD and Summary still keep write-off loans out of their figures.
* v3.2: Summary: write-off loans are left out of Overdue / Only Due / Total Due only (CL loans stay in Overdue as before); All Loans, Reschedule, WCL and CL count them again; own WRITE OFF box.
* v3.3: App font = Liberation Serif (Times New Roman compatible, subset Latin ~25 KB each) in `res/font/` (`app_serif.xml` = regular 400 + bold 700). Set once by the theme (`AppTheme` in values/styles.xml, also in SplashTheme) so every TextView / EditText / dialog uses it. Bengali text and the taka sign are not in the font and fall back to the system font. `Context.withTextScale()` (Ui.kt, used in `attachBaseContext` of the three activities) makes all sp text 10% larger. License text: `licenses/LiberationFonts-copyright.txt`.
* v3.4: Home module cards: row height 104 -> 118dp, tighter side padding, no font padding on title / hint, so the hint line and long titles (New Customer) are no longer cut with the serif font. Font sizes unchanged.
* v3.5: Home module cards are back to the original size (row 104dp, margins 5dp). Instead the content is top aligned (icon 4dp from the top, title 5dp below the icon, hint 2dp below the title) so the hint is no longer cut. Font sizes unchanged.
* v3.6: Details table values and the four action names (Location / Navigation / Note / Call) are bold; New Customer form: typed text is bold (`EditText.boldWhenTyped()` in Ui.kt, hint stays regular).
* v3.7: Details table: the first-column titles (Name, Father, ... Received) are bold too (dark slate colour so they still differ from the values).
