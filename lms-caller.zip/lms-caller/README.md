# KB LMS (Loan Monitoring System) — Android app  (project folder `lms-caller`)

> **Read this first (for any AI / developer).** This file describes the whole Android app: architecture, every file, every
> Firestore collection and field, every module/screen, all business rules, the build pipeline and how to change things safely.
> Keep this README updated whenever the app changes (see section 16 "Changelog").
>
> Owner / developer: **Md. Golam Rosul (GPF-2361)**, Contact +8801893-264663. The owner chats in **Banglish**
> (Bengali written in English letters) and wants working code delivered as a zip (`lms-caller.zip`).

---

## 1. What the app is

* **App name on the phone:** `KB LMS`. Package / applicationId: `com.lms.caller`. Internal project/folder name: `lms-caller`
  (the old name was "LMS Caller"; do NOT rename the folder, the GitHub workflow depends on it).
* Mobile companion of a **web app** (plain HTML/JS + Firebase Firestore, no build step, "LMS - Loan Monitoring System").
  Both use the **same Firestore database** (one Firebase project per branch). The web app is the main system: loan data is
  uploaded there (a PDF parser inserts it automatically into `LoanMonthlyData`), users/permissions are managed there, and
  the web app sends **call requests** to the phone.
* Users are field officers of a bank branch (investigators / callers). The app lets them: see customers and loans, call and
  navigate to them, write notes with promise dates, work on CL / WCL lists, follow overdue / reschedule / promise-date lists,
  see a due summary, capture customer home locations (GPS), record new loan applicants (home visit), and receive call requests
  from the web app (the phone places the call).
* UI language is **English**, UI is built **in code** (no XML layouts). Numbers use **lakh format** (`1,32,47,278`), dates `dd-MM-yyyy`
  or `dd MMM yyyy`.

## 2. Tech stack / build facts

| Item | Value |
|---|---|
| Language | Kotlin 1.9.24, Android Gradle Plugin 8.5.2, Gradle 8.9 (workflow), Java 17 |
| SDK | minSdk 26, targetSdk/compileSdk 34 (adaptive icon always available) |
| Libraries | Firebase BoM 33.1.2 → `firebase-firestore` only (no Firebase Auth), `androidx.core-ktx`, `androidx.recyclerview`, `org.maplibre.gl:android-sdk:11.5.2` (maps) |
| UI | Pure Kotlin views (helpers in `Ui.kt`); `Activity` based (no AppCompat, no Compose, no Fragments) |
| Version | `versionCode 10`, `versionName 2.0` in `app/build.gradle.kts` (bump on release) |
| Signing | Fixed keystore `app/lms.keystore` (alias `lms`, password `lmscaller`) so every APK updates the old one |
| ABI | `arm64-v8a`, `armeabi-v7a` |
| Maps | MapLibre with raster tiles (see `MapStyle` in `LocationScreen.kt`), Google Maps app is used only for navigation intents |
| I have no compiler in chat | Code is generated without compiling. Re-check braces/imports carefully; the user compiles through GitHub Actions and reports errors. |

### Build pipeline (GitHub Actions, `build.yml` in the repo root next to `lms-caller.zip`)
1. Repo contains `lms-caller.zip` (the project folder `lms-caller/` zipped) and `.github/workflows/build.yml`.
2. Workflow: `unzip -o lms-caller.zip` → (optional) write `lms-caller/app/src/main/assets/branch.json` from secret `<BRANCH>_BRANCH`
   when the workflow is started with a branch code → `gradle assembleRelease` in `lms-caller/` → copy APK as `KB-LMS[-BRANCH].apk` → upload artifact.
3. `branch.json` (optional) = Firebase config of a branch built into the APK (`Prefs.bundled`). Without it the phone must be set up
   once with the developer password (section 4).
4. Never rename the zip's inner folder `lms-caller` or the zip name `lms-caller.zip` without also changing `build.yml`.

## 3. Source map (`app/src/main/java/com/lms/caller/`)

| File | Purpose |
|---|---|
| `SplashActivity.kt` | **Launcher activity.** Full-screen animated logo (3D flip, tilt, shine, loading line, ~2.3 s), then starts `MainActivity`. Theme `SplashTheme` (dark gradient; Android 12 system splash made invisible in `values-v31`). |
| `MainActivity.kt` | Not exported. Router + setup + login + "Caller" status screen. Modes: developer password → config (setup code or manual) → login → status. If a user is logged in and not opened from Home it immediately calls `goHome()`. |
| `HomeActivity.kt` | Main container. Holds `content` (screens) and an overlay stack (`push`/`pop`) for full-screen sub-pages. `select(i)` switches module; constants `HOME, CUSTOMERS, LOCATION, MAP, LISTS, SUMMARY, RESCHEDULE, NEWCUST, MONITOR, OVERDUE, PENDING`. Back button: pop overlay → go Home → exit. Also hosts MapView lifecycle (`registerMap/unregisterMap`), runtime permission helper `needLocation`, `openCaller()`. `onResume` starts the call service if needed and calls `Repo.autoSyncCheck()`. |
| `Repo.kt` | **Central data layer (singleton `Repo`)**: models (`Cust`, `Loc`, `ListItem`, `PromiseItem`, `Me`, notes), caches, all Firestore listeners and writes, union filter, location matching + automatic daily sync, helpers (`fmtAmt`, `fmtDate`, `parseAnyDate`, `normalizePhone`, `rescheduleNumber`, `promiseMs`, ...). |
| `Store.kt` | `Prefs` (SharedPreferences `lms_caller`: config, userId, userName, enabled, info), `Fb` (FirebaseApp/Firestore creation per config), `Setup` (AES-GCM encrypted setup code), `Auth` (developer password hash). |
| `Ui.kt` | UI toolkit: `C` colours, `dp`, `vbox/hbox/label/icon/pill/btn/field/fab/shape/ripple/gradient/avatar/paintAvatar`, `Header`, `SearchBox`, `money()`, `Screen` interface, `View.gone()`. |
| `Modules.kt` | `HomeScreen` (launcher grid + developer card), `ListsScreen` (CL/WCL), `SummaryScreen`. |
| `CustomersScreen.kt` | `UnionBar`, `CustList` (shared customer row list), `infoRow`, `CustomersScreen`, `RescheduleScreen`. |
| `PendingLoan.kt` | `PendingLoanScreen` (module **Pending Loan** = web "Date Pending", call + delete only). |
| `Monitoring.kt` | `MonitoringScreen` (promise dates + month-OD lists) and `OverdueScreen`. |
| `Details.kt` | Customer details page (`Details.open(h, cust, loc)`): top 4 action tiles, customer, loan, notes, add-note dialog. |
| `LocationScreen.kt` | `MapStyle`, `LocationScreen` (saved locations list), `LocationEditor` (add/update a customer's GPS location). |
| `GpsPinMap.kt` | Shared **GPS-only** map component used by `LocationEditor` and `PinPicker`. |
| `NewCustomer.kt` | `CustomerPicker`, `PinPicker`, `NewCustomerEditor`, `NewCustomerScreen`. |
| `MapScreen.kt` | Customers map (MapLibre clusters/markers, search, route builder, navigation). |
| `Gps.kt` | `Gps` (LocationManager wrapper, best-fix logic) and `Act` (call / navigate intents with permission checks). |
| `CallService.kt` | Foreground service: listens to `CallQueue/{userId}` and places the call; heartbeat to `CallDevices`. `CallService.ensure(ctx)` starts it. |
| `BootReceiver.kt` | Restarts the service after phone reboot. |

Resources: `res/drawable/ic_*.xml` (vector icons), `res/drawable-nodpi/logo.png` + `ic_launcher_foreground.png`, `res/mipmap-*/ic_launcher.png`,
`res/mipmap-anydpi-v26/ic_launcher.xml` (adaptive icon: gradient background `drawable/ic_launcher_background.xml` + foreground png),
`res/values/{strings,styles,ic_colors}.xml`, `res/values-v31/styles.xml`.

## 4. Setup, login, session

1. **Developer password** (hash in `Auth`) protects phone setup. Then the Firebase config is entered manually or via an encrypted
   **setup code** (`Setup.encrypt/fromCode`, AES-GCM, key from the developer password) or is **bundled** (`assets/branch.json`).
2. **Login**: user ID (GPF) + password are checked against `Users/{userId}` (`password` stored plain text *by decision* in the web app,
   `status` must be `active`; `pending` = waiting for admin approval). On success `Prefs.saveUser`, listener service is started.
3. **Logout** (Caller status page): stop `CallService`, `Prefs.clearUser`, `Repo.reset()` (listeners, in-memory maps, union filter), **`Repo.wipeLocal()`** (deletes `*_loans.json`, `*_locs.json`, clears every `lms_repo_*` prefs file = profile, signatures, sync times, route list, and the saved call/sync info) and **`Fb.wipeCache()`** (waits up to 4 s for pending writes, `terminate()` + `clearPersistence()` of the Firestore offline cache, then drops the FirebaseApp). No customer/loan/location data stays on the phone after logout; the next login downloads everything again. While the wipe runs `Fb.db()` returns null (a login attempt in that first moment fails, retry). The same wipe runs when the server setup is changed (`applyConfig`).
4. The profile (`Me`: id, name, role, permissions[], unions[]) comes from `Users/{userId}` (live listener, also cached in prefs key `me`
   **only valid for the same user id**).
5. **Permissions** (strings in `Users.permissions[]`, role `Admin` has all): `call-request`, `note-add`, `wcl-edit`, `cl-edit`. **Pending Loan** uses the web Disbursement rule (`Repo.canPending(action)`): Admin / `userType` Manager = all, else `dsbPerms["date-pending"]`, else the Investigation Officer default (view + edit)
   (the web app has many more; the app only checks these via `Repo.can(...)`).
6. **Union filter**: `Repo.unionSel` (set of union names) defaults to the user's own `unions[]`; empty set = all unions.
   Shown as a compact chip in every module header (`UnionBar`). `Repo.unionOk(union)` is used by all lists. Re-initialised per user id (`unionFor`).

## 5. Firestore data model (same database as the web app)

| Collection / doc | Doc id | Fields used by the app | Written by app? |
|---|---|---|---|
| `LoanMonthlyData` | programme code + loan case no | `loanProgrammeCode`, `loanProgrammeName`, `loanCaseNo`, `customerName`, `fatherName`, `spouseName`, `village`, `union`, `phone`, `overdueDate`, `currentBalance`, `due`, `receivedAmount`, `rescheduleNo` | **Never** (inserted by the PDF parser / web app) |
| `MetaData` / `Loan Data Update` | – | any Timestamp field = last upload time. App compares it with the saved signature (`sig`) to decide when to re-download loans. | No (read with `Source.SERVER`) |
| `MetaData` / `Location Sync` | – | `updatedAt` (server ts), `updatedAtMs`, `updatedByName`, `leaseUntilMs`, `leaseBy`, counts (`phoneUpdated`, `loanUpdated`, `infoUpdated`, `inactiveMarked`, `unchanged`, `needsReview`), `skipReason`, `skipAtMs` | Yes (auto sync) |
| `Users` | GPF | `name`, `password`, `role`, `userType`, `status`, `permissions[]`, `unions[]`, `dsbPerms` (`{"date-pending": ["view","edit"]}`) | No |
| `Notes` | loan id | `entries[]` {text, promiseDate, by, byId, at}, `lastNote`, `lastNoteBy`, `lastNoteAt`, `lastPromiseDate`, `loanId`, `loanProgrammeCode`, `loanCaseNo`, `customerName`, `lastNoteSyncAt` | Yes (add note) |
| `WCL` | loan id | `loanProgrammeCode`, `customerName`, `needMore` (number or "") | Yes (add / remove / need more) |
| `CL` | loan id | `loanProgrammeCode`, `customerName` | Yes (add / remove) |
| `CustomerLocations` | auto id | `mobile`, `loanProgramme`, `loanCase`, `customerName`, `fatherName`, `spouseName`, `village`, `union`, `latitude`, `longitude`, `accuracy`, `active`, `source` (`gps`; old data may have `manual`), `createdAt`, `createdBy`, `updatedAt`, `updatedBy`, `updatedByName`. Legacy docs may carry `newCustomer: true` (moved to `NewCustomers` automatically by the owner's next visit to the New Customer module). | Yes |
| `NewCustomers` | auto id | `customerName`, `fatherName` (= spouse/father), `village`, `mobile`, `latitude`, `longitude`, `accuracy`, `source`, `createdAt`, `createdBy` (user id), `createdByName` | Yes |
| `LoanEntries` | auto id / `OLD_<sha256>` | Date Pending loan entries created by the web **Loan Entry** form: `status` (`Date Pending` → web sets `Pending` after Set Date), `customerName`, `customerMobile` (number or text), `unionId`, `unionName`, `loanType` (`New but Old` / `Revolving` / `Pure New`), `oldProgrammeId`, `oldProgrammeName`, `oldLC`, `paidDate`, `investigatorName`, `createdAt`. When a web entry is saved the web **deletes the paid loan from `LoanMonthlyData`**. | Yes (delete only, while status is `Date Pending`) |
| `CallQueue` | user id | `status` (`Pending` → app sets `Received` / `Failed` / `Expired` / `Busy`), `number`, `time`, `customerName` | Yes (status only) |
| `CallDevices` | user id | `userId`, `lastSeen`, `device`, `app` (heartbeat) | Yes |

* **Loan id** = programme code + loan case no (the `LoanMonthlyData` doc id) and is used as the doc id of `Notes`, `WCL`, `CL`.
* Security rules are not in this repo. If rules are per collection, `NewCustomers` and `MetaData/Location Sync` must be writable.
  An error like `PERMISSION_DENIED` at login means the Firestore rules expired/changed (e.g. test-mode date limit).

## 6. Data layer (`Repo.kt`) — how it works

* **Loans**: `refreshLoans(force)` compares the server `MetaData/Loan Data Update` signature with the saved one. Unchanged → use cache
  (`files/loans.json`); changed/forced → download the whole `LoanMonthlyData` (~hundreds of docs) and rewrite the cache. `SCHEMA` constant
  (currently 3) forces a re-download when the stored loan fields change (bump it when you add a field to `Cust`).
  Loans are kept in memory in `Repo.loans` plus indexes `byKey` ("prog|case") and `byPhone`.
* **Live removal of paid loans (`startEntryWatch`)**: the web Loan Entry form creates a `LoanEntries` doc (`oldProgrammeId` = loan programme code, `oldLC` = loan case no) and then deletes the loan `LoanMonthlyData/<code><case>`. The app does NOT listen to the whole `LoanMonthlyData` collection (that costs one read per loan on every listener start). It listens only to **new `LoanEntries`** (`createdAt` after the last time this phone looked: `max(entrySeenMs, uploadMs)`, capped at 45 days) and removes the matching loan (`prog|case`) from `Repo.loans` and `loans.json` at once. `uploadMs` = newest Timestamp of `MetaData/Loan Data Update` (server clock), `entrySeenMs` = newest entry `createdAt` processed. Cost: a few reads per app start (entries created meanwhile). Started only after the loans are verified; re-attached on resume when the start time moved by > 20 min.
* **Locations**: listener on `CustomerLocations` (incremental by `updatedAt`, cached in `files/locs.json`) → `Repo.locs` (map id→`Loc`).
  `Repo.locFor(cust)` finds a customer's location by key or phone; `Repo.custFor(loc)` the reverse.
  `Loc.isNew` is only true for legacy new-customer docs (ignored by sync/map/lists).
* **Lazy listeners** (started when needed, `ensure*`): `ensureEntries()` (LoanEntries with status `Date Pending`, limit 800), `ensureLists()` (WCL + CL collections), `ensureNotes()` (promise dates → `Repo.promises`: reads only the `Notes` docs of loans that are in `LoanMonthlyData`, by id, 30 per query like the web app; result cached in `<project>_notes.json` with the checked loan ids; later starts read only new loans + a live listener on `lastNoteSyncAt` for notes saved meanwhile), `ensureNewCustomers()` (only this user's `NewCustomers`).
* **Listeners** notify UI via `Repo.addListener { }` / `removeListener`; screens refresh in their own `onData()`.
* **Notes**: `addNote` appends to `entries[]` with `arrayUnion` and updates the `last*` fields; `noteListen(id)` for the details page.
* **Reset**: `Repo.reset()` removes every listener, clears caches/profile/union filter (on logout).

### Automatic location sync (daily, silent)
Goal: `CustomerLocations` must follow `LoanMonthlyData` because customers repay (8–12 months) and take new loans (new programme code / loan case,
sometimes a new phone).
* Trigger: `Repo.autoSyncCheck()` — called after the loans were verified with the server (`refreshLoans`) and after the first locations snapshot
  (`locsLoaded`, **cache is enough**, no server snapshot needed), and from `HomeActivity.onResume`. At most one check per 10 minutes per process.
  It works only on data already in memory (`Repo.loans` + `Repo.locs`, i.e. local cache + live changes): **no extra Firestore reads for matching**.
* **24 h check without reads:** the last sync time is remembered on the phone (prefs `locSyncAt_<projectId>`). While it is < 24 h old nothing is read from Firestore.
* Otherwise a transaction on `MetaData/Location Sync` runs: if the document does **not exist it is created** (lease fields), if `updatedAtMs` is older than 24 h
  and no lease (`leaseUntilMs`) is active the phone takes a 15-minute lease and syncs, so only one phone runs it.
* The sync keeps running when the app goes to the background (singleton `Repo` + `CallService` foreground process).
* **Errors stop the sync** (nothing is changed, retried on the next app open). A failed batch is retried document by document and a missing document (`NOT_FOUND`) is ignored.
* Diagnostics: the last result/error text is kept in prefs `syncInfo` and shown on the **Caller** status page ("Location sync: ...",
  e.g. `Auto sync error: PERMISSION_DENIED ...` when Firestore rules do not allow writing `MetaData/Location Sync`).
* `planSync()` (rules, unchanged from the former manual "Update" button):
  1. Match each location **by phone** (normalised) with loans; if several loans share the phone the **customer name** (`sameName`) decides; if the phone
     belongs to a *different* customer it is only listed in `review` (not changed automatically).
  2. Phone not found → match by **programme code + loan case**; update the **phone** (and other customer info) from the loan.
  3. Neither matches → mark `active = false` (loan closed). A closed location becomes active again if it matches later.
  4. Info (name, father, spouse, village, union) is refreshed from the matched loan.
* Safety: if more than 20 and more than 40 % of active locations would become inactive the run is skipped (looks like incomplete loan data) and retried after 6 h.
* Auto-sync writes `updatedBy = "system"`, `updatedByName = "Auto sync"` and bumps `updatedAt` (needed so other phones receive the change).
* There is **no manual Update button** any more.

## 7. Modules (what each screen does)

Home (`HomeScreen`) is a launcher: header with logo + the user's full name (no "Welcome"), refresh button; module cards in rows of 3,3,3,2
(fixed height, no scrolling); developer credit card at the bottom with a call (dialer) button.
Order: Customers, CL/WCL, Summary / Overdue, Monitoring, Pending Loan / Reschedule, Location, Map / New Customer, Caller.

| Module | Class | Behaviour |
|---|---|---|
| **Customers** | `CustomersScreen` | All loans (union filtered). Search by **customer name by default**; chips under the search box **Father / Spouse / Loan Case / Phone** switch the single search field (tap again to go back to name). Sorted overdue first. Row → `Details`. |
| **CL / WCL** | `ListsScreen` | Tabs WCL / CL (counts). Shows loans that are in the `WCL`/`CL` collection. With `wcl-edit`/`cl-edit`: "+" add (programme + L/C no lookup, confirm), Remove, WCL **Need more** amount (own line above the overdue badge). |
| **Summary** | `SummaryScreen` | For the (union-filtered) loans of the logged-in user: Total Due (overdue balance + due of not-overdue loans, % of balance), Overdue, Only Due, Reschedule, WCL, CL, All loans — count + amount. |
| **Overdue** | `OverdueScreen` | Loans with overdue date ≤ today **excluding loans in CL**. Month chips (All, `Nov 2026 (5)` …) filter by overdue month. Oldest first. |
| **Monitoring** | `MonitoringScreen` | Promise-date list from `Notes.lastPromiseDate`. Tabs **Today** (default on every open), **Expired**, **Upcoming**, plus two buttons on one line: **`<CurrentMonth>-OD`** and **`<NextMonth>-OD`** = loans whose overdue date falls in that month. Rows show balance/due, last note text, promise date pill (`dd-MM-yyyy`) and "X days late / in X days". |
| **Reschedule** | `RescheduleScreen` | Loans with `rescheduleNo >= 1`; badge `RS-01`, `RS-02`… |
| **Location** | `LocationScreen` | Saved locations from `CustomerLocations` (also of customers whose loan is paid, badge "Active loan" / "Loan closed"). Row → Details (customer if still a loan) with navigation. "+" = pick a customer **without** a location → `LocationEditor`. |
| **Map** | `MapScreen` | Every saved location is its **own blue teardrop pin** (grey = loan closed, amber = selected) — **no clusters / count bubbles**. When the map opens it shows the **user's location as a red dot with halo** and zooms out to the customers within 3 km (zoom 12–16); without a location it fits all pins. Search, satellite toggle, my location, nearest list, route list + navigation. New customers are excluded. |
| **Pending Loan** | `PendingLoanScreen` | Web "Date Pending" list (`LoanEntries`, status `Date Pending`), live. Chips All / New but Old / Revolving / Pure New with counts, union filter (by `unionName`), search (name, union, mobile, loan case). Row: name, union, old programme + loan case, mobile, loan type pill, paid date, **Call** button (`customerMobile`) and **Delete** (needs `canPending("edit")`, confirm dialog, transaction deletes only while status is still `Date Pending`). There is **no Set Date**. |
| **New Customer** | `NewCustomerScreen` | Home visit of a loan applicant: "+" form (name*, spouse/father, village, mobile, **GPS location**) saved to `NewCustomers`. List shows **only the records of the logged-in user**. **Connect**: pick a customer **without a location** (`CustomerPicker`), review card, confirm → location written to `CustomerLocations` with the customer's loan data and the `NewCustomers` doc is deleted. **Delete** removes a record (applicant got no loan). |
| **Caller** | `MainActivity` (status mode) | Shows whether the call listener runs, last call info, restart / logout / setup code. |

### Customer details page (`Details`)
Header (name, village • union). Four tiles in this order: **Update Location / Add Location**, **Navigation**, **Add Note**, **Call**.
Sections: Customer, Loan (programme `code - name`, loan case, overdue date, balance, due, received), **Notes**: only the **last note** — text, highlighted promise date
(`dd-MM-yyyy`; red expired, amber today, blue upcoming) and a small line `user • date time`; "Add note" button (needs `note-add`; promise date required).
There is **no Home Location card** any more.

### Location capture rules (GPS only)
* `GpsPinMap` shows a red pin **attached to the phone's GPS coordinate** (+ accuracy circle). Panning/zooming never changes it and it cannot be moved by hand.
  When updating an existing location, the old saved pin is shown in grey.
* Phone **GPS must be ON** (`LocationManager.GPS_PROVIDER`). If off → dialog "Turn on GPS" opens location settings and capture continues automatically when
  GPS is switched on (PROVIDERS_CHANGED receiver). Runtime location permission is requested first.
* Save/Use uses only the latest GPS fix (`panel.fix`), `source = "gps"`. Accuracy > 50 m asks for confirmation. Replacing an existing location asks for confirmation.
* Buttons: **Refresh GPS**, satellite toggle, re-centre.

## 8. Call listener (`CallService`)
* Foreground service (type `specialUse`, notification channel `lms_caller`). Listens to `CallQueue/{userId}`; only fresh **server** data is acted on.
* For `status == "Pending"`: validates number `^01\d{9}$`, request age ≤ 60 s, phone idle, 10 s cool-down, permission `CALL_PHONE`, then sets status
  (`Received`/`Failed`/`Expired`/`Busy`) in a transaction and places **one** call. Heartbeat every 30 s to `CallDevices/{userId}` (wake lock).
* It is started at login, at boot (`BootReceiver`), by "Restart listener", **and every time the app is opened** (`CallService.ensure`) — earlier versions only
  started it at login, so it stayed dead after the OS killed it. Foreground-start failures are caught.
* Phone battery settings should be "Unrestricted" / auto-start allowed or some OEMs kill the service.

## 9. UI conventions (keep consistent)
* Colours in `C` (`primary` blue, `dark`, `bg`, `line`, `text`, `muted`, `ok` green, `warn`, `bad` red, `violet`, `teal`, `pink`, `orange`).
* Every list module: blue gradient `Header` (rounded bottom) with **title + sub text, compact union chip, action icons and the search box inside the header**,
  then (optional) tabs/chips, then the list. Rows are white rounded cards with a status stripe, coloured letter avatar, pills (`pill()`), green call button.
* Home cards: gradient, centred icon in translucent circle, title + short hint, fixed 104 dp rows (rows 3,3,3,2).
* Amounts: `money()` → `৳ 1,32,47,278` (lakh grouping in `fmtAmt`). Promise dates `dd-MM-yyyy` (`fmtPromise`), other dates `dd MMM yyyy`.
* Reschedule badge `RS-%02d`. Overdue = overdue date ≤ today (`todayStart()` local midnight).
* Phone numbers are normalised with `normalizePhone` (11-digit `01XXXXXXXXX`).
* A new screen: implement `Screen` (`view`, `onShow`, `onDestroy`), add a constant + `when` branch in `HomeActivity.select`, a card in `HomeScreen`,
  register listeners with `Repo.addListener` and remove them in `onDestroy`.
* A full-screen sub-page: build a view and `h.push(view) { onClose }`, close with `h.pop()`.

## 10. Branding
* App name `KB LMS`; logo `res/drawable-nodpi/logo.png` (login header, Home header, splash). Launcher icon = adaptive icon, white card of the logo zoomed to fill the icon on
  a blue gradient background; legacy PNG icons in `mipmap-*`.
* Splash: 3D flip/tilt of the logo, shine sweep, "KB LMS / Loan Monitoring System", loading line; tap to skip; ~2.3 s.

## 11. Business rules cheat-sheet
* Reschedule loan: `rescheduleNo >= 1` (number or text, commas ignored).
* Overdue: `overdueDate <= today` (amount = balance). Only Due: not overdue and `due > 0` (amount = due). Total Due = Overdue + Only Due.
* Overdue List excludes CL loans; Summary still counts them.
* Month-OD: overdue date inside the current / next calendar month (includes dates still in the future of that month).
* Promise lists use only the **last** note's promise date: today = equal, expired = before today, upcoming = after.
* A customer may have only one location; Connect and "+ Add location" list only customers **without** a location.
* New Customer records are private to the user who created them.
* A customer's loan renewal (new programme code/case) is handled by the daily sync (phone first, then programme+case).
* Logout deletes all locally cached data (files, prefs, Firestore offline cache) so another user/branch never sees or mixes old data.

## 12. Typical change recipes
* **Add a loan field** → read it in `Cust.fromDoc`, add to `Cust` constructor + `toJson/fromJson`, bump `SCHEMA` in `Repo`, show it in `Details`/lists.
* **Add a module** → screen class (see section 9), `HomeActivity` constant/branch/array size, card in `HomeScreen.items` (keep the 3,3,2,2 row plan or adjust),
  icon in `res/drawable`.
* **Change colours/design** → `Ui.kt` (`C`, `Header`, `SearchBox`) and the card builders in `Modules.kt`.
* **New Firestore collection** → add listener/writes in `Repo` (lazy `ensure*`), remember Firestore rules.
* **Sync rules** → `Repo.planSync/applySync/autoSyncCheck`.
* After editing, check: balanced braces, imports, `R.drawable.*` exist, no leftover references; zip as `lms-caller.zip` (folder `lms-caller/` inside).

## 13. Known limitations
* Not compiled in chat; build errors appear in GitHub Actions and are fixed in the next iteration.
* If both the phone number **and** the loan case/programme of a customer change, the daily sync cannot re-link that location (add it again manually).
* Passwords are plain text in `Users` (decision of the web app owner); Firestore rules are outside this repo.
* Notes collection is read completely by the Monitoring module (first open downloads all notes docs; later reads are cached).
* Promise list covers only loans currently in `LoanMonthlyData`.
* Live removal depends on the web Loan Entry form (entry with old programme + loan case). Loans removed from `LoanMonthlyData` in any other way disappear on the next full download (monthly upload marker change).
* Read cost to watch on big branches: Pending Loan reads all `Date Pending` entries (once per app process start; the call service keeps the process alive). Monitoring reads the notes of current loans only, once (first open), then only new loans and new notes.

## 14. Web app relation (for reference)
Web files: `index.html`, `core.js` (collections `COL`, login, loading, notes, call queue, summary maths), `app.js`, `modules/*.js`
(loan-table, loan-list, loan-filter, wcl-report, cl-report, employee-summary, total-summary, user-management, permission-management), `branches.js`
(branch code → Firebase config, e.g. `0536` = Mollahat Branch). The app mirrors web logic for: overdue/due summary, WCL/CL lists, notes + promise dates,
reschedule, user permissions/unions and the call queue.

## 15. Owner preferences (how to work with this owner)
* Replies in **Banglish**; short, clear; list what changed and anything the owner must do.
* Deliver the full updated project as `lms-caller.zip` (and `build.yml` if the pipeline changes).
* Owner asks to **confirm doubts before coding** when behaviour is unclear; otherwise implement and explain defaults.
* The owner values a professional, colourful, compact UI; everything on Home must fit one screen without scrolling; lists should show as many rows as possible.

## 16. Changelog (high level)
* v2.0 baseline: login, customers list, details, call listener, map, location capture (manual), notes.
* Details redesign (programme name, last note only, new tiles), Home launcher, CL/WCL module, Summary, Reschedule, Location list, New Customer module.
* Monitoring (promise dates, month-OD lists), Overdue list, lakh number format, RS-01 badges, union chip + search inside header, customers search by chosen field.
* Fixes: login "Missing permissions" diagnosis (Firestore rules), call listener auto-start, union filter after switching user, reschedule parsing.
* New Customer moved to `NewCustomers`; daily automatic location sync with `MetaData/Location Sync`; GPS-only location capture with GPS-on enforcement.
* Logout now wipes all cached data (files, prefs, Firestore persistence).
* Sync fix: no longer waits for a server snapshot of locations (it never came when nothing changed), uses cache/memory, local 24 h check, error diagnostics on the Caller page.
* Map pins are classic blue teardrops, Pending Loan module, live removal of loans paid on the web through new LoanEntries (cheap listener, not a LoanMonthlyData listener).
* Branding: KB LMS name, logo icon, 3D splash, developer credit card on Home.
